# Prompt For Claude Code

You are receiving a design handoff package for the SharePoint AI Knowledge Workspace.

Your job is to help move the design into practical pilot setup, but you must not assume the workspace is already production-ready.

## Required Read Order

Read these first:

1. `README_FOR_CLAUDE_CODE.md`
2. `EXPECTED_FIRST_OUTPUT.md`
3. `FIRST_OUTPUT_ACCEPTANCE_CHECKLIST.md`
4. `docs/wiki/hot.md`
5. `docs/wiki/index.md`
6. `docs/wiki/projects/SharePoint AI Knowledge Workspace Project.md`
7. `docs/wiki/specs/SharePoint AI Knowledge Workspace.md`
8. `docs/wiki/specs/SharePoint AI Knowledge Workspace V0 Readiness Gate.md`
9. `docs/wiki/specs/SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix.md`
10. `docs/wiki/specs/SharePoint AI Knowledge Workspace Private Pilot Materialization Plan.md`
11. `docs/wiki/specs/SharePoint AI Knowledge Workspace Minimal CLAUDE Rules.md`
12. `docs/wiki/specs/SharePoint AI Knowledge Workspace Initial File Contents.md`
13. `docs/wiki/specs/SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan.md`
14. `docs/wiki/specs/SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix.md`

Then read additional package files only as needed.

## Operating Rules

- Treat this as a pilot design handoff, not a finished production system.
- Prefer the Simple Minimum Profile.
- Do not add expansion folders, services, MCP, database, UI, or many skill files unless the documents explicitly call for that step.
- Do not directly edit root or project `official/`; use patches.
- Do not delete articles; use supersede and tombstone first.
- Keep `.raw` immutable and treat converted Markdown as source evidence.
- Put deterministic maintenance in Python where possible.
- Keep Claude Code work focused on semantic review, writing, and pilot planning.

## First Task To Perform

Create a practical implementation plan for private Simple Minimum materialization:

- target folder path,
- files/folders to create,
- initial file contents source,
- validation checklist,
- expected `kw-maint doctor` behavior,
- risks and open questions.

Do not create files until the human approves the plan.

Use `EXPECTED_FIRST_OUTPUT.md` as the output shape.

The human should use `FIRST_OUTPUT_ACCEPTANCE_CHECKLIST.md` to approve, request changes, or reject scope before you create files.

After approval, the first durable plan file should be:

```text
_reviews/open/private-simple-minimum-materialization-plan-YYYYMMDD.md
```

Do not create that file before approval unless the human explicitly asks you to write the plan into the target workspace.
