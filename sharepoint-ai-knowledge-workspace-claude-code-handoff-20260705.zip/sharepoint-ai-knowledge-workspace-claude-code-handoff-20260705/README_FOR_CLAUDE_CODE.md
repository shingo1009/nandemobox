# SharePoint AI Knowledge Workspace Claude Code Handoff

Generated: 2026-07-05

This package contains the design and operation documents needed to move the SharePoint AI Knowledge Workspace from design into practical setup and pilot validation.

## Current State

The design phase is coherent, but real operation is not complete yet.

Do not treat this as a finished production workspace. The next evidence order is:

1. Choose the pilot scenario.
2. Materialize a private Simple Minimum folder.
3. Run the pilot file consistency checklist.
4. Implement or simulate read-only `kw-maint doctor`.
5. Run one source-to-reviewed-to-patch sample.
6. Validate SharePoint / OneDrive behavior.
7. Only then consider a shared pilot.

## Read First

Read these files first, in order:

1. `docs/wiki/hot.md`
2. `docs/wiki/index.md`
3. `docs/wiki/projects/SharePoint AI Knowledge Workspace Project.md`
4. `docs/wiki/specs/SharePoint AI Knowledge Workspace.md`
5. `docs/wiki/specs/SharePoint AI Knowledge Workspace V0 Readiness Gate.md`
6. `docs/wiki/specs/SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix.md`
7. `docs/wiki/specs/SharePoint AI Knowledge Workspace Private Pilot Materialization Plan.md`
8. `docs/wiki/specs/SharePoint AI Knowledge Workspace Minimal CLAUDE Rules.md`
9. `docs/wiki/specs/SharePoint AI Knowledge Workspace Initial File Contents.md`
10. `docs/wiki/specs/SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan.md`
11. `docs/wiki/specs/SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix.md`

## Main Decision

The current recommendation is not to start a real shared pilot yet.

Start with private Simple Minimum materialization, then validate with files, Python doctor behavior, and SharePoint / OneDrive evidence.

## Important Boundaries

- Python should handle deterministic maintenance.
- Claude Code should handle semantic judgment and writing.
- Humans keep authority over official knowledge, archive, and deletion.
- `.raw` converted Markdown is source evidence, not active reviewed knowledge.
- Hard delete is rare and requires an admin plan.
- Root and project `official/` should be protected by patch-first workflow.

## Package Contents

- `docs/wiki/`: selected wiki pages and indexes.
- `CLAUDE_CODE_PROMPT.md`: prompt to give Claude Code before asking it to act.
- `EXPECTED_FIRST_OUTPUT.md`: the shape of the first planning response Claude Code should produce.
- `FIRST_OUTPUT_ACCEPTANCE_CHECKLIST.md`: human-side checklist for approving or rejecting Claude Code's first plan.
- `PACKAGE_MANIFEST.md`: file categories and intended use.

## What To Ask Claude Code Next

Use `CLAUDE_CODE_PROMPT.md`, then ask:

```text
このパッケージを読み、Private Simple Minimum folder materialization の具体的な作業計画を作ってください。まだ実ファイル作成はせず、対象パス・作成ファイル・検証手順・リスクを出してください。
```

Claude Code may use `EXPECTED_FIRST_OUTPUT.md` as the response template.

Use `FIRST_OUTPUT_ACCEPTANCE_CHECKLIST.md` before allowing Claude Code to create files.

Expected first artifact after human approval:

```text
_reviews/open/private-simple-minimum-materialization-plan-YYYYMMDD.md
```

Before approval, keep the plan in chat or draft form only.
