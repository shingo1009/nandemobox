# Package Manifest

Generated: 2026-07-05

## Start Here

- `README_FOR_CLAUDE_CODE.md`
- `CLAUDE_CODE_PROMPT.md`
- `EXPECTED_FIRST_OUTPUT.md`
- `FIRST_OUTPUT_ACCEPTANCE_CHECKLIST.md`
- `docs/wiki/research/SharePoint AI Knowledge Workspace Claude Code Handoff Intake Simulation.md`
- `docs/wiki/hot.md`
- `docs/wiki/index.md`
- `docs/wiki/specs/_index.md`
- `docs/wiki/research/_index.md`
- `docs/wiki/decisions/_index.md`
- `docs/wiki/projects/_index.md`

## Project Control

- `docs/wiki/projects/SharePoint AI Knowledge Workspace Project.md`
- `docs/wiki/specs/SharePoint AI Knowledge Workspace.md`
- `docs/wiki/specs/SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack.md`
- `docs/wiki/specs/SharePoint AI Knowledge Workspace V0 Readiness Gate.md`

## Pilot Setup

- scenario selection
- private materialization
- pilot file consistency
- pilot sample flow
- design freeze and open item disposition

## Workspace Files

- template pack
- initial file contents
- README draft
- minimal CLAUDE rules
- project mini-wiki structure and creation rules

## Python Maintenance

- maintenance automation boundary
- admin Python command set
- `kw-maint doctor` dry-run implementation plan
- `kw-maint doctor` acceptance matrix

## Governance

- operating flow
- lifecycle state machine
- article quality rubric
- raw converted Markdown source policy
- deletion and tombstone policy
- archive TTL policy

## Research And Simulation

Relevant simulations, audits, and validation protocols are included under:

- `docs/wiki/research/`
- `docs/wiki/decisions/`
- `docs/wiki/comparisons/`
- `docs/wiki/sources/`
