---
type: decision
title: "Admin Python First Maintenance"
status: proposed
created: 2026-07-05
updated: 2026-07-05
tags:
  - decision
  - maintenance
  - python
  - automation
  - token-budget
related:
  - "[[SharePoint AI Knowledge Workspace Project]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
---

# Admin Python First Maintenance

## Decision

Prefer admin-run Python automation for deterministic workspace maintenance.

Normal client PCs should not be expected to run maintenance jobs or spend Claude Code tokens on repeated workspace discovery. Claude Code should be reserved for work that needs semantic judgment, explanation, synthesis, article revision, or official patch drafting.

The initial runner can be Nishizawa's own PC as an administrator member.

## Rationale

Long-term use will fail if every client session has to rediscover the folder state, rebuild mental indexes, count notifications, inspect stale items, or check the same SharePoint / OneDrive conflicts.

Those jobs are mostly mechanical. Python can do them once from a trusted synced admin machine and produce narrow, reusable outputs that every later Claude Code session can read cheaply.

This accepts some Python-side complexity in exchange for:

- lower Claude Code usage on client PCs,
- fewer repeated token-heavy scans,
- more consistent README/index/digest maintenance,
- simpler normal-user onboarding,
- a clearer authority boundary between automation, AI judgment, and human decisions.

## Responsibility Split

| Layer | Owner | Examples |
|---|---|---|
| Deterministic scan and maintenance | Admin Python | inventory, frontmatter validation, link checks, generated index blocks, digest counts, conflict reports, weekly skeletons |
| Semantic judgment and writing | Claude Code | source extraction, article quality review, merge plans, weekly narrative, contradiction explanation, official patch drafts |
| Authority and rollout | Human curator | approve reviewed knowledge, apply official patches, decide common/shared content, approve write-mode automation |

## Operating Shape

Default flow:

```text
many users add or review files
  -> one admin PC runs Python maintenance
  -> Python writes or previews generated facts only
  -> Claude Code reads narrowed outputs when judgment is needed
  -> humans approve official or shared changes
```

V0 should start with no-write `kw-maint doctor`. Write mode can be added only for generated blocks after dry-run output is trusted.

## Consequences

Positive:

- Client-side Claude Code use stays narrow.
- Normal users do not need local Python maintenance.
- Repeated scan/index/digest work becomes consistent and cheap.
- Cloud-sync risks are easier to detect from one maintained runner.

Negative:

- The Python maintainer becomes a real component that needs tests and careful write boundaries.
- The admin runner needs a reliable local SharePoint / OneDrive sync state.
- If the admin run is skipped for too long, generated indexes and digests may become stale.

## Implementation Implications

- `kw-maint doctor` is the first required command.
- Daily and weekly profiles remain admin-only.
- Python should produce small reports, skeletons, and generated blocks that reduce what Claude Code must read.
- Python must not apply official patches, rewrite human prose outside generated blocks, archive files automatically, or make semantic merge decisions.
- Future client-side skills should be judged by whether they reduce user friction without duplicating admin Python work.

## Review Trigger

Revisit this decision if:

- the admin maintainer becomes a bottleneck,
- several users need independent offline maintenance,
- SharePoint / OneDrive sync makes admin-only maintenance unreliable,
- Python reports require Claude Code to reread broad folders anyway.
