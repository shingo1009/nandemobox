---
type: decision
title: "SharePoint OneDrive First Knowledge Workspace"
status: proposed
created: 2026-07-04
updated: 2026-07-04
tags:
  - decision
  - sharepoint
  - architecture
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Project]]"
---

# SharePoint OneDrive First Knowledge Workspace

## Decision

For the next design cycle, prioritize a SharePoint / OneDrive synchronized Markdown workspace over a GROWI + MCP server architecture.

## Rationale

The SharePoint / OneDrive path has a lower adoption barrier:

- It uses an existing internal sharing mechanism.
- It appears as local files to Claude Code.
- It avoids requiring every user to install or configure MCP.
- It avoids early WSL and server memory constraints.
- It lets the team validate knowledge lifecycle rules before adding heavier infrastructure.

## Consequences

Positive:

- Faster pilot.
- Easier individual onboarding.
- Markdown remains portable.
- Server migration remains possible later.

Negative:

- OneDrive sync conflicts must be handled explicitly.
- There is no built-in database workflow, approval UI, or access audit.
- File and folder conventions must do more governance work.
- Generated indexes may become stale unless regenerated.

## Guardrails

- `official/` is protected by convention and should eventually be protected by permissions.
- AI creates proposals and patches; it does not directly update official knowledge.
- Personal notes are opt-in shared knowledge, not surveillance data.
- `reviewed` is provisional and must be labeled as such when used as evidence.

## Review Date

Review this decision after the MVP can support one real project and at least two users.
