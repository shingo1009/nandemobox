---
type: decision
title: "SharePoint Workspace Evidence Track Order"
status: proposed
created: 2026-07-05
updated: 2026-07-05
tags:
  - decision
  - pilot
  - validation
  - python
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace Project]]"
  - "[[SharePoint AI Knowledge Workspace Objective Completion Audit]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
---

# SharePoint Workspace Evidence Track Order

## Decision

Use this default evidence order:

```text
1. Private Simple Minimum folder materialization
2. kw-maint doctor implementation against that folder
3. SharePoint / OneDrive real-environment validation
```

Do not add more V0 Claude skills before at least one of these tracks produces real evidence.

## Rationale

The design phase has produced enough tabletop evidence. The remaining uncertainty is not "what else should be designed?" but "what breaks when the design touches files, Python, and SharePoint?"

The order matters:

- A materialized private folder gives `kw-maint doctor` a real target.
- `kw-maint doctor` gives the admin a deterministic way to inspect the folder before deeper AI use.
- SharePoint / OneDrive validation is essential before team rollout, but it depends on external tenant behavior and should not block local proof unless cloud risk is the top concern.

## Track 1: Private Materialization

Purpose:

- prove the Simple Minimum Profile can exist as actual files,
- catch mismatch between template docs and real folder shape,
- run one local source-to-review or patch rehearsal.

Evidence:

- actual folder tree,
- actual README / `CLAUDE.md` / `_system` files,
- actual project mini-wiki,
- consistency checklist result,
- one traceable pilot source.

Use:

- [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]
- [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]

## Track 2: `kw-maint doctor`

Purpose:

- prove admin-run Python can reduce deterministic maintenance and client-side Claude Code scanning,
- validate `.raw`, tombstone, index, metadata, and conflict checks against actual files.

Evidence:

- `kw-maint doctor` dry-run output,
- fixture results from [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]],
- no-write guarantee,
- issue codes and exit codes.

Use:

- [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]
- [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]

## Track 3: SharePoint / OneDrive Validation

Purpose:

- prove cloud permissions, search, version history, local availability, path safety, and sync conflicts.

Evidence:

- protocol result per scenario,
- observed conflict filename patterns,
- confirmed search behavior,
- confirmed restore/version behavior,
- confirmed local-read behavior for Claude Code.

Use:

- [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]

## Alternative Orders

### Cloud-Risk-First

Use this if SharePoint tenant behavior is the largest unknown:

```text
1. SharePoint / OneDrive validation
2. Private materialization
3. kw-maint doctor
```

Tradeoff: validates the riskiest external substrate early, but may spend time on cloud behavior before the local folder shape is proven.

### Automation-First

Use this if the next priority is Python development:

```text
1. kw-maint doctor fixture implementation
2. Private materialization
3. SharePoint / OneDrive validation
```

Tradeoff: lets Python progress immediately, but fixtures may drift from the real pilot folder unless materialization follows quickly.

## Non-Goals

This decision does not:

- create the pilot folder,
- implement Python,
- run SharePoint validation,
- add new V0 skills,
- approve team rollout.

## Success Signal

The design can move from tabletop to pilot only when at least these are true:

- one actual Simple Minimum folder exists,
- `kw-maint doctor` can inspect it without writing,
- SharePoint / OneDrive behavior is validated enough for the intended pilot scope.

## Review Trigger

Revisit this order only if:

- SharePoint access is available now and tenant risk is the dominant blocker,
- Python implementation starts before any pilot folder can be created,
- actual materialization reveals the Simple Minimum Profile is still too heavy.
