---
type: index
title: "Decision Index"
status: evergreen
created: 2026-07-02
updated: 2026-07-05
tags:
  - index
  - decisions
---

# Decisions

Use this folder for architecture decisions, product tradeoffs, library choices, data model choices, and irreversible or expensive-to-change judgments.

## Foundation

- [[2026-07-02 API First MCP Second]]: keep FastAPI as the core system and MCP as the AI adapter.

## SharePoint Workspace Direction

- [[2026-07-04 SharePoint OneDrive First Knowledge Workspace]]: prioritize SharePoint / OneDrive synchronized Markdown before GROWI + MCP.
- [[2026-07-04 V0 Workspace Convention Choices]]: proposed conventions for accepted proposals, official patches, file naming, current user identity, and sync conflicts.
- [[2026-07-04 Official Folder Permission Protection]]: proposed convention-plus-permission protection for the `official/` folder.

## Skill And Documentation Surface

- [[2026-07-04 Markdown Playbooks Before Technical Skills]]: start with Markdown playbooks before implementing full technical skills.
- [[2026-07-04 Link Playbooks From CLAUDE Not README]]: link detailed playbooks from `CLAUDE.md` while keeping the README human-small.

## Maintenance And Evidence Order

- [[2026-07-05 Admin Python First Maintenance]]: prefer admin-run Python automation for deterministic maintenance so client PCs spend fewer Claude Code tokens.
- [[2026-07-05 SharePoint Workspace Evidence Track Order]]: default next evidence order is private materialization, then `kw-maint doctor`, then SharePoint / OneDrive validation.
