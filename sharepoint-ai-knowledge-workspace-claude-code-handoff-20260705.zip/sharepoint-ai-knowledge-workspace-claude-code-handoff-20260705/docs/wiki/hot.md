---
type: meta
title: "Hot Cache"
status: evergreen
created: 2026-07-02
updated: 2026-07-05T20:48:00+09:00
tags:
  - meta
  - hot-cache
related:
  - "[[index]]"
  - "[[overview]]"
  - "[[log]]"
---

# Recent Context

Navigation: [[index]] | [[overview]] | [[log]]

## Last Updated

2026-07-05. Refactored SharePoint workspace control pages and created a Claude Code handoff ZIP for practical pilot setup.

## Key Recent Facts

- Active project: [[SharePoint AI Knowledge Workspace Project]].
- [[index]] is short; detail lives in grouped indexes and [[log]].
- Main spec: [[SharePoint AI Knowledge Workspace]] is compact V0; [[SharePoint AI Knowledge Workspace Pilot Sample Flow]] shows source to review, notification, reviewed article, and official patch.
- Scenario selector: [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]. Default is note-only private rehearsal unless `.raw`, Python, SharePoint, common-candidate, or weekly-topic risk is intentionally tested.
- Future rehearsals should write `_reviews/open/pilot-evidence-YYYYMMDD.md` plus one short `_index/events/` pointer.
- Source placement: normal notes under `projects/sample-project/sources/`; converted Office/PDF Markdown under `projects/sample-project/.raw/{file_type}/`.
- Runtime: [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]] is active V0; [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]] is the compact startup contract.
- Maintenance boundary: Python handles deterministic admin maintenance; Claude Code handles semantic judgment and writing; humans keep official, archive, and deletion authority.
- First maintainer path is no-write: [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]], [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]], and [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]] keep daily/weekly/write profiles as expansion steps.
- Weekly/common loop is optional after real activity and must stay bounded, curator-reviewed, and non-automatic.
- Merge cleanup does not imply deletion. Default is supersede plus tombstone; hard delete requires admin plan, retention, backlink checks, and SharePoint alert care.
- Readiness gate says no shared pilot yet; evidence order remains private Simple Minimum materialization, file consistency, `kw-maint doctor`, then SharePoint / OneDrive validation.
- `.raw` remains source evidence, not the default user mental model or active article layer.
- Handoff ZIP: `exports/sharepoint-ai-knowledge-workspace-claude-code-handoff-20260705.zip` includes start-here docs, prompt, selected design pages, intake simulation, first-output template/checklist, and [[SharePoint AI Knowledge Workspace First Output Acceptance Dry Run]].
- Current audit: design/tabletop is strong, but real files, SharePoint/OneDrive, `kw-maint doctor`, and real article/weekly outcomes remain unproven.

## Recent Changes

- Refactored key specs, produced the handoff package, and dry-ran first-output acceptance.
- Updated log and hot cache.

## Active Threads

- Next default action: use the scenario selector, then private Simple Minimum folder materialization when the user explicitly asks to move from design to setup.
- During materialization, default to note-only workflow proof unless raw traceability, Python, or SharePoint risk is intentionally selected.
- After any real rehearsal, record scenario, environment, selected risk, source path, outputs, signals, checklist result, optional doctor output, result, and next step.
- After materialization: implement/run `kw-maint doctor` against the real folder.
- Then validate SharePoint / OneDrive behavior before team rollout.
- Keep entrypoints simple; use grouped indexes/log for detail.
