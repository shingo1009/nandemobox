---
type: spec
title: "SharePoint AI Knowledge Workspace Skill Consolidation Pass"
status: reference
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 2
tags:
  - spec
  - skills
  - simplification
  - consolidation
  - python
related:
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Skill Architecture]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]"
  - "[[SharePoint AI Knowledge Workspace Skill Surface Reaudit After Raw Tombstone Doctor]]"
---

# SharePoint AI Knowledge Workspace Skill Consolidation Pass

## Purpose

Record why the design moved from many Claude skills to a smaller runtime surface.

This page is the rationale. The active runtime boundary is [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]. The future capability map is [[SharePoint AI Knowledge Workspace Skill Architecture]].

## Consolidation Decision

```text
many specialized Claude skills
  -> 3 Claude behavior modes
  -> 1 admin Python maintainer
  -> human authority for irreversible actions
```

This keeps the system compact while still allowing growth after evidence.

## Sorting Rule

| Work Type | Home |
|---|---|
| mechanical, repeated, count-based, file-inventory-based | admin-run Python |
| judgment, synthesis, wording, source meaning, merge reasoning | Claude Code |
| official application, deletion, archive movement, sensitive policy | human curator |

Rule of thumb:

- Python keeps the workspace tidy.
- Claude Code makes knowledge meaningful.
- Humans decide what becomes official.

## Merge Map

| Earlier Capability | New Home |
|---|---|
| workspace navigation, daily triage, tombstone navigation | `workspace_navigator` |
| source extraction, proposal building, quality review, article merge planning, weekly narrative | `knowledge_steward` |
| patch drafting, same-target patch review, rollback note | `patch_reviewer` |
| current user resolution | `_system/users.md` and a small rule |
| sensitivity preflight | checklist plus SharePoint permissions |
| index maintenance, digest counts, stale reports, raw validation, conflict scans | `kw-maint` |
| duplicate/common-candidate discovery | Python candidate report plus Claude explanation |
| archive movement, hard deletion, official patch application | human curator procedure |

## Normal Week Check

| Moment | Minimal Runtime Behavior |
|---|---|
| Monday source addition | contributor adds project note; `knowledge_steward` extracts only when asked |
| Daily admin maintenance | `kw-maint` prepares indexes, counts, warnings, and dry-run reports |
| Midweek review | `workspace_navigator` starts from digest or `needs_action`, not the whole WIKI |
| Friday topic note | Python creates a skeleton; `knowledge_steward` writes a short curated narrative |
| Article integration | Python surfaces candidates; Claude drafts merge plan; human chooses outcome |

Result: repeated maintenance moves away from client Claude sessions, while meaning-heavy work remains available.

## What This Removes From V0

Do not start the first pilot with:

- separate `_system/skill_*.md` files,
- separate client skills for every personal workflow,
- automatic weekly distribution,
- automatic merge or archive movement,
- automatic patch application,
- automatic hard delete or tombstone cleanup,
- broad Claude scans as a normal entry path.

## Why This Still Covers The User Goals

- Article precision improves through `knowledge_steward`, the quality rubric, and human review.
- Notifications stay smooth because Python handles counts and Claude explains only the useful action.
- Scale pressure is handled by generated indexes, stale reports, conflict scans, and candidate reports.
- Common items across multiple WIKIs are surfaced as candidates, not automatically promoted to shared truth.
- Weekly topics remain a motivation layer only after real activity exists.
- Client Claude token use stays bounded because normal clients start from maintained views.

## Reopen This Decision When

- `CLAUDE.md` becomes too long to follow,
- one behavior is used often enough to deserve a stable playbook,
- reviewers cannot act without a separate checklist artifact,
- common-candidate reports produce repeated high-value shared articles,
- `kw-maint doctor` proves reliable enough for selected write mode,
- SharePoint / OneDrive validation exposes a client-side sync problem that Python cannot see centrally.

## Current Verdict

Keep V0 at:

```text
project WIKI Markdown
  + 3 Claude behavior modes
  + admin-run Python doctor
  + human authority
```

The latest raw/tombstone/doctor reaudit, [[SharePoint AI Knowledge Workspace Skill Surface Reaudit After Raw Tombstone Doctor]], did not justify adding new V0 Claude skills.
