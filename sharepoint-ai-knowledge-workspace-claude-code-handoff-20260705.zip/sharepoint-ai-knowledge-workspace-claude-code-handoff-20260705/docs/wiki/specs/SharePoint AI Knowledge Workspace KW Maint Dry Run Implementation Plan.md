---
type: spec
title: "SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - python
  - maintenance
  - dry-run
  - implementation-plan
related:
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
---

# SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan

## Purpose

Define the first no-write implementation slice for `kw-maint doctor`.

Acceptance fixtures, exit codes, and issue-code checks live in [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]].

## First Slice

Implement only:

```text
scan
validate
conflict-scan
raw-validate if .raw exists
rebuild-indexes --dry-run
doctor
```

No file writes. No reports. No archive moves. No deletion. No Claude calls.

## Questions It Must Answer

1. Does this folder look like the Simple Minimum Profile?
2. Which projects exist?
3. Which required files or folders are missing?
4. Which reviewed/generated files have metadata gaps?
5. Are there obvious OneDrive conflict filenames?
6. Are converted `.raw` Markdown files traceable to originals?
7. What would generated indexes contain if write mode existed?

## CLI Shape

Start with module execution:

```text
python -m kw_maint --root /path/to/workspace doctor
```

Optional wrapper later:

```text
kw-maint doctor --root /path/to/workspace
```

## Read Scope

Read only enough to inspect structure and metadata:

- root `README.md` and `CLAUDE.md`,
- `_system/users.md`,
- `_system/status_rules.md`,
- `_system/write_rules.md`,
- `_system/patch_rules.md`,
- `_index/by_project.md`,
- `_index/by_topic.md`,
- `_index/events/`,
- `_notifications/*/digest.md`,
- `_notifications/*/inbox/` names and frontmatter,
- `_reviews/open/` names and frontmatter,
- `_patches/open/` names and frontmatter,
- `projects/*/README.md`,
- `projects/*/_index.md`,
- `projects/*/{sources,notes,reviewed,official}/`,
- `projects/*/.raw/`,
- archive names only, if present.

Do not parse article bodies deeply in the first slice.

## In-Memory Model

Build a temporary model only:

| Object | Fields |
|---|---|
| `WorkspaceInventory` | root, projects, files scanned, users, indexes, issues |
| `ProjectInfo` | slug, path, required folders, README, `_index.md` |
| `MarkdownFileInfo` | path, frontmatter, status, project, owner, source_files, links |
| `PatchInfo` | path, target_file, status, risk |
| `Issue` | severity, code, path, message, suggested_action |

Do not persist a database.

## Checks

### Structure

- root `README.md` and `CLAUDE.md`,
- required `_system` files,
- `_index/by_project.md`, `_index/by_topic.md`, `_index/events/`,
- `_reviews/open/`, `_patches/open/`,
- at least one `projects/{project}/`,
- project `README.md`, `_index.md`, `sources/`, `notes/`, `reviewed/`, `official/`.

### Metadata

Warn when reviewed/generated knowledge lacks:

- `status`,
- `project`,
- `owner`,
- `source_files` when derived from source.

Source notes may warn, not block. Low-friction source intake matters.

### Raw Converted Markdown

Warn when converted `.raw` Markdown lacks:

- `original_file_path`,
- `original_file_name`,
- `original_file_type`,
- `converted_from`,
- `converted_at`.

Surface `conversion_warning` if present.

### Conflicts And Protected Paths

Warn on:

- `conflicted copy`,
- `競合`,
- `conflict`,
- conservative user/machine duplicate patterns,
- recent visible edits under `official/`, `_system/`, or `archive/`.

Do not decide whether the edit was authorized.

### Generated Blocks

Warn when:

- generated block timestamps are older than recent `_index/events/` or project changes,
- generated block markers are missing timestamps,
- generated markers are unbalanced.

Do not rewrite blocks.

### Tombstones

Warn when:

- tombstones appear in active generated index previews,
- tombstones lack `superseded_by`.

## Dry-Run Index Preview

Print intended sections for:

- `_index/by_project.md`,
- `_index/by_topic.md`,
- `projects/{project}/_index.md`.

Preview should show links and counts, not article bodies.

## Exit Codes

| Code | Meaning |
|---:|---|
| 0 | no blocking issues or warnings |
| 1 | warnings exist |
| 2 | blocking Simple Minimum structure issue |
| 3 | invalid command or root path |
| 4 | unreadable file or permission problem |

Bias toward warning unless the workspace cannot function as Simple Minimum.

## Output Format

Support plain text first.

Use stable issue codes and paths:

```text
[warning] raw_missing_original_file_path projects/sample/.raw/xlsx/vendor.md
```

JSON can come later.

## Non-Goals

The first slice does not:

- write generated blocks,
- write reports,
- parse all headings,
- detect semantic duplicates,
- convert binary files,
- generate weekly topics,
- apply patches,
- archive files,
- delete files,
- validate deletion plans,
- call Claude Code,
- require SharePoint APIs,
- require MCP.

## Done When

- `doctor` runs locally against a Simple Minimum folder,
- no files are modified,
- missing required structure is detected,
- metadata gaps are reported without blocking source intake,
- conservative sync-conflict patterns are reported,
- raw converted Markdown traceability gaps are reported,
- tombstones are omitted from active index previews,
- proposed index output is deterministic and compact.
