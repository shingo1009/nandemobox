---
type: spec
title: "SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - deletion
  - archive
  - sharepoint
  - maintenance
  - python
related:
  - "[[SharePoint AI Knowledge Workspace Archive TTL Policy]]"
  - "[[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]]"
  - "[[SharePoint AI Knowledge Workspace Article Integration Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
---

# SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy

## Purpose

Define how article merge, revision, supersede, archive, and deletion should work in a SharePoint / OneDrive Markdown workspace.

Deletion is not a normal Claude Code action. It is administrator-controlled maintenance.

## Core Rule

```text
Prefer supersede and tombstone before delete.
Hard delete is rare, explicit, and admin-approved.
```

Article integration should improve knowledge without surprising users with SharePoint deletion alerts or broken links.

## Merge Outcome Rules

| Integration Decision | Cleanup Result |
|---|---|
| `keep_separate` | no deletion; optionally explain difference |
| `cross_link` | no deletion; add proposed links |
| `merge_common_core` | create/choose common article; mark old articles `superseded`; leave tombstones |
| `revise_existing` | revise or patch one article; supersede clearly obsolete duplicates |
| `patch_official` | use official patch flow first; cleanup only after patch acceptance |
| `authority_conflict` | no deletion; route to curator |

Merge completion is not deletion permission.

## Default Lifecycle

```text
active
  -> merge_candidate
  -> superseded
  -> tombstone
  -> archive_candidate
  -> archived
  -> hard_delete_candidate
```

V0 usually stops at `tombstone` or `archive_candidate`.

## Tombstone Shape

Keep a short redirect at the old path:

```markdown
---
type: tombstone
status: superseded
superseded_by: "[[Replacement Article]]"
superseded_on: YYYY-MM-DD
owner: user-id
reason: merged_into_common_article
---

# This Article Was Replaced

Use [[Replacement Article]].
```

Tombstones are navigation aids, not duplicate articles. Generated active indexes should omit them by default.

## Deletion Authority

| Action | Authority |
|---|---|
| propose supersede/delete | Claude Code or human |
| mark `superseded` | curator/admin or owner-approved patch |
| create tombstone | curator/admin or approved patch |
| move to archive | admin after review |
| hard delete | admin only, with explicit plan |

Normal users and Claude Code should not hard delete shared articles.

## Admin Deletion Plan

Before archive or hard delete, create:

```text
_reviews/open/maint-deletion-plan-YYYYMMDD.md
```

Minimum fields:

- target file,
- replacement file,
- reason,
- owner or curator approval,
- known backlinks or references,
- SharePoint alert risk,
- retention period,
- proposed action: `keep_tombstone`, `archive`, or `hard_delete`,
- rollback path.

## Python Maintainer Role

Admin Python may report:

- superseded articles older than retention,
- tombstones missing `superseded_by`,
- active indexes that include tombstones,
- links pointing to superseded articles,
- deletion plans with missing fields,
- unsafe delete candidates.

Admin Python must not hard delete by default.

## Retention Defaults

| Item | Archive Review Timing |
|---|---:|
| superseded low-risk FAQ | 30 days |
| superseded reviewed article | 60 days |
| superseded official article | 90 days plus curator approval |
| tombstone with active backlinks | keep until links are updated |
| source evidence | no hard delete by default |
| converted `.raw` Markdown | no hard delete by default |

Hard delete has no automatic TTL.

## SharePoint Alert Care

If hard delete is unavoidable:

- batch deletions into a planned maintenance window,
- notify affected owners first,
- keep a deletion plan and event record,
- confirm recycle-bin/version-history expectations,
- update replacement links and indexes before deletion.

If deletion alerts are politically or operationally noisy, keep tombstones indefinitely and hide them from active generated indexes.

## V0 Position

V0 does not need an automated delete command.

V0 needs only:

- no direct hard delete by Claude Code,
- tombstone pattern,
- deletion plan shape,
- admin approval rule,
- later Python detection of unsafe deletion candidates.

See [[SharePoint AI Knowledge Workspace Article Integration Simulation]] for merge scenarios and [[SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation]] for raw-source traceability.
