---
type: spec
title: "SharePoint AI Knowledge Workspace V0 Operating Flow"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - operations
  - mvp
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[AI Review Notification]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Simplicity Optimization Pass]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
  - "[[SharePoint AI Knowledge Workspace Article Integration Simulation]]"
---

# SharePoint AI Knowledge Workspace V0 Operating Flow

## Purpose

Define the smallest operational flow worth testing before adding scripts, MCP, GROWI, or a custom service.

## V0 Success Definition

V0 succeeds if one pilot user can:

- Drop a meeting note or review memo into the relevant project mini-wiki.
- Ask Claude Code to extract reusable knowledge.
- Receive one useful notification or proposal.
- Accept, reject, or defer that item.
- Keep official knowledge protected.

The tighter success condition is:

```text
1件のナレッジが、安全に循環できること。
```

## Human-Facing Shortcut

Do not teach the full lifecycle first.

For a normal pilot user, the operating model is:

```text
1. Put a project note in the project WIKI.
2. Ask Claude to extract reusable knowledge.
3. Act only on `needs_action` notifications.
```

The full source, proposal, review, patch, and archive model exists so Claude and the curator can keep trust boundaries intact behind that simple user flow.

## Roles

| Role | Responsibility |
|---|---|
| Contributor | Places sources, personal notes, review records, and meeting notes. |
| Reviewer | Accepts, rejects, defers, or requests changes on proposals and patches. |
| Curator | Keeps indexes, notifications, stale proposals, and archive candidates healthy. |
| Claude Code | Extracts, compares, proposes, notifies, and drafts patches inside allowed folders. |
| Python helper | Admin-run deterministic maintenance for scan, validation, conflict scan, generated indexes, digests, and reports; starts dry-run and is not run by every client. |

## Flow 1: Daily Check

Trigger phrase:

```text
自分宛通知を確認して。
```

Steps:

1. Identify `current_user`.
2. Read `_notifications/{current_user}/inbox/`.
3. Read `_index/recent_changes.md`.
4. Summarize only actionable items first.
5. Group by status and severity: `needs_action`, `waiting`, `deferred`, then FYI/digest.
6. Ignore `resolved` and `superseded` items unless the user asks for history.
7. Ask before making any file changes.

Output:

- Short action summary.
- Suggested next action per item.
- No direct edits unless the user approves.

## Flow 2: Source To Extraction / Reviewed Candidate

Trigger phrase:

```text
このsourceから抽出してproposalを作って。
```

Steps:

1. Read the target source file, usually under `projects/{project_slug}/sources/` when project-specific.
2. Extract decisions, assumptions, risks, review points, FAQ candidates, and unresolved questions.
3. Check project `official/` and `reviewed/` first when a project is named, then root `official/` and `reviewed/` for cross-project overlap.
4. If the result is just a lightweight finding, write it as a review finding under `_reviews/open/` or as a project note.
5. If the knowledge is accepted after review, copy it into `projects/{project_slug}/reviewed/`.
6. If human judgment is needed, create notification in `_notifications/{owner}/inbox/`.
7. Record a lightweight event in `_index/events/`; avoid direct summary index edits unless curator-approved.

Acceptance guard:

- Do not move directly to `reviewed/` or `official/`.
- Preserve source evidence paths.
- Root `extracted/` and `proposals/` are expansion folders, not required for the first pilot.

## Flow 3: Proposal Review

Trigger phrase:

```text
このproposalをレビューして。
```

Steps:

1. Read proposal and source files.
2. Compare with `official/` and `reviewed/`.
3. Classify risk: low, medium, high.
4. Recommend one action: accept to `reviewed`, revise, reject, defer, or patch official.
5. If user approves acceptance, move or copy into `reviewed/` with review metadata.

Risk rule:

- Low-risk examples and FAQ can become `reviewed` after one reviewer.
- Procedures and checklists can become `reviewed` after one reviewer, but need owner review before `official`.
- Contract, security, authority, production incident, or compliance rules need explicit owner or multiple-person review.

V0 convention: copy accepted proposals into `reviewed/` and preserve the original proposal for traceability. See [[2026-07-04 V0 Workspace Convention Choices]].

## Flow 3b: Article Merge Or Revision

Trigger phrase:

```text
似た記事を統合できるか見て。
```

Steps:

1. Start from Python common-candidate output, a user-provided pair of articles, or a project `_index.md` cluster.
2. Compare source evidence, scope, owner path, risk, and intended user action.
3. Choose one decision: `keep_separate`, `cross_link`, `merge_common_core`, `revise_existing`, `patch_official`, or `authority_conflict`.
4. Write a short merge plan under `_reviews/open/` if a human decision is needed.
5. Keep project-specific deltas in project pages unless the shared core is clear.
6. Use official patch flow if protected official content must change.

Guard:

- Do not rewrite `reviewed/` or `official/` directly from a merge suggestion.
- Do not create a common article from contradictory authority rules.

## Flow 4: Official Patch

Trigger phrase:

```text
officialに反映すべき差分だけpatchにして。
```

Steps:

1. Read proposed source and target official file. For project-specific knowledge, the target is usually `projects/{project_slug}/official/...`.
2. Extract only the delta that belongs in official knowledge.
3. Create `_patches/open/patch-YYYYMMDD-topic.md`.
4. Include target file, reason, proposed change, source evidence, risk level, and reviewer needed.
5. Search existing `_patches/open/` files for the same target file.
6. Mark the patch `merge_required` if another open patch touches the same target or section.
7. Do not edit `official/`.

## Flow 4b: Official Patch Application

Trigger phrase:

```text
このpatchをofficialに適用して。
```

Steps:

1. Confirm the current user is curator or has owner approval.
2. Reread the current target official file.
3. Reread all open patches with the same target file.
4. Apply at most one patch at a time.
5. If another patch conflicts, mark or record it as `merge_required` or `superseded`.
6. Record a status event in `_index/events/`.
7. Notify affected patch owners.

Risk rule:

- Drafting patches can be distributed.
- Applying patches to `official/` must be serialized.

## Flow 5: Cleanup

Trigger phrase:

```text
古い通知とproposalを整理して。
```

Steps:

1. List stale notifications and proposals.
2. Group into resolved, rejected, deferred, stale, superseded, and needs-owner.
3. Apply [[SharePoint AI Knowledge Workspace Archive TTL Policy]] as review triggers, not automatic deletion rules.
4. Create an archive candidate review file when cleanup is non-trivial.
5. Ask before moving files.
6. Keep an audit note through `_index/events/`; curator can roll up `_index/recent_changes.md` later.
7. If multiple users are active, prefer `_index/events/` entries and curator rollup to avoid OneDrive conflicts.

## V0 Folder Boundary

Use the Simple Minimum Profile first:

```text
projects/{project_slug}/
_notifications/
_reviews/open/
_patches/open/
_index/
_system/
archive/
```

Root `sources/`, `extracted/`, `proposals/`, `reviewed/`, `official/`, and `people/` are expansion surfaces. Add them only when the first pilot proves the need.

Avoid full project-local workflow queues in V0. Use root `_notifications/`, `_reviews/`, `_patches/`, and `_system/`.

## Failure Signals

V0 is too complex if:

- Users ask where to place a note more than once.
- Users need the full lifecycle diagram before completing their first useful action.
- Claude reads too many files before answering.
- Notifications are mostly ignored.
- `needs_action` notifications are buried under FYI items.
- Proposals pile up without review.
- Multiple patches target the same official file without merge-required handling.
- People are afraid their personal notes will be corrected publicly.
- `official/` receives unreviewed edits.

## Next Design Questions

- When should the dry-run admin maintainer slice move from report-only mode to generated-block write mode?
- Should `reviewed/` notes eventually be promoted into `official/` by copy, patch, or direct edit after approval?
