---
type: spec
title: "SharePoint AI Knowledge Workspace Shared Skill Playbooks"
status: reference
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 2
tags:
  - spec
  - skills
  - playbooks
  - shared-workspace
related:
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Skill Architecture]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[SharePoint AI Knowledge Workspace Article Quality Rubric]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
---

# SharePoint AI Knowledge Workspace Shared Skill Playbooks

## Purpose

Record shared playbooks that may become `_system/skill_*.md` files later.

They are not active V0 runtime files. The active V0 boundary is [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]].

## V0 Decision

Do not create shared skill files by default in the first pilot.

Keep the runtime as:

```text
CLAUDE.md
  workspace_navigator
  knowledge_steward
  patch_reviewer

_system/
  users.md
  status_rules.md
  write_rules.md
  patch_rules.md
```

Admin Python handles generated indexes, counts, stale reports, conflict scans, raw validation, weekly skeletons, and common-candidate reports.

## Candidate Shared Playbooks

| Candidate | V0 Home | Promote When |
|---|---|---|
| `skill_workspace_navigator.md` | `workspace_navigator` section in `CLAUDE.md` | users repeatedly fail to find the right project/status |
| `skill_source_extractor.md` | `knowledge_steward` | extraction becomes frequent and the steps stabilize |
| `skill_proposal_builder.md` | `knowledge_steward` | many contributors create reusable proposals |
| `skill_article_quality_reviewer.md` | `knowledge_steward` plus rubric | reviewers need a standalone repeatable checklist |
| `skill_notification_router.md` | Python digest plus navigator/steward wording | notification lifecycle becomes noisy |
| `skill_patch_drafter.md` | `patch_reviewer` | patch volume or same-target collisions rise |
| `skill_index_maintainer_lite.md` | `kw-maint` | dry-run index reports prove trustworthy and write mode is approved |
| `skill_duplicate_conflict_detector.md` | Python candidate report plus steward explanation | common-candidate reports become high-signal |
| `skill_archive_curator.md` | Python stale report plus human decision | stale material creates real navigation pain |
| `skill_permission_sensitivity_guard.md` | checklist plus SharePoint permissions | incidents or restricted projects require stronger handling |

## Promotion Rule

Promote a shared playbook only when all are true:

- the behavior was used repeatedly in real pilot work,
- the steps are stable and short enough to document,
- keeping it in `CLAUDE.md` creates confusion,
- Python cannot handle the mechanical part more cheaply,
- the new playbook reduces lookup cost instead of adding another place to search.

## Shared Playbook Shape

If promoted, use this minimal shape:

```markdown
# Skill: [Name]

## When To Use

## Inputs

## Steps

## Allowed Writes

## Forbidden Actions

## Output Shape

## Escalate To Human When
```

No playbook should be longer than the workflow it simplifies.

## Explicit Deferrals

Do not promote in V0:

- automatic archive movement,
- automatic official patch application,
- automatic hard deletion,
- broad semantic duplicate search,
- permission automation beyond SharePoint permissions and checklists,
- notification generation for FYI-only noise.

## Current Verdict

The first pilot should prove the simple loop before adding shared skill files:

```text
navigate -> extract/review -> notify only when useful -> draft patch -> admin doctor
```

The old seven-playbook design is now an expansion shelf, not a startup requirement.
