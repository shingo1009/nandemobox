---
type: spec
title: "SharePoint AI Knowledge Workspace Template Pack"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - templates
  - workspace-setup
  - pilot
related:
  - "[[SharePoint AI Knowledge Workspace README Draft]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[SharePoint AI Knowledge Workspace Shared Skill Playbooks]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Sample Flow]]"
  - "[[SharePoint AI Knowledge Workspace Archive TTL Policy]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
---

# SharePoint AI Knowledge Workspace Template Pack

## Purpose

Define the initial template pack for a future SharePoint / OneDrive Markdown Knowledge Workspace.

This is a design artifact. It does not create the actual shared folder yet.

## Setup Principle

The initial pack should be small enough to copy into a new shared folder without making the workspace feel bureaucratic.

Use three layers:

1. Human entry files: `README.md`.
2. Agent operating files: `CLAUDE.md` and `_system/`.
3. Navigation, root workflow queues, and lightweight project mini-wikis: `_index/`, `_notifications/`, `_reviews/`, `_patches/`, root `official/`, and `projects/{project_slug}/`.

The first pilot should use the **Simple Minimum Profile** from [[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]].

The broader folder tree remains an expansion pack, not the mandatory first shape.

## Simple Minimum Folder Tree

```text
knowledge-workspace/
├─ README.md
├─ CLAUDE.md
├─ _system/
│  ├─ users.md
│  ├─ status_rules.md
│  ├─ write_rules.md
│  └─ patch_rules.md
├─ _index/
│  ├─ by_project.md
│  ├─ by_topic.md
│  └─ events/
├─ _notifications/
│  └─ {user}/
│     ├─ inbox/
│     └─ digest.md
├─ _reviews/
│  └─ open/
├─ _patches/
│  └─ open/
├─ projects/
│  └─ sample-project/
│     ├─ README.md
│     ├─ _index.md
│     ├─ .raw/        # optional but recommended when converted source Markdown is used
│     ├─ sources/
│     ├─ notes/
│     ├─ reviewed/
│     └─ official/
└─ archive/
```

## Expansion Folder Tree

```text
knowledge-workspace/
├─ README.md
├─ CLAUDE.md
├─ _system/
│  ├─ users.md
│  ├─ metadata_schema.md
│  ├─ status_rules.md
│  ├─ write_rules.md
│  ├─ permission_rules.md
│  ├─ notification_rules.md
│  ├─ patch_rules.md
│  ├─ archive_rules.md
│  ├─ skill_workspace_navigator.md
│  ├─ skill_source_extractor.md
│  ├─ skill_proposal_builder.md
│  ├─ skill_article_quality_reviewer.md
│  ├─ skill_notification_router.md
│  ├─ skill_patch_drafter.md
│  └─ skill_index_maintainer_lite.md
├─ _index/
│  ├─ recent_changes.md
│  ├─ official_index.md
│  ├─ by_project.md
│  ├─ by_topic.md
│  ├─ notification_summary.md
│  └─ events/
├─ _notifications/
│  └─ _template/
│     ├─ inbox/
│     └─ digest.md
├─ _reviews/
│  └─ open/
├─ _patches/
│  └─ open/
├─ .raw/
├─ sources/
│  └─ meetings/
├─ extracted/
├─ proposals/
├─ reviewed/
├─ official/
│  └─ README.md
├─ people/
├─ projects/
│  └─ sample-project/
│     ├─ README.md
│     ├─ _index.md
│     ├─ .raw/
│     ├─ official/
│     │  └─ external-interface.md
│     ├─ reviewed/
│     ├─ sources/
│     └─ notes/
└─ archive/
```

## Required Files For V0

For the Simple Minimum Profile:

| File | Required | Purpose |
|---|---:|---|
| `README.md` | yes | human onboarding |
| `CLAUDE.md` | yes | Claude Code operating contract |
| `_system/users.md` | yes | user IDs and aliases |
| `_system/status_rules.md` | yes | minimum lifecycle status definitions |
| `_system/write_rules.md` | yes | allowed and forbidden writes |
| `_system/patch_rules.md` | yes | patch-first official update rules |
| `_index/by_project.md` | yes | project navigation |
| `_index/by_topic.md` | yes | topic navigation |
| `_index/events/` | yes | append-only event files to reduce sync conflicts |
| `_notifications/{user}/inbox/` | yes for pilot users | action routing |
| `_notifications/{user}/digest.md` | yes for pilot users | low-priority notification rollup |
| `_reviews/open/` | yes | review findings and decisions |
| `_patches/open/` | yes | proposed changes to protected files |
| `projects/sample-project/README.md` | yes for pilot | project mini-wiki human entrypoint |
| `projects/sample-project/_index.md` | yes for pilot | project-local navigation and search keywords |
| `projects/sample-project/.raw/` | optional but recommended | converted Markdown source evidence from Excel, PowerPoint, and other original files |
| `projects/sample-project/official/external-interface.md` | yes for pilot | starter project official patch target |
| `projects/sample-project/sources/` | yes for pilot | source intake |
| `projects/sample-project/notes/` | yes for pilot | lightweight shared notes |
| `projects/sample-project/reviewed/` | yes for pilot | reviewed project knowledge |
| `projects/sample-project/official/` | yes for pilot | protected project knowledge |
| pilot file consistency checklist | yes before materialization | verifies README, `CLAUDE.md`, `_system/`, project mini-wiki, and scope alignment |

For the Expansion Pack:

| File | Required | Purpose |
|---|---:|---|
| `_system/metadata_schema.md` | optional after first pilot | frontmatter baseline |
| `_system/permission_rules.md` | optional before real team pilot | `official/` and protected area policy |
| `_system/notification_rules.md` | optional after notification volume grows | notification status, thread, digest, and stale rules |
| `_system/archive_rules.md` | optional after stale material appears | TTL review triggers and archive candidates |
| `_system/skill_*.md` playbooks | optional after operations stabilize | split out only behaviors that become too large for `CLAUDE.md` |
| `_index/recent_changes.md` | optional after event rollup begins | recent activity |
| `_index/official_index.md` | optional after official content grows | trusted knowledge index |
| `_index/notification_summary.md` | optional | useful once notifications exist |
| root `.raw/` | optional | cross-project converted Markdown source evidence |
| root `sources/`, `extracted/`, `proposals/`, `reviewed/` | optional | cross-project or behind-the-scenes workflow expansion |
| `official/README.md` | optional but useful | root official scope note; root official is only for cross-project knowledge |
| `_tools/maintenance/` or admin-local maintainer script | optional after first pilot | Python scan, validation, generated indexes, digest counts, and stale reports |
| project mini-wiki creation convention | yes before multiple projects | naming, owner, curator, status, and anti-sprawl rules |

## Deferred In V0

- `_commands/`: defer until operations stabilize.
- full project-scoped lifecycle folders: defer until multiple projects require independent queues.
- `_reviews/accepted` and `_reviews/rejected`: defer until review volume grows.
- `_patches/applied` and `_patches/rejected`: defer until patches are frequent.
- search database: defer until retrieval pain is proven.
- Python maintenance helper: can start earlier in admin dry-run mode if it reduces repeated Claude Code token usage and does not complicate the user-facing folder.

## Simple Minimum Creation Order

1. Create the folder tree.
2. Add `README.md`.
3. Add `CLAUDE.md`.
4. Add `_system/users.md`, `status_rules.md`, `write_rules.md`, and `patch_rules.md`.
5. Add `_index/by_project.md`, `_index/by_topic.md`, and `_index/events/`.
6. Add `_notifications/{pilot-user}/inbox/` and `digest.md`.
7. Add `_reviews/open/` and `_patches/open/`.
8. Add `projects/sample-project/` mini-wiki.
9. Add starter `projects/sample-project/official/external-interface.md`.
10. Add one pilot source from [[SharePoint AI Knowledge Workspace Pilot Sample Flow]] under the project mini-wiki:
    - use `projects/sample-project/sources/` for normal Markdown notes or low-friction source intake;
    - use `projects/sample-project/.raw/{file_type}/` for converted Markdown evidence from Excel, PowerPoint, PDF, Word, or similar original files.
11. Run [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]] against the intended files.
12. Run the manual V0 flow.

## Design Choices

- Link shared playbooks from `CLAUDE.md`, not from the root README.
- For the first pilot, prefer three consolidated Claude behaviors in `CLAUDE.md` over seven separate playbook files.
- Treat the Simple Minimum Profile as the default first pilot target.
- Treat the broader template as an expansion pack.
- Keep root `README.md` focused on three user actions: add project material, check notifications, and ask Claude Code for extraction.
- Mention useful Claude Code prompts in `README.md`, but keep skill internals, status tables, and detailed trust order in `CLAUDE.md` or `_system/`.
- Keep `_index/` files lightweight.
- Treat project mini-wikis as the main cloud-searchable project knowledge surface.
- Require project README files to show project state, last reviewed date, search keywords, owner, and curator.
- Create project mini-wikis through curator approval using [[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]].
- Keep root workflow queues centralized; do not duplicate `_notifications/`, `_reviews/`, `_patches/`, or `_system/` under every project in V0.
- Prefer append-only `_index/events/` files during normal user workflows; curator can roll up summary indexes.
- Prefer admin-run Python rollups for daily maintenance once the first safe loop is proven.
- Keep Python-generated content inside explicit generated blocks; do not regenerate README prose wholesale.
- Use [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]] as the implementation boundary before writing a real maintainer script.
- Treat `_system/` as curator-owned; most users should read it, not edit it.
- Treat notification status and patch status as first-class lifecycle signals, not comments hidden in prose.
- Allow multiple open patches for one `official/` target, but require same-target detection and serialized curator application.
- Treat archive as a curator-reviewed preservation action, not deletion or trash.
- Treat `.raw` converted Markdown as source evidence, not reviewed knowledge; see [[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]].
- Do not require `.raw/` for a normal note-only pilot; require raw traceability checks only when converted source Markdown is present.
- Treat [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]] as a design gate before any pilot folder is materialized.
- Use [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]] before creating any private pilot folder.

## Open Questions

- Should `_notifications/_template/` be copied per user manually, or generated later by a helper?
- Should `people/` contain per-user folders from the start or be created on demand?
- Should `_index/events/` rollup stay manual during V0, or move to `kw-maint` generated-block write mode after dry-run validation?
- Should the first maintainer script live outside the shared folder on the admin PC, or be stored later under `_tools/maintenance/` for transparency?
- Should patch status changes be written into patch files directly, or represented first as `_index/events/` status events when users lack permission to edit the patch file?
- Should archive candidate lists live in `_reviews/open/` or a later `_archive_candidates/` folder once volume grows?
- Should contributor-created `draft_project` folders be allowed in pilot, or should all project mini-wikis be curator-created?
