---
type: spec
title: "SharePoint AI Knowledge Workspace Pilot Sample Flow"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - pilot
  - sample-flow
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
---

# SharePoint AI Knowledge Workspace Pilot Sample Flow

## Purpose

Define the smallest sample flow that proves V0 without building extra tooling.

The pilot should show one thing clearly:

```text
A normal project source can become reviewed knowledge and an official patch without direct edits to official files.
```

## Scenario

Use a meeting note from an external interface design review.

This is a good first sample because it is common, reusable, and risky enough to test review and patch boundaries without using customer secrets or incident data.

## Input Source

Path:

```text
projects/sample-project/sources/2026-07-04_meeting_external-if-review.md
```

Minimal source body:

```markdown
# 外部IFレビュー会議メモ

## 背景

ベンダーから外部IF設計の説明を受けた。APIタイムアウト時の扱い、リトライ仕様、ログ出力、責任分界が曖昧だった。

## 決定事項

- APIタイムアウトは業務エラーではなく技術エラーとして扱う。
- タイムアウト発生時は同一リクエストIDをログに残す。
- リトライ回数と間隔はベンダー設計書に明記してもらう。

## 未決事項

- リトライ後も失敗した場合の業務通知方法。
- 一次切り分けを自社側とベンダー側のどちらが行うか。
- テスト工程でどこまで異常系を確認するか。
```

Optional frontmatter:

```yaml
---
title: "外部IFレビュー会議メモ"
type: meeting
project: sample-project
topics:
  - design-review
  - external-interface
status: source
owner: nishizawa
source_files: []
---
```

## Flow

| Step | Actor | Behavior | Output |
|---:|---|---|---|
| 1 | Human | Add source | `projects/sample-project/sources/...md` |
| 2 | Claude | `workspace_navigator` | Reads only root rules, project README/index, target source, and relevant official/reviewed pages. |
| 3 | Claude | `knowledge_steward` | Creates `_reviews/open/rev-20260704-external-if-review.md`. |
| 4 | Claude | `knowledge_steward` | Creates `_notifications/nishizawa/inbox/ntf-20260704-external-if-review.md`. |
| 5 | Human | Review | Approves, rejects, or requests changes. |
| 6 | Claude | `knowledge_steward` | If approved, creates `projects/sample-project/reviewed/external-if-review-checklist.md`. |
| 7 | Claude | `patch_reviewer` | Drafts `_patches/open/patch-20260704-external-interface-review-checklist.md`. |
| 8 | Admin/Python later | `kw-maint doctor` | Confirms structure, stale indexes, source trace, and protected write boundaries. |

No direct edit to `projects/sample-project/official/` happens during the sample.

## Review File Shape

`_reviews/open/rev-20260704-external-if-review.md` should contain:

```markdown
# Review: 外部IFレビュー観点

## Source

- `projects/sample-project/sources/2026-07-04_meeting_external-if-review.md`

## Extracted Knowledge

- 外部IF設計レビューでは、タイムアウト、リトライ、冪等性、ログ、責任分界を確認する。
- タイムアウトは業務エラーか技術エラーかを明確にする。
- 障害時に誰が一次切り分けを行うかを確認する。

## Review Verdict

- Verdict: patch_candidate
- Risk: medium
- Reason: 再利用できるが、責任分界は契約や案件で変わる。

## Suggested Next Step

Reviewed articleを作成し、official向けpatchでは「必ず」ではなく「確認する」と表現する。
```

## Notification Shape

`_notifications/nishizawa/inbox/ntf-20260704-external-if-review.md` should be action-oriented:

```markdown
# 通知: 外部IFレビュー観点の確認

## Action

外部IFレビュー会議メモから抽出した観点を reviewed article に進めるか確認してください。

## Related Files

- `projects/sample-project/sources/2026-07-04_meeting_external-if-review.md`
- `_reviews/open/rev-20260704-external-if-review.md`

## Options

- accept
- request changes
- defer
- reject
```

## Reviewed Article Shape

After human approval:

```markdown
---
title: "外部IFレビュー異常系チェックリスト"
type: article
project: sample-project
status: reviewed
owner: nishizawa
source_files:
  - "projects/sample-project/sources/2026-07-04_meeting_external-if-review.md"
reviewed_by:
  - nishizawa
---

# 外部IFレビュー異常系チェックリスト

外部IF設計レビューでは、正常系だけでなく以下を確認する。

- タイムアウト時の扱い。
- リトライ回数、間隔、終了条件。
- 同一リクエスト再送時の冪等性。
- 障害調査に必要なログ項目。
- 障害時の一次切り分け責任。
```

## Patch Shape

`_patches/open/patch-20260704-external-interface-review-checklist.md` should be short:

```markdown
# Patch: 外部IFレビュー観点の追加

## Target

`projects/sample-project/official/external-interface.md`

## Proposed Change

外部IFレビューの公式チェックリストに、タイムアウト、リトライ、冪等性、ログ、責任分界の確認観点を追加する。

## Risk

medium

## Approval

project owner or curator

## Source

- `projects/sample-project/reviewed/external-if-review-checklist.md`
```

## Success Signals

The sample succeeds when:

- the human knows where to place the source,
- Claude reads project-local files before broad workspace files,
- reviewed knowledge keeps source links,
- notification asks for a decision, not just awareness,
- official knowledge is changed only through a patch,
- `kw-maint doctor` can later inspect the result without needing semantic judgment.

## Not Proven Yet

This sample does not prove:

- large-workspace duplicate detection,
- multi-user patch contention,
- SharePoint permission enforcement,
- OneDrive conflict recovery,
- archive cleanup.

## Design Implication

If this sample feels heavy, remove outputs before adding automation. If it feels clear but repetitive, Python can later generate indexes, digests, and doctor reports around it.
