---
type: spec
title: "SharePoint AI Knowledge Workspace Private Pilot Materialization Plan"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - pilot
  - materialization
  - simple-minimum
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace Initial File Contents]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[SharePoint AI Knowledge Workspace Simple Minimum Final Consistency Review]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
---

# SharePoint AI Knowledge Workspace Private Pilot Materialization Plan

## Purpose

Define how to materialize a private Simple Minimum Profile pilot folder when the user explicitly asks to move from design to setup.

This page is a plan only. It does not create the folder.

## Materialization Principle

Materialize only the smallest structure that can prove one safe knowledge loop:

```text
one project source
  -> Claude extraction/review
  -> notification if needed
  -> reviewed knowledge or official patch
  -> event trace
```

Do not generate the Expansion Pack for the private pilot.

Before creating files, use [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]] to choose whether the first rehearsal is:

- note-only workflow proof,
- converted `.raw` source traceability proof,
- or a different evidence track because SharePoint or Python risk is dominant.

## Target Shape

Use the Simple Minimum Profile:

```text
knowledge-workspace/
├─ README.md
├─ CLAUDE.md
├─ _system/
│  ├─ users.md
│  ├─ status_rules.md
│  ├─ write_rules.md
│  └─ patch_rules.md
├─ _index/
│  ├─ by_project.md
│  ├─ by_topic.md
│  └─ events/
├─ _notifications/
│  └─ nishizawa/
│     ├─ inbox/
│     └─ digest.md
├─ _reviews/
│  └─ open/
├─ _patches/
│  └─ open/
├─ projects/
│  └─ sample-project/
│     ├─ README.md
│     ├─ _index.md
│     ├─ .raw/            # optional: only if converted Excel/PPTX/document Markdown is used
│     ├─ sources/
│     ├─ notes/
│     ├─ reviewed/
│     └─ official/
└─ archive/
```

## Explicitly Excluded

Do not create these in the first private materialization:

- root `sources/`,
- root `extracted/`,
- root `proposals/`,
- root `reviewed/`,
- root `official/` except a future placeholder if needed,
- `people/`,
- root `.raw/` unless the pilot source is cross-project converted evidence,
- `_system/metadata_schema.md`,
- `_system/permission_rules.md`,
- `_system/notification_rules.md`,
- `_system/archive_rules.md`,
- `_system/skill_*.md`,
- `_index/recent_changes.md`,
- `_index/official_index.md`,
- `_index/notification_summary.md`,
- `_tools/maintenance/`,
- full project-local workflow queues.

## File Content Sources

| Pilot File | Source Design Page |
|---|---|
| `README.md` | [[SharePoint AI Knowledge Workspace README Draft]] |
| `CLAUDE.md` | [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]], [[SharePoint AI Knowledge Workspace Initial File Contents]] |
| `_system/users.md` | [[SharePoint AI Knowledge Workspace Initial File Contents]] |
| `_system/status_rules.md` | [[SharePoint AI Knowledge Workspace Initial File Contents]] |
| `_system/write_rules.md` | [[SharePoint AI Knowledge Workspace Initial File Contents]] |
| `_system/patch_rules.md` | [[SharePoint AI Knowledge Workspace Initial File Contents]] |
| `_index/by_project.md` | generated or manually seeded from project README |
| `_index/by_topic.md` | generated or manually seeded from project keywords |
| `_index/events/README.md` | simple append-only event explanation |
| `_notifications/nishizawa/digest.md` | empty generated-block placeholder |
| project README and `_index.md` | [[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]] |
| project official starter | [[SharePoint AI Knowledge Workspace Pilot Sample Flow]] |
| project `.raw/` converted source, if used | [[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]] |

## Creation Sequence

1. Create the Simple Minimum folder tree in a private local or private SharePoint test area.
2. Add root `README.md`.
3. Add root `CLAUDE.md` with three consolidated Claude behaviors.
4. Add the four required `_system/` files.
5. Add `_index/by_project.md`, `_index/by_topic.md`, and `_index/events/README.md`.
6. Add `_notifications/nishizawa/inbox/` and `_notifications/nishizawa/digest.md`.
7. Add `_reviews/open/` and `_patches/open/`.
8. Add `projects/sample-project/` mini-wiki.
9. Add starter `projects/sample-project/official/external-interface.md`.
10. Choose the pilot source type using [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]:
    - if it is already Markdown or a low-friction note, add it under `projects/sample-project/sources/`;
    - if it is converted from Excel, PowerPoint, PDF, Word, or another original file, add the converted Markdown under `projects/sample-project/.raw/{file_type}/` with original-path frontmatter.
11. Run the consistency checklist against the actual files.
12. Run one manual knowledge loop.
13. Record the result in `_reviews/open/pilot-evidence-YYYYMMDD.md` using the evidence note template in [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]].

## Optional Raw Evidence Layer

Project `.raw/` is optional for the first private materialization.

Use it when the rehearsal source is a Markdown conversion of an original file, such as Excel or PowerPoint. In that case:

- create `projects/sample-project/.raw/{xlsx|pptx|other}/`,
- preserve `original_file_path`, `original_file_name`, `original_file_type`, `converted_from`, and `converted_at` in frontmatter,
- treat the converted Markdown as source evidence, not reviewed knowledge,
- have generated reviewed notes or patches cite the `.raw` path in `source_files`.

If the rehearsal source is a normal Markdown note, omit `.raw/` or leave it empty. The pilot should not require conversion automation.

## Consistency Checks Before Use

Run [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]] against the materialized files.

For Simple Minimum Profile:

- checks for `_system/users.md`, `status_rules.md`, `write_rules.md`, and `patch_rules.md` are mandatory,
- checks for `metadata_schema.md`, `permission_rules.md`, `notification_rules.md`, and `archive_rules.md` are optional and apply only if those files are created,
- no generated file should require seven `_system/skill_*.md` playbooks,
- `CLAUDE.md` should describe `workspace_navigator`, `knowledge_steward`, and `patch_reviewer`,
- Python maintenance may be referenced as admin-run future or dry-run work, but `_tools/maintenance/` is not required.

## Private Rehearsal Script

Use one non-sensitive source note.

Expected loop:

1. User adds source to `projects/sample-project/sources/`, or adds converted Markdown evidence to `projects/sample-project/.raw/` when the original is Excel, PowerPoint, PDF, Word, or similar.
2. Claude uses `workspace_navigator` to read only relevant files.
3. Claude uses `knowledge_steward` to extract source-backed review knowledge.
4. If accepted, reviewed content goes to `projects/sample-project/reviewed/`.
5. If official should change, Claude uses `patch_reviewer` to draft `_patches/open/...`.
6. An `_index/events/` file records the action.
7. User checks `_notifications/nishizawa/inbox/` if action is needed.

Success means the loop is traceable and understandable, not that all future automation exists.

## Evidence Capture

After the rehearsal, create one short evidence note:

```text
_reviews/open/pilot-evidence-YYYYMMDD.md
```

Minimum fields to capture:

- selected scenario,
- selected risk,
- environment,
- source path,
- reviewed output path if created,
- patch output path if created,
- event path,
- consistency checklist result,
- `kw-maint doctor` output path or note, if run,
- signals or issue codes,
- result: `pass`, `pass_with_notes`, or `blocked`,
- next step.

Add a short `_index/events/` entry that points to the evidence note. Keep the detailed evidence in `_reviews/open/` so shared indexes do not become large or conflict-prone.

## `kw-maint` Role During Private Pilot

The private pilot can run without `kw-maint`.

If `kw-maint` exists, use only dry-run commands first:

```text
kw-maint scan
kw-maint validate
kw-maint conflict-scan
kw-maint raw-validate
kw-maint rebuild-indexes --dry-run
```

Run `raw-validate` only if project or root `.raw/` exists. The command should report missing original-path or conversion metadata, but it should not convert, overwrite, move, or delete files.

Do not enable generated-block write mode until the dry-run output is understood.

Use [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]] before implementing or running the first helper.

## No-Go Conditions

Do not proceed from private materialization to real shared pilot if:

- actual SharePoint permissions are untested,
- version history and restore are unconfirmed,
- OneDrive files are not locally readable by Claude Code,
- project mini-wiki files are not searchable in SharePoint web,
- conflict file patterns are unknown and not accepted as a rehearsal risk,
- `official/` or project `official/` can be changed without patch awareness,
- converted `.raw` Markdown is used but does not preserve the original file path,
- users cannot identify their notification inbox.

## Exit Criteria

Private materialization planning is complete when:

- the intended folder tree is exactly the Simple Minimum Profile,
- every required file has a source design page,
- optional expansion files are intentionally excluded,
- project `.raw/` is either omitted or contains traceable converted Markdown source evidence,
- consistency checklist rules are Simple Minimum compatible,
- one private rehearsal source is selected,
- evidence note expectations are clear,
- the next action is either actual folder materialization, `kw-maint` dry-run implementation, or SharePoint validation.

## Recommendation

Materialize only after the user explicitly asks to move from design to setup.

Until then, keep this as the current build plan and avoid expanding V0.
