---
type: spec
title: "SharePoint AI Knowledge Workspace Migration Trigger Matrix"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - migration
  - roadmap
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Design Review]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Archive TTL Policy]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]"
---

# SharePoint AI Knowledge Workspace Migration Trigger Matrix

## Purpose

Define when the SharePoint / OneDrive Markdown workspace should evolve beyond manual Markdown playbooks.

This prevents premature engineering while preserving a clear path toward deterministic helpers, search, GROWI, MCP, or a custom service.

## Core Principle

Do not migrate because a tool is attractive. Migrate when a repeated operational pain is observed, or when a deterministic helper can remove repeated Claude Code token usage from every client without changing knowledge authority.

## Trigger Matrix

| Pain Signal | Threshold | Next Layer | Why |
|---|---:|---|---|
| Indexes are stale or expensive to update | curator spends more than 15 minutes/week on index rollup | admin-run Python helper | deterministic scan/index is cheaper than more human process |
| Client Claude sessions spend time rediscovering files | repeated sessions read broad folders just to answer basic navigation questions | admin-run Python generated indexes | central rollups reduce token usage on each client |
| README or project `_index.md` facts drift | generated facts are wrong twice in a week | Python generated blocks | preserve human prose while refreshing mechanical facts |
| Metadata gaps are common | more than 20% of new files miss owner/status/project/topic | Python helper | validation can suggest fixes without changing knowledge authority |
| Notification backlog keeps growing | users have more than 10 active `needs_action` or waiting items for 2 weeks | review queue helper | file inbox needs summarized queue views |
| Duplicate proposals appear repeatedly | 3 or more duplicate/conflict findings in one month | duplicate/conflict detector | semantic comparison becomes worth automating |
| Markdown search misses known content | users report failed lookup for existing knowledge 3 times/month | local search index | SQLite/BM25/vector index can improve retrieval while Markdown stays source of truth |
| Workspace exceeds comfortable manual scan | more than 500 active Markdown files | local search index and stronger generated indexes | navigation becomes the bottleneck |
| Cross-project common items are repeatedly missed | curator sees the same topic rediscovered in 3 or more project mini-wikis | weekly common-candidate loop, then local search index if needed | Python should narrow repeated patterns before Claude spends tokens on synthesis |
| Weekly progress is invisible to users | users ask "what changed?" or stop checking the workspace for 2 consecutive weeks | weekly topics skeleton plus curator-reviewed note | visible small progress helps adoption without broad automatic notifications |
| Multiple teams need different permissions | more than 2 teams with conflicting confidentiality needs | separate workspaces or SharePoint permission model | one folder risks permission drift |
| Users need browser-based contribution | non-technical users avoid Markdown/Claude Code | GROWI or web UI | add publishing/contribution surface after lifecycle is proven |
| AI clients need standard API access | multiple AI agents need consistent read/write operations | MCP or API adapter | expose controlled operations without making AI the authority |
| Official updates require audit-grade approvals | official changes need formal approval trace | custom service or workflow layer | Markdown conventions may not satisfy governance |
| OneDrive conflicts block work | sync conflicts occur weekly in protected or index files | helper plus stricter permissions, possibly service layer | file sync is becoming the wrong control plane |

## Layer Order

Recommended order:

```text
V0 Markdown conventions
  -> V0.5 admin-run deterministic maintenance helper
  -> V1 broader deterministic helper
  -> V2 review queue and duplicate/conflict support
  -> V3 local search index
  -> V4 web/UI or GROWI publishing layer
  -> V5 MCP/API/custom service
```

Do not skip directly to V4/V5 unless there is a real organizational constraint that V0 cannot test.

## What Each Layer Should Own

### V0.5 Admin-Run Deterministic Maintenance Helper

Owns:

- scan,
- metadata validation,
- generated index blocks,
- project `_index.md` generated sections,
- notification digest counts,
- stale item reports,
- event summary,
- conflict scan,
- dry-run diff.

Does not own:

- semantic approval,
- official edits,
- sensitivity judgment,
- human-facing README prose,
- archive moves.

Execution:

- run from one administrator or curator PC,
- initially Nishizawa's PC is acceptable,
- use dry-run before write mode,
- do not require normal users to run the helper,
- start with the first implementation slice in [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]].

### V1 Deterministic Helper

Owns:

- scan,
- index rollup,
- metadata validation,
- stale item report,
- event summary,
- scheduled admin-side maintenance.

Does not own:

- semantic approval,
- official edits,
- sensitivity judgment,
- human-facing README prose.

### V2 Review Operations Helper

Owns:

- review queue summary,
- notification digest summary,
- stale proposal list,
- duplicate candidate list.

Does not own:

- automatic promotion to official,
- automatic archive moves.

### V3 Local Search Index

Owns:

- fast lookup,
- BM25/vector retrieval,
- duplicate candidate support,
- "what changed recently" retrieval.

Does not own:

- canonical content; Markdown remains source of truth.

### V4 GROWI Or Web UI

Owns:

- browser-based reading,
- easier contribution for non-CLI users,
- publishing,
- possibly richer permissions.

Does not own:

- replacing the lifecycle until the Markdown workflow has proven stable.

### V5 MCP/API/Custom Service

Owns:

- controlled multi-agent operations,
- formal workflow state,
- stronger audit,
- integration with Teams/SharePoint/approval tools.

Does not own:

- bypassing human authority for official knowledge.

## Anti-Triggers

Do not migrate merely because:

- the folder tree looks unsophisticated,
- a server feels more professional,
- AI could theoretically automate it,
- one user dislikes Markdown,
- there are a few stale proposals in week one.

The design goal is adoption and clarity first.

## Decision Rule

Before adding a new technical layer, answer:

1. What repeated pain has been observed?
2. Which current Markdown rule failed to absorb it?
3. What is the smallest helper that fixes only that pain?
4. What authority remains with humans?
5. How will the helper write durable evidence back to the WIKI?

If those questions cannot be answered, stay in the Markdown layer.
