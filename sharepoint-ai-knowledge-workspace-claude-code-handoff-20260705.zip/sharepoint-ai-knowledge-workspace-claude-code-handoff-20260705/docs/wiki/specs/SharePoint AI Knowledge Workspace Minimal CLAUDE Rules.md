---
type: spec
title: "SharePoint AI Knowledge Workspace Minimal CLAUDE Rules"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - claude-code
  - operating-rules
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Initial File Contents]]"
---

# SharePoint AI Knowledge Workspace Minimal CLAUDE Rules

## Purpose

Draft the smallest useful root `CLAUDE.md` for the SharePoint / OneDrive Markdown workspace.

The goal is not a governance manual. The goal is to make Claude Code safe, narrow, and useful in the first pilot.

## Design Principle

Root `CLAUDE.md` should answer five questions quickly:

1. What is this workspace?
2. What should Claude read first?
3. What is trusted?
4. Where may Claude write?
5. What must Claude never edit directly?

Detailed starter file contents live in [[SharePoint AI Knowledge Workspace Initial File Contents]].

## V0 Required Rule Files

For the first pilot, `_system/` starts with four files:

- `_system/users.md`
- `_system/status_rules.md`
- `_system/write_rules.md`
- `_system/patch_rules.md`

Optional after evidence:

- `_system/metadata_schema.md`
- `_system/permission_rules.md`
- `_system/notification_rules.md`
- `_system/archive_rules.md`
- `_system/skill_*.md`

## Candidate Root `CLAUDE.md`

```markdown
# Markdown Knowledge Workspace Rules

## Purpose

This folder is a SharePoint / OneDrive synchronized Markdown knowledge workspace.

Humans add project notes, meeting notes, review results, source evidence, and reusable knowledge. Claude Code helps extract knowledge, create review files, route notifications, and draft official patches.

## Read Order

At startup, read:

1. `README.md`
2. `CLAUDE.md`
3. `_index/by_project.md`
4. `_index/by_topic.md`
5. `_notifications/{current_user}/inbox/` when the user is known

If the task names a project, read project-local files before broad workspace files:

1. `projects/{project_slug}/README.md`
2. `projects/{project_slug}/_index.md`
3. `projects/{project_slug}/official/`
4. `projects/{project_slug}/reviewed/`
5. `projects/{project_slug}/sources/` and `notes/` only as needed

## Trust Order

Use information in this order:

1. project `official/`
2. root `official/` if cross-project knowledge exists
3. project `reviewed/`
4. project `sources/`
5. project `notes/`
6. `_reviews/open/`, `_patches/open/`, and notifications as workflow state
7. archive only when explicitly needed

Always say when information is provisional, AI-generated, personal, superseded, or archived.

## Current User

If `{current_user}` is unknown, read `_system/users.md`.

If still uncertain, ask once before reading or writing personal notification folders.

## Claude Behaviors

Use three behavior modes:

1. `workspace_navigator`: choose the smallest useful project, index, notification, or file set.
2. `knowledge_steward`: extract source-backed knowledge, review quality, create reviewed candidates, and route notifications.
3. `patch_reviewer`: draft official patches, check same-target patches, and preserve human approval.

Do not create separate `_system/skill_*.md` files in V0 unless a repeated behavior becomes too large for this file.

## Write Rules

Claude may create or update:

- `_reviews/open/`
- `_notifications/{current_user}/inbox/`
- `_patches/open/`
- generated files under `_index/`
- `projects/{project_slug}/notes/`
- `projects/{project_slug}/sources/` when the user asks to place a source there
- `projects/{project_slug}/reviewed/` after human approval

Claude must not directly edit:

- root or project `official/`
- project `README.md`
- project `_index.md`
- `_system/`
- another person's personal folder
- `archive/`
- original source files

Protected changes require a patch in `_patches/open/`.

## Required System Rules

Read `_system/users.md` for user IDs.

Read `_system/status_rules.md` when setting or interpreting lifecycle status.

Read `_system/write_rules.md` before writing files.

Read `_system/patch_rules.md` before drafting or reviewing official patches.

## Minimum Safety Checks

Before creating review files, notifications, or patches:

1. Check whether the topic already exists in project `official/` or `reviewed/`.
2. Preserve source links.
3. Mark generated files with `generated_by: claude` when frontmatter is used.
4. Do not present unreviewed AI output as official policy.
5. For official changes, create a patch; do not edit official files directly.

## Admin Python Boundary

Admin-run Python may handle deterministic maintenance: scans, generated indexes, digests, stale reports, conflict checks, and `kw-maint doctor`.

Claude Code handles semantic judgment and writing. Humans keep authority over official knowledge, archive, and deletion.
```

## Optional Rule Files

Add optional `_system` files only after pilot evidence shows the need.

| File | Add When |
|---|---|
| `_system/metadata_schema.md` | Metadata drift becomes a real review cost. |
| `_system/permission_rules.md` | SharePoint permission behavior must be documented. |
| `_system/notification_rules.md` | Notification status and digest rules become too long for `CLAUDE.md`. |
| `_system/archive_rules.md` | Cleanup or retention begins. |
| `_system/skill_*.md` | One Claude behavior is repeated often and stable enough to promote. |

## Design Notes

- Keep `CLAUDE.md` a startup contract, not a policy book.
- Keep `_system` files narrow and mechanical.
- Treat missing metadata as a review finding, not a contribution blocker.
- Keep root `extracted/`, `proposals/`, `people/`, and broad root source folders deferred unless a scenario intentionally tests them.
- Prefer project-local search and project-local evidence first.

## Open Questions

- Should `current_user` have a tiny local config file, or stay user-confirmed?
- Should SharePoint permissions enforce `official/` read-only for most members from day one?
- Should review status live mainly in frontmatter or in `_reviews/open/` path conventions?
