---
type: spec
title: "SharePoint AI Knowledge Workspace Skill Architecture"
status: reference
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 2
tags:
  - spec
  - skills
  - agent-design
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]"
---

# SharePoint AI Knowledge Workspace Skill Architecture

## Purpose

This page is a capability map, not the active V0 runtime.

Use [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]] as the current runtime boundary. Use [[SharePoint AI Knowledge Workspace Skill Consolidation Pass]] for the reduction rationale.

## Current Runtime Answer

```text
3 Claude behavior modes
  + 1 admin Python maintainer
  + human authority
```

The three Claude behaviors are:

- `workspace_navigator`
- `knowledge_steward`
- `patch_reviewer`

They live inside `CLAUDE.md` for V0. They should not be split into many first-class skill files until real pilot evidence proves the need.

## Architecture Principle

Keep responsibility separated by kind of work:

| Work Kind | Owner |
|---|---|
| repeated scans, counts, index checks, stale reports, conflict scans | admin-run Python |
| reading route, source meaning, article quality, merge explanation, weekly narrative | Claude Code |
| official application, deletion, archive movement, sensitivity calls | human curator |

This keeps normal client PCs light and limits Claude Code token use.

## Capability Areas

These are the capability areas the workspace may need over time. In V0, they are covered by the three behaviors plus Python, not separate skill packages.

| Capability | V0 Home | Promote Later When |
|---|---|---|
| workspace navigation | `workspace_navigator` | users repeatedly fail to find the right project or status |
| daily personal triage | `workspace_navigator` plus Python digest | notification backlog becomes recurring |
| current user resolution | `_system/users.md` rule | multi-user ambiguity appears often |
| source extraction | `knowledge_steward` | extraction steps become long and stable |
| proposal building | `knowledge_steward` | many contributors draft proposals weekly |
| article quality review | `knowledge_steward` | reviewers need a repeatable checklist artifact |
| duplication/conflict detection | Python candidate report plus `knowledge_steward` | common-candidate reports become high-signal |
| notification routing | Python counts plus Claude wording | action routing needs stronger lifecycle threads |
| patch drafting | `patch_reviewer` | patch volume or same-target collisions rise |
| patch application | human curator procedure | permissions, rollback, and audit trail are proven |
| index maintenance | `kw-maint` | dry-run reports are consistently trusted |
| archive and stale cleanup | Python stale report plus human decision | stale material creates real navigation pain |
| sensitivity preflight | checklist and SharePoint permissions | incidents or restricted projects require stronger checks |
| raw converted Markdown care | `kw-maint raw-validate` plus `knowledge_steward` | raw conversion becomes frequent and varied |
| tombstone and deletion care | `kw-maint` report plus navigator/steward explanation | merge/deletion operations become common |
| weekly topics | Python skeleton plus `knowledge_steward` | weekly summaries improve return visits |

## Shared Versus Client-Side

Shared workspace rules should cover:

- lifecycle states,
- write boundaries,
- patch boundaries,
- user IDs,
- project WIKI conventions,
- generated index conventions.

Client-side behavior should stay small:

- resolve the current user,
- read that user's inbox,
- warn about local sync conflicts,
- help capture a personal source,
- run sensitivity preflight before sharing.

Do not require every client PC to run Python maintenance. That is an admin responsibility.

## V0 Non-Packaging Decision

Do not create these as active V0 files:

```text
_system/skill_workspace_navigator.md
_system/skill_source_extractor.md
_system/skill_article_quality_reviewer.md
_system/skill_notification_router.md
_system/skill_patch_drafter.md
_system/skill_index_maintainer.md
_system/skill_archive_curator.md
```

They remain expansion candidates. The first pilot should prove that simple project WIKI files, three Claude behaviors, and `kw-maint doctor` are enough.

## Promotion Rule

Promote a capability into a separate playbook or skill only when all are true:

- the behavior was used repeatedly in real work,
- the steps are stable enough to write down,
- keeping it inside `CLAUDE.md` makes the root instructions harder to follow,
- Python cannot do the deterministic part more cheaply,
- the new playbook reduces confusion instead of adding another place to look.

## Anti-Patterns

- one giant all-purpose knowledge manager skill,
- separate skill files before pilot evidence,
- normal users running maintenance Python,
- notifications without `needs_action` / FYI separation,
- weekly notes becoming another inbox,
- automatic merge, archive, hard delete, or patch apply,
- Claude scanning broad folders before narrowing,
- client-side behavior that guesses the user ID.

## Open Questions

- Which V0 behavior first becomes too large for `CLAUDE.md`?
- Which `kw-maint doctor` dry-run checks deserve admin-approved write mode?
- Does a weekly topic summary create useful return visits, or only more noise?
- Do common-candidate reports improve article integration enough to justify a shared common area?
- Does SharePoint / OneDrive sync behavior require a stronger client-side warning step?
