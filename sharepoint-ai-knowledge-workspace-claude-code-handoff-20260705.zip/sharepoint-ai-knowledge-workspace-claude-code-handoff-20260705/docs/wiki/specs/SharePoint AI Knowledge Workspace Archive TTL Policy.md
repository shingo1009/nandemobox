---
type: spec
title: "SharePoint AI Knowledge Workspace Archive TTL Policy"
status: draft
created: 2026-07-04
updated: 2026-07-04
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - archive
  - ttl
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Design Coverage Audit]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
---

# SharePoint AI Knowledge Workspace Archive TTL Policy

## Purpose

Define the V0 policy for stale proposals, resolved notifications, old reviews, patch records, and generated extraction files.

The goal is to prevent the shared folder from growing into an unreadable dump while avoiding unsafe automatic deletion or movement in a SharePoint / OneDrive synced environment.

## Core Principle

V0 uses archive candidates before archive moves.

Claude may identify stale material and write recommendations, but should not move or delete files unless the user explicitly approves the specific action.

For articles replaced by merge or revision, follow [[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]: prefer `superseded` status and a tombstone at the old path before any archive or hard delete.

## Lifecycle Statuses

Use these cleanup-related statuses:

| status | Meaning | Default Handling |
|---|---|---|
| active | still useful or pending | keep visible |
| waiting | blocked by another person or event | keep visible but lower priority |
| deferred | intentionally postponed | keep visible until review date |
| resolved | completed | hide from active triage; candidate for archive later |
| superseded | replaced by newer item | candidate for archive after trace is clear |
| tombstone | short redirect from old article to replacement | keep until links and users have migrated |
| rejected | explicitly not accepted | keep reason; candidate for archive later |
| stale | old and likely no longer useful | ask owner before archive |
| archive_candidate | ready for curator review | do not move automatically |
| archived | preserved only | ignore unless requested |

## Suggested TTLs

These are review triggers, not automatic deletion timers.

| Item Type | TTL Trigger | Default Action |
|---|---:|---|
| FYI notification | 14 days after creation | move into digest or mark resolved |
| resolved notification | 30 days after resolved | archive candidate |
| superseded notification | 14 days after superseded | archive candidate |
| superseded article | 60 days after replacement | archive candidate only after replacement and backlinks are clear |
| tombstone article | no automatic TTL | keep while backlinks, bookmarks, or SharePoint search hits may exist |
| proposal with no activity | 30 days | notify owner or mark deferred |
| deferred proposal | review date or 60 days | ask owner to renew, reject, or keep deferred |
| rejected proposal | 30 days after rejection | archive candidate if reason is recorded |
| open review finding | 30 days | notify owner/reviewer |
| resolved review finding | 60 days | archive candidate |
| open patch | 14 days | notify owner or curator |
| merge_required patch | 7 days | curator review needed |
| applied patch | 30 days after event recorded | archive candidate or keep in place for audit |
| extraction with no proposal | 60 days | archive candidate if source remains available |
| source material | no automatic TTL | keep unless owner requests archive |
| official material | no automatic TTL | never archive without explicit curator approval |

## Folder Policy

| Folder | Archive Behavior |
|---|---|
| `sources/` | keep by default; archive only with owner/curator approval |
| `extracted/` | archive candidates allowed after source remains available |
| `proposals/` | archive candidates allowed after reject, supersede, or stale review |
| `reviewed/` | archive only when superseded by official or newer reviewed note |
| `official/` | no automatic archive |
| `_notifications/` | resolved and superseded threads can become archive candidates |
| `_reviews/open/` | resolved findings can become archive candidates |
| `_patches/open/` | applied/rejected/superseded patches can become archive candidates |
| `_index/events/` | no archive in V0; event history is the audit trail |

## Cleanup Flow

```text
scan stale items
  -> classify status
  -> create archive candidate list
  -> ask owner or curator
  -> move only approved items
  -> write _index/events/ cleanup event
```

## Archive Candidate Record

Use a lightweight candidate list rather than immediately moving files:

```markdown
# Archive Candidates YYYY-MM-DD

## Candidate

- File: `proposals/prp-YYYYMMDD-topic.md`
- Current status: rejected
- Reason: rejected with reason recorded and inactive for 30 days
- Suggested action: archive
- Owner: user-id
- Approval needed: owner or curator
```

Suggested location:

```text
_reviews/open/rev-YYYYMMDD-archive-candidates.md
```

This keeps cleanup visible as a review task.

## Forbidden Actions

- Do not delete files automatically.
- Do not hard delete articles that were merely merged; use tombstones first.
- Do not archive `official/` automatically.
- Do not move source files if they are the only evidence for a reviewed or official claim.
- Do not archive another user's personal note without owner approval.
- Do not treat `archive/` as trash; archived material may still be evidence.

## Design Decision

V0 should prefer conservative cleanup. If the workspace grows enough that manual archive candidate review is painful, that is the trigger for a deterministic helper in V1. Even then, the helper should generate deletion or archive plans, not silently remove SharePoint files.
