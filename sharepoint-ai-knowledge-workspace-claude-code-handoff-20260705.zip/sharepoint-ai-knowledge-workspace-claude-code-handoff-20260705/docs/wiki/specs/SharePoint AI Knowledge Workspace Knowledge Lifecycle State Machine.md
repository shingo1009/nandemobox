---
type: spec
title: "SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - lifecycle
  - operations
  - state-machine
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Article Quality Rubric]]"
  - "[[SharePoint AI Knowledge Workspace Article Integration Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
---

# SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine

## Purpose

Define the knowledge lifecycle as a state machine so the SharePoint / OneDrive workspace can support contribution, review, revision, officialization, notification, and cleanup without relying on hidden chat context.

This page addresses the commit, modification, and circulation loop in file-based collaboration.

## Core Lifecycle

```mermaid
flowchart TD
    S["source<br/>sources/"] --> E["extracted<br/>extracted/"]
    E --> P["proposal<br/>proposals/"]
    P --> R["review open<br/>_reviews/open/"]
    R --> RV["reviewed<br/>reviewed/"]
    R --> RJ["rejected or deferred<br/>proposal status/event"]
    RV --> PT["patch open<br/>_patches/open/"]
    P --> PT
    PT --> MR["merge_required<br/>same target overlap"]
    MR --> PT
    PT --> AP["applied<br/>_index/events/ status"]
    AP --> O["official<br/>official/"]
    RJ --> AR["archive candidate<br/>archive/ later"]
    RV --> SP["superseded/tombstone<br/>old article path"]
    SP --> AR
    O --> S2["new source or change request"]
    S2 --> E
```

## State Definitions

| State | Folder Or Signal | Owner | Meaning |
|---|---|---|---|
| source | `sources/` | contributor | human-provided material |
| extracted | `extracted/` | Claude-assisted | structured extraction from source |
| proposal | `proposals/` | proposer or owner | candidate reusable knowledge |
| review open | `_reviews/open/` | reviewer | quality, duplicate, conflict, or risk review |
| reviewed | `reviewed/` | reviewer | provisional shared knowledge |
| patch open | `_patches/open/` | patch author | proposed change to protected official knowledge |
| merge required | patch status | curator | same-target overlap or conflict |
| applied | `_index/events/` status event | curator | official target was changed |
| official | `official/` | curator/owner | stable accepted common knowledge |
| rejected/deferred | proposal/review status event | reviewer | not accepted now |
| archive candidate | event or cleanup list | curator | old or resolved material ready for later cleanup |
| merge plan | `_reviews/open/article-merge-*.md` or `_reviews/open/article-revision-*.md` | reviewer/curator | proposed consolidation, cross-link, revision, or conflict decision |
| superseded/tombstone | old article path | curator/admin | article was replaced; old path remains as a redirect or explanation |

## Side Effects By Transition

| Transition | Required Side Effects |
|---|---|
| source -> extracted | preserve source path; write `_index/events/` event |
| extracted -> proposal | check similar `official/` and `reviewed/`; assign owner/reviewer |
| proposal -> review open | run [[SharePoint AI Knowledge Workspace Article Quality Rubric]] |
| review open -> merge plan | create a bounded merge/revision plan when multiple reviewed or proposed notes overlap |
| review open -> reviewed | copy accepted proposal; keep original proposal for traceability |
| reviewed -> merge plan | use when a reviewed article becomes stale, duplicated, contradicted, or too broad |
| proposal/reviewed -> patch open | include target file, target section, evidence, risk, approval |
| patch open -> merge_required | link same-target patches; notify curator or owner |
| patch open -> applied | reread current target and same-target patches; apply one patch only |
| applied -> official | write `_index/events/` status event; notify affected owners |
| rejected/deferred -> archive candidate | record reason; do not delete automatically |
| reviewed/official -> superseded/tombstone | link replacement article; keep old path readable; record event |
| superseded/tombstone -> archive candidate | use admin deletion plan; do not hard delete automatically |

## Notification Lifecycle

Notifications are not authoritative knowledge. They are attention-routing artifacts.

```mermaid
flowchart TD
    NA["needs_action"] --> W["waiting"]
    NA --> D["deferred"]
    NA --> RS["resolved"]
    W --> NA
    W --> RS
    D --> NA
    D --> RS
    NA --> SS["superseded"]
    W --> SS
    FYI["fyi"] --> DG["digest"]
```

Rules:

- `needs_action` is the only status that should interrupt the user.
- `fyi` should move toward digest when volume grows.
- `resolved` and `superseded` should not appear as active work.
- Notification state must not override proposal, patch, or official state.

## Commit And Revision Model

In this workspace, "commit" has two meanings:

1. Human decision commit: accept, reject, defer, patch, or apply.
2. File trace commit: event file, reviewed copy, patch file, or official edit.

V0 does not require Git commits for every knowledge change. The durable trace is:

- source file,
- extraction/proposal/review/patch files,
- `_index/events/` status events,
- preserved proposal history,
- official file after curator application.

Git can be added later for repository-style audit, but the workspace should not depend on Git literacy for daily users.

## Circular Improvement Loop

The healthy loop is:

```text
use official knowledge
  -> discover gap or outdated point
  -> add source or review finding
  -> create proposal or patch
  -> human decides
  -> update reviewed or official
  -> record event
  -> future Claude sessions read the improved state
```

## Article Integration Loop

When reviewed or proposed notes overlap across project mini-wikis, use this smaller loop before editing shared knowledge:

```text
Python candidate cluster
  -> Claude merge plan
  -> human decision
  -> cross-link, common reviewed note, revision, or official patch
```

Merge plan decisions:

- `keep_separate`,
- `cross_link`,
- `merge_common_core`,
- `revise_existing`,
- `patch_official`,
- `authority_conflict`.

Do not directly merge contradictory rules. Authority conflicts must go to curator review.

Do not delete old articles as part of the merge itself. Use [[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]] so SharePoint deletion alerts, backlinks, and user search paths are handled by an admin process.

## Failure Modes

| Failure | Signal | Correction |
|---|---|---|
| Proposal becomes de facto official | users cite `proposals/` as policy | reinforce trust order and status labels |
| Patch pileup | many same-target patches stay open | curator batches or marks merge-required |
| Reviewed duplicate pileup | similar reviewed notes grow across projects | create merge plan; keep common core separate from project deltas |
| False common article | project-specific rules are flattened | use `keep_separate`, `cross_link`, or `authority_conflict` |
| Notification drift | resolved items remain active | status-aware triage and digest cleanup |
| Index drift | `_index/*.md` stale | use `_index/events/` and curator rollup |
| Review fatigue | proposals wait forever | reject/defer path and stale proposal cleanup |
| Over-formalization | contributors stop adding sources | loosen metadata; keep source drop easy |

## Design Decision

V0 should treat lifecycle state as explicit file metadata plus event records, not as chat memory.

The system can remain simple if the only mandatory human behavior is:

- put sources in the right area,
- review action items,
- never directly edit `official/` without patch approval.
