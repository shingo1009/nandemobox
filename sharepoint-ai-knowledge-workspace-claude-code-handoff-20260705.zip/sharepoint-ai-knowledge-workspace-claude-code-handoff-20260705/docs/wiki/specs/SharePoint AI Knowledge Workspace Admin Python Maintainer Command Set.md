---
type: spec
title: "SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - maintenance
  - python
  - cli
  - automation
related:
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[2026-07-05 Admin Python First Maintenance]]"
---

# SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set

## Purpose

Define the admin-run Python command surface for the shared Markdown workspace.

Working name:

```text
kw-maint
```

This is a command reference. Responsibility boundaries live in [[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]. First implementation details live in [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]].

## Principle

- Dry-run first.
- Admin-run from one synced PC.
- Normal users do not run maintenance.
- Python produces narrow facts and reports.
- Claude Code handles meaning and narrative.
- Humans approve official, archive, and delete actions.

## V0 Required Command

```text
kw-maint doctor --root /path/to/workspace
```

`doctor` is read-only and should run:

- `scan`
- `validate`
- `conflict-scan`
- `raw-validate` when `.raw` exists
- `rebuild-indexes --dry-run`

This is the only required Python command for the first pilot packaging.

## Command Groups

### Read-Only Checks

| Command | Purpose |
|---|---|
| `scan` | inventory projects, files, statuses, owners, topics, links, mtimes |
| `validate` | report required-file, metadata, frontmatter, dead-link, and protected-path issues |
| `conflict-scan` | detect OneDrive conflict filenames and duplicated generated files |
| `raw-validate` | validate `.raw` converted Markdown traceability |
| `deletion-plan-check` | validate a curator-authored deletion plan before hard delete |
| `doctor` | run the V0 read-only readiness set |

### Generated Views And Reports

| Command | First Use | Writes |
|---|---|---|
| `digest` | V0.5 | generated digest blocks only |
| `rebuild-indexes` | V0.5 | generated index blocks only |
| `rollup-events` | V1 | generated activity view |
| `stale-report` | V1 | report only |
| `weekly-topics` | V1 | curator-facing skeleton |
| `common-candidates` | V1/V2 | report only |
| `deletion-candidates` | V1 | report only |

### Explicit Admin Actions

| Command | First Use | Boundary |
|---|---|---|
| `convert-source` | V1 | writes new converted Markdown under `.raw` only |
| `run --profile daily` | V1 | safe approved set only |
| `run --profile weekly` | V1 | weekly reports and skeletons only |

No command hard-deletes SharePoint files by default.

## Profiles

### Daily Dry Run

```text
kw-maint run --profile daily --dry-run
```

Includes:

1. `scan`
2. `validate`
3. `conflict-scan`
4. `raw-validate` if `.raw` exists
5. `digest`
6. `rebuild-indexes`
7. intended maintainer event preview

No semantic duplicate detection, archive movement, deletion, or official patch application.

### Weekly Dry Run

```text
kw-maint run --profile weekly --dry-run
```

Includes daily dry-run plus:

- `rollup-events`
- `stale-report`
- `weekly-topics`
- `common-candidates`

`deletion-candidates` may be added only as a report after tombstone and archive policy are accepted.

## Write Boundaries

Allowed after dry-run trust:

- generated blocks in index and digest files,
- generated reports under `_reviews/open/` or later maintenance reports folder,
- maintainer events under `_index/events/`,
- new `.raw` converted Markdown only for explicit `convert-source`.

Forbidden:

- human prose outside generated blocks,
- `official/`,
- project `official/`,
- `_system/`,
- source notes,
- existing `.raw` evidence without approved reconversion,
- archive moves,
- hard deletion,
- review decisions,
- patch application.

## Generated Block Contract

Generated blocks use explicit markers:

```markdown
<!-- AUTO:BY_PROJECT_START generated_by=kw-maint updated=YYYY-MM-DDTHH:mm:ss+09:00 -->
...
<!-- AUTO:BY_PROJECT_END -->
```

Rules:

- preserve everything outside markers,
- replace only matching marker bodies,
- fail if markers are unbalanced,
- include timestamp and command name.

## Report Contract

Reports are review inputs, not decisions.

Common report names:

- `maint-metadata-gaps-YYYYMMDD.md`
- `maint-conflicts-YYYYMMDD.md`
- `maint-stale-items-YYYYMMDD.md`
- `maint-raw-source-gaps-YYYYMMDD.md`
- `maint-weekly-topics-YYYY-Www.md`
- `maint-common-candidates-YYYYMMDD.md`
- `maint-deletion-candidates-YYYYMMDD.md`

Reports should use links, counts, reason codes, confidence bands, and sensitivity hints instead of copied content or long prose.

## First Implementation Slice

Implement only:

```text
scan
validate
conflict-scan
raw-validate if .raw exists
rebuild-indexes --dry-run
doctor
```

Acceptance criteria and fixtures live in [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]].

Do not enable `--write` until the dry-run output is trusted against real pilot files.

## Open Questions

- Should the command live outside the shared folder first, or under `_tools/maintenance/` after it stabilizes?
- Should generated reports stay under `_reviews/open/` or move to `_maintenance/reports/` later?
- Should accepted weekly topics be linked from digests after curator review?
- Should first parsing use only frontmatter and paths, or also headings?
- How should online-only OneDrive placeholders be reported?
