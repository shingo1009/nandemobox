---
type: spec
title: "SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - skills
  - runtime
  - simplification
  - pilot
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Skill Architecture]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]"
  - "[[2026-07-05 Admin Python First Maintenance]]"
---

# SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack

## Purpose

Define the smallest runtime surface for the first real pilot.

This is the active control page. Broader background lives in [[SharePoint AI Knowledge Workspace Skill Architecture]]. The reduction rationale lives in [[SharePoint AI Knowledge Workspace Skill Consolidation Pass]].

## V0 Runtime Decision

```text
project WIKI Markdown
  + 3 Claude behavior modes
  + 4 required _system rule files
  + admin-run Python doctor
  + human authority
```

Everything else is design material until real evidence proves it should be activated.

## Operating Principle

- Normal users read and write simple project WIKI files.
- Claude Code handles meaning only after the relevant scope is narrowed.
- Admin Python handles repeated mechanical checks.
- Humans decide official application, deletion, archive movement, and sensitive policy calls.

## Required Files

Minimum shared workspace files:

- `README.md`
- `CLAUDE.md`
- `_system/users.md`
- `_system/status_rules.md`
- `_system/write_rules.md`
- `_system/patch_rules.md`
- `_index/`
- `_notifications/`
- `_reviews/open/`
- `_patches/open/`
- `projects/{project_slug}/`

Project mini-wikis are required for useful SharePoint-side search. Root-level common knowledge is optional until repeated cross-project candidates prove it is needed.

## Claude Behavior Modes

| Behavior | Job | Reads | Writes |
|---|---|---|---|
| `workspace_navigator` | find project, status, notification, recent item, or tombstone destination | narrow index and target folders | normally no |
| `knowledge_steward` | extract, review, improve, merge-plan, weekly narrative, common-candidate explanation | starts narrow; broadens only with reason | allowed review/proposal/notification paths |
| `patch_reviewer` | draft or review official patch; detect same-target patches | target-specific | `_patches/open/` only unless curator applies |

These are behavior modes inside `CLAUDE.md`, not separate V0 skill files.

## Admin Python

First required command:

```text
kw-maint doctor
```

First slice:

- `scan`
- `validate`
- `conflict-scan`
- `raw-validate` when `.raw` exists
- `rebuild-indexes --dry-run`

Python owns deterministic maintenance: generated indexes, digest counts, stale reports, sync-conflict checks, raw metadata validation, tombstone exclusion from active indexes, common-candidate reports, and weekly topic skeletons.

Python write mode, scheduling, automatic conversion, automatic merge, and automatic deletion are not part of the first pilot.

## Persona Burden

| Persona | Required Habit | Should Not Need |
|---|---|---|
| Contributor | add a source or note under a project WIKI | Python, whole-workspace scan |
| Reviewer | start from `needs_action` notifications or review files | manual index rebuilding |
| Curator/Admin | run `kw-maint doctor`; approve official changes | automatic risky edits |
| Occasional Reader | search/read project WIKI in SharePoint | Claude Code |

## Submodes Stay Inside The Three Behaviors

| User Need | Runtime Home |
|---|---|
| "自分宛通知を確認して" | `workspace_navigator` |
| "このsourceから抽出して" | `knowledge_steward` |
| "この.raw変換MDから抽出して" | `knowledge_steward` plus Python raw validation |
| "このproposalをレビューして" | `knowledge_steward` |
| "似た記事を統合できるか見て" | Python candidate report plus `knowledge_steward` merge plan |
| "この古い記事の移行先を確認して" | `workspace_navigator` tombstone navigation |
| "今週のトピックをまとめて" | Python skeleton plus `knowledge_steward` narrative |
| "officialに反映すべき差分だけpatchにして" | `patch_reviewer` |

If one row becomes too long for `CLAUDE.md`, move it to a playbook only after pilot evidence.

## Explicit Non-Additions For V0

Do not add by default:

- separate Claude skills for each submode
- seven `_system/skill_*.md` files
- automatic weekly distribution
- automatic article merge
- automatic archive movement
- automatic hard delete or tombstone cleanup
- automatic raw conversion in daily maintenance
- MCP/API/service layer
- project-local review/patch/notification queues unless root queues fail

## Expansion Triggers

Add capability only when one of these is observed in a real pilot:

| Trigger | Possible Addition |
|---|---|
| users cannot find project information through SharePoint search | improve project mini-wiki index before adding search tech |
| notification backlog repeatedly hides urgent work | Python digest or thread compaction |
| same-target patches collide repeatedly | stronger patch queue report |
| common candidates recur across projects | root common-candidate review page |
| weekly note creates useful return visits | curated weekly summary flow |
| `CLAUDE.md` becomes too long for reliable use | split the specific behavior into one playbook |
| Python doctor catches frequent real issues | promote selected dry-run checks to admin-approved write mode |

## Fit Checks

Good V0:

- a new user can start from `README.md` and one project WIKI
- client Claude reads narrow files first
- admin Python absorbs repeated maintenance
- weekly/common-candidate work appears only after real activity
- official changes still require human authority

Too much:

- normal users must run Python
- every workflow has a separate skill
- weekly notes become a second inbox
- common pages contain many project-specific exceptions
- Claude scans broad folders before answering

Too little:

- `needs_action` is mixed with FYI
- official, reviewed, provisional, and raw content are unclear
- duplicate reviewed notes accumulate without merge plans
- indexes drift for more than a week
- same-target patches are not detected

## Next Proof

This page is not proven by design alone. The next evidence path remains:

1. private Simple Minimum materialization
2. `kw-maint doctor` against real files
3. SharePoint / OneDrive validation

Use [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]] before changing the runtime surface again.
