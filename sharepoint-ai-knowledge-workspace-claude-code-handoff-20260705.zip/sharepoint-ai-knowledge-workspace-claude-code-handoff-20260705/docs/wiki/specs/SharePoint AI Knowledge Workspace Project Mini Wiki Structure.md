---
type: spec
title: "SharePoint AI Knowledge Workspace Project Mini Wiki Structure"
status: draft
created: 2026-07-04
updated: 2026-07-04
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - information-architecture
  - project-wiki
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint Workspace Structure Options]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace V0 Design Freeze Checklist]]"
  - "[[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
---

# SharePoint AI Knowledge Workspace Project Mini Wiki Structure

## Purpose

Add the user's new requirement:

> Shared workspace content should be separated by project, and each project should behave like an independent WIKI, even if the structure is not complete.

The reason is practical: users should be able to search and investigate in the shared SharePoint area without first pulling everything to a local machine.

## Design Shift

Previous V0 direction:

- one global lifecycle structure,
- project stored mostly as metadata,
- project-scoped lifecycle folders deferred.

Updated direction:

- keep global `_system/`, `_notifications/`, `_reviews/`, `_patches/`, and `_index/events/`,
- add lightweight project mini-wikis under `projects/{project_slug}/`,
- do not duplicate the full lifecycle structure inside every project for V0.

This preserves the simple workflow while making cloud-side project search and browsing more natural.

## External Search Assumption

Microsoft Search in SharePoint can return sites, pages, and files, and only shows results the user has permission to see. This supports the idea that project mini-wikis should live as readable Markdown files in the shared area rather than only inside local-only working folders.

Reference:

- [Overview of Microsoft Search](https://learn.microsoft.com/en-us/microsoftsearch/overview-microsoft-search)

## V0 Project Mini-Wiki Shape

Use this minimal project structure:

```text
projects/
└─ project-slug/
   ├─ README.md
   ├─ _index.md
   ├─ .raw/
   ├─ official/
   │  └─ project-overview.md
   ├─ reviewed/
   ├─ sources/
   └─ notes/
```

Meaning:

| Path | Purpose |
|---|---|
| `README.md` | Human entrypoint for the project WIKI. Explains scope, owner, and where trusted knowledge lives. |
| `_index.md` | Project-local navigation, important links, search keywords, and current state. |
| `.raw/` | Converted Markdown source evidence from original Excel, PowerPoint, PDF, or document files. |
| `official/` | Project-specific trusted knowledge. Still patch-first and curator/owner protected. |
| `reviewed/` | Project knowledge reviewed by at least one human but not official. |
| `sources/` | Project-local source material that should be searchable in SharePoint. |
| `notes/` | Low-friction shared project notes that are not yet proposals or official knowledge. |

Do not add project-local `_notifications/`, `_patches/`, `_reviews/`, or `_system/` in V0 unless a real pilot proves the need.

## Root Versus Project Responsibilities

| Responsibility | Root Workspace | Project Mini-Wiki |
|---|---|---|
| Shared rules | yes | inherits root rules |
| User identity | yes | no |
| Notifications | yes | no |
| Review queue | yes | no |
| Patch queue | yes | no |
| Cross-project recent activity | yes | emits events |
| Project search surface | no | yes |
| Project official knowledge | optional shared/common only | yes |
| Project source material | optional intake | yes for project-specific sources |
| Converted source Markdown | optional cross-project `.raw/` | yes for project-specific `.raw/` |

## Read Order Update

When the task names a project:

1. read root `README.md`,
2. read root `CLAUDE.md`,
3. read `projects/{project_slug}/README.md`,
4. read `projects/{project_slug}/_index.md`,
5. read project `official/`,
6. then project `reviewed/`, `notes/`, and `sources/` as needed.

When the task is cross-project:

1. read root `_index/by_project.md`,
2. identify relevant project mini-wikis,
3. read only those project `_index.md` files first,
4. then drill into specific files.

## Write Rule Update

Claude may write project-specific generated work to:

- `projects/{project_slug}/notes/`,
- `projects/{project_slug}/.raw/` only when the user or admin explicitly asks to place converted source evidence there,
- `projects/{project_slug}/sources/` when the user asks to place a source there,
- `projects/{project_slug}/reviewed/` after approved review,
- root `_patches/open/` for official changes,
- root `_index/events/` for activity events.

Claude must not directly edit:

- `projects/{project_slug}/official/`,
- `projects/{project_slug}/README.md`,
- `projects/{project_slug}/_index.md`,
- root `_system/`,
- converted `.raw/` files unless explicitly asked to create or regenerate source evidence,
- another user's personal folders.

For project official changes, create a root patch file whose `target_file` points to `projects/{project_slug}/official/...`.

## Search-Oriented Metadata

Project mini-wiki files should include lightweight metadata, freshness hints, and search phrases in visible Markdown, not only YAML.

Recommended header:

```markdown
---
project: "project-slug"
status: reviewed
owner: "user-id"
topics:
  - "keyword"
---

# Human Title

Last reviewed: YYYY-MM-DD
Search keywords: keyword, synonym, project name, system name
```

Reason:

- SharePoint/Microsoft Search users may search by project name, topic, acronym, or business phrase.
- Visible keywords help humans and AI even when YAML handling is inconsistent across tools.
- Last reviewed dates help users judge whether project knowledge is current before asking for deeper validation.

## Template Impact

The root template should now include one sample project mini-wiki:

```text
projects/
└─ sample-project/
   ├─ README.md
   ├─ _index.md
   ├─ .raw/
   ├─ official/
   │  └─ project-overview.md
   ├─ reviewed/
   ├─ sources/
   └─ notes/
```

The existing starter official target can move from root `official/design-review/external-interface.md` to:

```text
projects/sample-project/official/external-interface.md
```

Root `official/` should remain for truly cross-project knowledge.

## V0 Scope Correction

This does not mean V0 should duplicate every lifecycle folder inside every project.

V0 includes:

- project mini-wiki shell,
- project-local converted source evidence under `.raw/`,
- project-local trusted and reviewed knowledge,
- project-local source browsing,
- root-level workflow queues.

V0 still excludes:

- full project-local `_system/`,
- project-local notification queues,
- project-local patch queues,
- project-local review queues,
- automated search database,
- GROWI/MCP/custom service requirement.

## Risks

| Risk | Mitigation |
|---|---|
| Folder sprawl | Require a curator-created project mini-wiki before adding a new project. |
| Cross-project duplication | Root `_index/by_project.md` and project `_index.md` should link related projects. |
| Confusion between root official and project official | Root `official/` is for shared/common knowledge; project `official/` is for project-specific trusted knowledge. |
| Permission mismatch | Validate project folder and `official/` permissions before team pilot. |
| Search result noise | Add visible search keywords and concise project indexes. |

## Creation Control

Use [[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]] before adding new project folders.

V0 recommendation:

- curator-created project mini-wikis,
- contributor-proposed project folders only as `draft_project`,
- root workflow queues stay centralized.

## Recommendation

Adopt lightweight project mini-wikis for V0.

Do not adopt full project-scoped lifecycle folders yet. The updated compromise is:

- project folders are the main cloud-searchable knowledge surface,
- root folders remain the shared workflow control plane.
