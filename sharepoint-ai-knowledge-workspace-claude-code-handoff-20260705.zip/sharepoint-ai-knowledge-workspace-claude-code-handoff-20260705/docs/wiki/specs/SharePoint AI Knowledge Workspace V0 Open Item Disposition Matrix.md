---
type: spec
title: "SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - open-items
  - design-freeze
  - pilot
related:
  - "[[SharePoint AI Knowledge Workspace Project]]"
  - "[[SharePoint AI Knowledge Workspace V0 Design Freeze Checklist]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
  - "[[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Dry Run]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Dry Run]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
  - "[[SharePoint AI Knowledge Workspace Simple Minimum Final Consistency Review]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
---

# SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix

## Purpose

Classify remaining V0 open items before design freeze.

This page prevents every uncertainty from becoming a new V0 feature. Each item must be handled as one of:

- `close_before_pilot`: resolve before a real shared pilot.
- `close_before_materialization`: resolve before generating or manually creating the pilot folder.
- `accept_for_private_rehearsal`: acceptable for a private or very small validation run, but visible as a known unknown.
- `defer_post_pilot`: do not solve in V0; revisit after observed usage.
- `remove_from_v0`: explicitly out of V0 scope.

## Current Verdict

The design is internally aligned for private materialization planning, but not ready for a real shared pilot.

The biggest close-before-pilot items are:

- SharePoint permission behavior,
- version history and restore,
- OneDrive local file availability for AI reads,
- `current_user` and notification folder setup,
- official patch serialization in the generated `CLAUDE.md` and `_system/patch_rules.md`.
- lightweight project mini-wiki creation and root-vs-project read/write rules.
- project mini-wiki searchability in SharePoint web.

## Disposition Matrix

| Item | Disposition | Why | Required Action | Evidence |
|---|---|---|---|---|
| SharePoint `official/` permission behavior | close_before_pilot | Direct official edits are the highest trust-boundary risk. | Validate with the permission boundary scenario. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| Version history and restore | close_before_pilot | Recovery must exist before official pages become important. | Confirm version history in the target library. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| OneDrive local file availability | close_before_pilot | Claude Code cannot operate reliably if files appear locally but content is unavailable. | Validate local AI reads and add first-run offline guidance if needed. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| `current_user` resolution | close_before_pilot | Notifications fail if users cannot identify their own inbox. | Keep `_system/users.md` required and make the README prompt explicit. | [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]] |
| Notification folder creation | close_before_pilot | A user cannot triage if their inbox does not exist. | Decide whether curator manually creates per-user folders for V0. | [[SharePoint AI Knowledge Workspace Template Pack]] |
| Patch serialization | close_before_pilot | Same-target official patches are expected, not rare. | Ensure patch rules require same-target reread before apply. | [[SharePoint AI Knowledge Workspace V0 Operating Flow]] |
| Starter official target | close_before_pilot | Patch drafting needs a real target file in the first pilot. | Keep `projects/sample-project/official/external-interface.md` in the template. | [[SharePoint AI Knowledge Workspace Template Pack]] |
| Simple minimum profile | close_before_materialization | The new source says V0 should prove one safe loop, not the full platform. | Treat broader root workflow folders and extra `_system` files as expansion surfaces, not first-pilot requirements. | [[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]] |
| Pilot file consistency | close_before_materialization | A simple README is only safe if `CLAUDE.md` and `_system/` retain the detailed rules. | Design artifacts passed with notes; rerun the checklist before generating or manually creating the pilot folder. | [[SharePoint AI Knowledge Workspace Pilot File Consistency Dry Run]], [[SharePoint AI Knowledge Workspace Simple Minimum Final Consistency Review]], [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]] |
| Project mini-wiki shell | close_before_pilot | Shared search should work by project without requiring local sync. | Add `projects/{project_slug}/README.md`, `_index.md`, `official/`, `reviewed/`, `sources/`, and `notes/`; validate with the project mini-wiki creation scenario. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| Root-vs-project trust order | close_before_pilot | Claude and users must know whether project `official/` or root `official/` wins. | Project official wins for project-specific questions; root official wins for cross-project common knowledge. | [[SharePoint AI Knowledge Workspace Project Mini Wiki Dry Run]] |
| Project mini-wiki creation convention | close_before_pilot | Without creation rules, `projects/` can sprawl quickly. | Require slug, owner, curator, state, README, index, curator approval, and validation through the protocol. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| Project mini-wiki SharePoint searchability | close_before_pilot | The new requirement exists so users can investigate project knowledge in the shared area before pulling files locally. | Validate project README, index, source, and official/reviewed discovery in SharePoint web for permitted users. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| Admin-run Python maintenance ownership | close_before_pilot | Long-term operation should not require every client to spend Claude Code tokens on mechanical index/digest work. | Decide admin runner, initial command set, dry-run/write mode, and schedule. | [[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]], [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]] |
| Maintainer dry-run implementation | accept_for_private_rehearsal | The private pilot can run without `kw-maint`, but the dry-run helper is the preferred way to reduce repeated manual checks. | Implement only `doctor`/dry-run first; no writes. | [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]] |
| Maintainer write-mode boundary | close_before_materialization | Python is useful only if it cannot mutate trusted prose, official content, sources, or archive. | Start with dry-run commands; enable writes only for generated blocks after review. | [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]], [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]] |
| File name and path safety | accept_for_private_rehearsal | The design can be tested privately while names are still conservative. | Validate before broader team pilot. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| Actual sync conflict filename pattern | accept_for_private_rehearsal | Exact pattern depends on tenant, OS, client, and timing. | Observe once and update scanner playbook. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| Notification digest threshold | accept_for_private_rehearsal | Thresholds need lived usage data. | Start with action-first triage, recalibrate after one week. | [[SharePoint AI Knowledge Workspace Notification Backlog Simulation]] |
| Article quality rubric weight | accept_for_private_rehearsal | The rubric is compact but may still feel heavy. | Apply to first pilot proposal and simplify if needed. | [[SharePoint AI Knowledge Workspace Article Quality Rubric]] |
| Archive TTL values | accept_for_private_rehearsal | TTLs are hypotheses until volume exists. | Treat TTLs as review triggers only. | [[SharePoint AI Knowledge Workspace Archive TTL Policy]] |
| Broader deterministic helper beyond dry-run maintainer | defer_post_pilot | The dry-run maintainer boundary is now defined; broader write-mode/search helpers should wait for evidence. | Revisit only after repeated index, metadata, retrieval, or review-queue pain. | [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]], [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]] |
| Local search or semantic search | defer_post_pilot | Search pain is not proven at V0 size. | Add only after retrieval failures cross threshold. | [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]] |
| GROWI or web UI | defer_post_pilot | A server UI would change the operating model too early. | Revisit if non-technical users cannot use Markdown folders. | [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]] |
| MCP/API service | defer_post_pilot | V0 explicitly avoids service dependency. | Revisit after deterministic helper and search prove insufficient. | [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]] |
| Full project-scoped lifecycle folders | defer_post_pilot | Project mini-wikis are needed, but duplicating all queues and system folders is too heavy for V0. | Keep root `_notifications/`, `_reviews/`, `_patches/`, and `_system/`. | [[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]] |
| Automatic Teams / SharePoint / Outlook crawling | remove_from_v0 | Too much security and noise risk for first validation. | Keep manual source capture only. | [[SharePoint AI Knowledge Workspace V0 Design Freeze Checklist]] |
| Automatic official edits by AI | remove_from_v0 | Contradicts patch-first trust boundary. | Keep official apply curator-only or owner-approved. | [[SharePoint AI Knowledge Workspace V0 Operating Flow]] |
| Automatic archive moves | remove_from_v0 | Cleanup without review can destroy auditability. | Keep archive candidates and curator approval. | [[SharePoint AI Knowledge Workspace Archive TTL Policy]] |
| Broad rollout to many users | remove_from_v0 | V0 needs small learning loops. | Use one curator, one contributor, one reviewer. | [[SharePoint AI Knowledge Workspace V0 Readiness Gate]] |

## Close-Before-Pilot Checklist

Before a real shared pilot, close these items:

1. `official/` permission behavior tested or explicitly downgraded to convention-only protection.
2. Version history and restore confirmed.
3. Required files are locally readable by Claude Code.
4. Every pilot user has a clear `_notifications/{user}/inbox/`.
5. `current_user` resolution is documented in `_system/users.md`.
6. Patch serialization rules are present in `CLAUDE.md` and `_system/patch_rules.md`.
7. Starter official target exists.
8. Project mini-wiki shell exists for the pilot project.
9. Root-vs-project trust order is documented in `CLAUDE.md`.
10. Project creation convention is documented before adding more than the pilot project.
11. Project mini-wiki searchability is validated in SharePoint web for permitted users.
12. Admin-run Python maintenance ownership and dry-run/write policy are decided for shared use.
13. Private pilot materialization plan is followed.
14. Pilot file consistency checklist passes before any folder is materialized.

If any item cannot close, the pilot can only proceed as a private rehearsal with the risk visible in the validation record.

## Accepted Known Unknowns For Private Rehearsal

These can remain open during a private rehearsal:

- exact sync conflict filename pattern,
- notification digest threshold,
- archive TTL calibration,
- article rubric friction,
- path length margin for future deeper folders.

Each accepted unknown must have an observation plan in [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]].

## Deferred Post-Pilot Backlog

Do not design these further until real usage produces evidence:

- broader Python helper beyond the dry-run maintainer slice,
- local or semantic search,
- GROWI/web UI,
- MCP/API service,
- full project-scoped lifecycle queues and system folders,
- automation around user folder creation,
- archive candidate dashboards.

## Removed From V0

These should not re-enter V0 unless the project scope is intentionally reopened:

- automatic source crawling,
- automatic AI official edits,
- automatic archive movement,
- broad team rollout,
- mandatory server-side platform,
- complex multi-person approval workflow.

## Design Freeze Implication

Private validation rehearsal can start after all `close_before_pilot` items are either:

- closed,
- converted into explicit private-rehearsal risks,
- or removed from the rehearsal scenario.

Real shared pilot cannot start until the close-before-pilot items are closed with evidence.

## Recommendation

Use this page as the change-control board for V0.

Any new idea should be added here before it is added to the template pack. If it cannot replace existing complexity or close a real validation risk, it belongs in post-pilot backlog.
