---
type: spec
title: "SharePoint AI Knowledge Workspace"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - sharepoint
  - ai-knowledge
related:
  - "[[SharePoint AI Knowledge Workspace Project]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
  - "[[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Objective Completion Audit]]"
---

# SharePoint AI Knowledge Workspace

## Problem

Project knowledge is scattered across meeting notes, review files, Office documents, personal notes, and ad hoc decisions. A server wiki or MCP-backed service may be useful later, but it is too much infrastructure for the first usable step.

The first step is a SharePoint / OneDrive synchronized Markdown workspace that humans can browse and Claude Code can operate safely.

## V0 Goal

Prove one safe knowledge loop:

```text
project source
  -> Claude extraction or review
  -> reviewed knowledge or official patch
  -> event trace
  -> pilot evidence note
```

The normal user mental model is:

```text
Project WIKI + Notifications + Official Patch
```

Anything beyond that is curator, admin Python, or Claude operating detail.

## V0 Non-Goals

- No MCP requirement for every user.
- No GROWI or custom web service requirement.
- No AI authority over official knowledge.
- No demand that every user fills perfect metadata.
- No broad weekly distribution, common-candidate merge, or source conversion automation before real evidence exists.

## Simple Minimum Profile

Use [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]] as the executable source of truth for the first folder.

V0 includes only:

- root `README.md`,
- root `CLAUDE.md`,
- `_system/users.md`,
- `_system/status_rules.md`,
- `_system/write_rules.md`,
- `_system/patch_rules.md`,
- `_index/by_project.md`,
- `_index/by_topic.md`,
- `_index/events/`,
- `_notifications/{user}/inbox/`,
- `_notifications/{user}/digest.md`,
- `_reviews/open/`,
- `_patches/open/`,
- `projects/{project_slug}/README.md`,
- `projects/{project_slug}/_index.md`,
- `projects/{project_slug}/sources/`,
- `projects/{project_slug}/notes/`,
- `projects/{project_slug}/reviewed/`,
- `projects/{project_slug}/official/`,
- optional `projects/{project_slug}/.raw/` for converted source Markdown.

The Expansion Pack exists only as a deferred design. Add it after observed friction, not because the folder could be more complete.

## Operating Rules

Trust order:

```text
official -> reviewed -> notes/sources -> .raw evidence
```

Write boundary:

- Claude may write notes, reviewed content after approval, notifications, patch drafts, reviews, and append-only events.
- Claude must not directly edit `official/`, project `official/`, `_system/`, project README, project `_index.md`, archive, or original source files.
- Official changes use `_patches/open/`.
- Normal actions should leave `_index/events/` entries instead of editing shared rollup indexes.

Source evidence:

- Normal Markdown sources go under `projects/{project_slug}/sources/`.
- Converted Excel/PPTX/PDF/Word Markdown goes under `projects/{project_slug}/.raw/{file_type}/`.
- `.raw` files remain source evidence, not reviewed or official knowledge.
- Derived articles cite `.raw` Markdown in `source_files`.

Lifecycle and status details live in [[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]], [[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]], and [[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]].

## Runtime Model

Use the compact runtime from [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]:

```text
workspace_navigator
knowledge_steward
patch_reviewer
```

Deterministic maintenance belongs to admin-run Python, starting with no-write `kw-maint doctor`:

```text
scan
validate
conflict-scan
raw-validate if .raw exists
rebuild-indexes --dry-run
```

Python should narrow what Claude Code needs to read. Claude Code should handle meaning, judgment, writing, review, and patch drafting.

## Evidence Gate

Before adding more V0 skills or expanding the folder set, produce real evidence.

Default evidence order:

```text
private materialization
  -> kw-maint doctor
  -> SharePoint / OneDrive validation
```

Use:

- [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]] to choose the scenario.
- [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]] to check files.
- [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]] to test Python.
- [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] to test SharePoint / OneDrive.

Every real rehearsal should write:

```text
_reviews/open/pilot-evidence-YYYYMMDD.md
_index/events/<short-event>.md
```

The evidence note records scenario, environment, selected risk, source path, outputs, signals, result, and next step.

## Expansion Triggers

Add more only when the pilot proves need:

| Trigger | Add Later |
|---|---|
| repeated manual index work | generated-block index writes |
| too many FYI notifications | stronger digest automation |
| multiple project overlaps | common-candidate reports |
| repeated article merges | formal merge/tombstone workflow |
| many converted Office files | explicit conversion command |
| weak SharePoint search | search index or service layer |

Use [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]] before adopting new tooling.

## Acceptance For The Next Phase

The design is ready to move from tabletop to private setup when:

- one evidence scenario is selected,
- the Simple Minimum folder is materialized,
- the consistency checklist is run against actual files,
- one source completes the loop or records a blocked evidence note,
- `kw-maint doctor` has a real or fixture target,
- SharePoint / OneDrive validation is still treated as required before team rollout.

Current status: design is strong, but real evidence is still missing. See [[SharePoint AI Knowledge Workspace Objective Completion Audit]].
