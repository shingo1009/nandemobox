---
type: spec
title: "SharePoint AI Knowledge Workspace Maintenance Automation Boundary"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - maintenance
  - automation
  - python
  - claude-code
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
  - "[[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]"
  - "[[2026-07-05 Admin Python First Maintenance]]"
---

# SharePoint AI Knowledge Workspace Maintenance Automation Boundary

## Purpose

Define the responsibility boundary between admin-run Python, Claude Code, and human authority.

This page is the boundary. Command details live in [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]. First implementation details live in [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]].

## Core Rule

```text
Python handles deterministic maintenance.
Claude Code handles semantic judgment and writing.
Humans keep authority over official knowledge.
```

The goal is to reduce repeated client-side Claude Code usage while keeping the shared workspace understandable.

## Responsibility Split

| Work | Owner | Reason |
|---|---|---|
| folder/frontmatter scan | Python | deterministic |
| generated index blocks | Python | reduces drift |
| metadata and required-file checks | Python | schema-like |
| OneDrive conflict filename checks | Python | mechanical |
| raw converted Markdown validation | Python | traceability check |
| notification counts and digest skeletons | Python | status/count rollup |
| stale proposal/review/patch reports | Python | file age and status |
| common-candidate evidence | Python first, Claude later | Python narrows; Claude explains |
| weekly skeleton | Python first, Claude later | facts first, narrative second |
| article quality, merge reasoning, contradiction explanation | Claude Code | semantic judgment |
| source extraction and proposal wording | Claude Code | meaning and writing |
| official patch drafting | Claude Code | source-backed writing |
| official application, archive movement, hard delete | human curator/admin | authority boundary |

## Execution Model

Default runner:

- one admin member's synced PC,
- initially Nishizawa's PC,
- dry-run first,
- normal users do not run maintenance,
- normal clients consume maintained views, reports, or narrow project WIKI files.

The Python side may be moderately complex if it removes repeated work from many client Claude Code sessions.

## Python May Write

Only these surfaces after dry-run trust is established:

- generated blocks marked with `<!-- AUTO:... -->`,
- generated reports under `_reviews/open/` or a later maintenance reports folder,
- digest/count rollups,
- maintainer event records under `_index/events/`,
- converted Markdown under `.raw/` only for explicit conversion commands.

## Python Must Not Write

- human prose outside generated blocks,
- `official/` or project `official/`,
- `_system/` rules,
- source notes,
- existing `.raw` evidence unless explicit reconversion is approved,
- review decisions,
- archive moves,
- hard delete operations.

## README And Index Strategy

README files should remain human-readable. Python may update only marked generated blocks.

Indexes should become generated views over files and `_index/events/`, but normal workflows should prefer append-only event records over competing edits to shared summary files.

## Safety Requirements

The maintainer must:

- default to dry-run until trusted,
- preserve manual text outside generated blocks,
- fail closed on unbalanced generated markers,
- report malformed frontmatter instead of guessing,
- report conflicts instead of fixing silently,
- use a lock or single-curator run convention,
- never apply official patches,
- never archive or delete automatically.

## Adoption Path

| Phase | Boundary |
|---|---|
| V0 private pilot | `kw-maint doctor` dry-run only |
| V0.5 | admin dry-run or approved generated-block write mode |
| V1 | scheduled admin run for indexes, digests, stale reports |
| V2 | retrieval-backed duplicate/common-candidate support; Claude still explains |

## First Helper Shape

The first helper should be boring:

```text
scan
validate
conflict-scan
raw-validate if .raw exists
rebuild-indexes --dry-run
doctor
```

No semantic AI maintainer, no automatic merge, no archive movement, no deletion.

## Current Verdict

Move deterministic maintenance to admin Python before adding richer server infrastructure or asking every client to spend Claude Code tokens on repeated scanning.

Keep Claude Code for judgment-heavy work and humans for irreversible authority.
