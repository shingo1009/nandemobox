---
type: spec
title: "SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - python
  - maintenance
  - acceptance
  - dry-run
related:
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
---

# SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix

## Purpose

Define the fixture-level acceptance contract for the first `kw-maint doctor`.

The command proves one narrow thing:

```text
An admin can run one read-only command and know whether the workspace is mechanically safe enough for human review or Claude Code follow-up.
```

This page should become test fixtures and expected-output assertions. Broader implementation design lives in [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]].

## Command

```text
kw-maint doctor --root /path/to/knowledge-workspace
```

Read-only internal checks:

```text
scan
validate
conflict-scan
raw-validate if .raw exists
rebuild-indexes --dry-run
```

No files are written.

## Exit Codes

| Exit | Status | Meaning |
|---:|---|---|
| 0 | `ok` | No warnings or blockers. |
| 1 | `warning` | Workspace is readable, but admin inspection is useful. |
| 2 | `blocking` | Simple Minimum structure is incomplete or unsafe. |
| 3 | `invalid_root` | The path is not a workspace root. |
| 4 | `unreadable` | A read or permission failure prevents inspection. |

Bias: warn rather than block unless V0 operation cannot function.

## Output Contract

Output is plain text first and stable enough for tests.

```text
KW-MAINT DOCTOR
Root: /path/to/knowledge-workspace
Status: warning

Summary:
- projects: 1
- files scanned: 42
- blocking: 0
- warnings: 3
- info: 2

Findings:
- [warning] raw_missing_original_file_path projects/sample/.raw/xlsx/vendor.md

Dry-run index preview:
- _index/by_project.md would list 1 project
- projects/sample/_index.md would omit 1 tombstone from active section
```

Every finding has:

- severity,
- stable issue code,
- target path,
- short suggested action when obvious.

The output must not copy article bodies. It only gives paths and concise evidence so Claude Code can continue narrowly.

## Required Fixtures

| Fixture | Exit | Required Finding | Acceptance Intent |
|---|---:|---|---|
| `simple_minimum_valid` | 0 | none | Baseline V0 folder passes. |
| `simple_minimum_with_raw_valid` | 0 | none | Converted Markdown source evidence passes when traced. |
| `bad_root_path` | 3 | `invalid_root` | Wrong folder is rejected clearly. |
| `missing_root_claude` | 2 | `missing_required_file` | Agent contract is absent. |
| `missing_project_index` | 2 | `missing_project_index` | Project mini-wiki cannot be navigated. |
| `missing_patch_rules` | 2 | `missing_required_system_file` | Official patch boundary is absent. |
| `source_missing_metadata` | 1 | `source_metadata_gap` | Loose source intake warns but does not block. |
| `reviewed_missing_source_files` | 1 | `reviewed_missing_source_files` | Reviewed article lacks evidence trace. |
| `reviewed_from_raw_missing_source_files` | 1 | `reviewed_missing_source_files` | Reviewed article derived from `.raw` lacks `.raw` path. |
| `raw_missing_original_path` | 1 | `raw_missing_original_file_path` | Converted Markdown cannot trace original file. |
| `raw_stale_conversion` | 1 | `raw_conversion_stale` | Original file appears newer than conversion. |
| `raw_conversion_warning` | 1 | `raw_conversion_warning` | Conversion may have dropped tables, images, or slide context. |
| `onedrive_conflict_file` | 1 | `sync_conflict_filename` | Conservative SharePoint or OneDrive conflict pattern is detected. |
| `recent_official_edit` | 1 | `protected_path_recent_edit` | Admin should confirm patch path was used. |
| `stale_generated_block` | 1 | `generated_block_stale` | Generated view may be stale after offline work. |
| `tombstone_in_active_index` | 1 | `tombstone_active_index_candidate` | Active index should not list superseded article as active. |
| `tombstone_missing_replacement` | 1 | `tombstone_missing_superseded_by` | Tombstone does not point to replacement. |
| `unsafe_deletion_plan` | 1 | `deletion_plan_unresolved_backlinks` | Hard-delete candidate still has unresolved links. |
| `expansion_folders_present` | 0 or 1 | no V0 failure merely for expansion folders | Future folders must not break V0. |
| `unreadable_file` | 4 | `unreadable_file` | Safety cannot be proven. |

## Baseline Fixture

`simple_minimum_valid` contains only the V0 required structure:

```text
README.md
CLAUDE.md
_system/users.md
_system/status_rules.md
_system/write_rules.md
_system/patch_rules.md
_index/by_project.md
_index/by_topic.md
_index/events/
_notifications/{user}/digest.md
_reviews/open/
_patches/open/
projects/sample/README.md
projects/sample/_index.md
projects/sample/sources/
projects/sample/notes/
projects/sample/reviewed/
projects/sample/official/
```

Expected result:

- exit `0`,
- deterministic dry-run index preview,
- no writes.

## Raw Evidence Fixture

`simple_minimum_with_raw_valid` adds:

```text
projects/sample/.raw/xlsx/vendor_checklist.md
projects/sample/reviewed/vendor_checklist_summary.md
```

The `.raw` Markdown frontmatter includes:

- `type: raw_converted_markdown`,
- `status: source`,
- `project`,
- `owner`,
- `original_file_path`,
- `original_file_name`,
- `original_file_type`,
- `converted_from`,
- `converted_at`.

The reviewed article includes `source_files` pointing to the `.raw` Markdown path.

Expected result:

- exit `0`,
- no `raw_*` warnings,
- `.raw` content appears only as source evidence,
- no writes.

## Warning Fixtures

Representative warning expectations:

| Fixture | Required Behavior |
|---|---|
| `reviewed_from_raw_missing_source_files` | Suggest adding the `.raw` converted Markdown path to `source_files`. |
| `raw_missing_original_path` | Warn that the conversion cannot trace the original file. |
| `raw_stale_conversion` | Suggest reconversion or review before article update. |
| `tombstone_in_active_index` | Preview active index without the tombstone; do not recommend deletion. |
| `unsafe_deletion_plan` | Suggest keeping tombstone or updating backlinks first. |

Warnings remain non-blocking unless the workspace cannot be read or the required V0 structure is broken.

## Must Not Do

`doctor` must not:

- write generated blocks,
- create reports,
- convert Office files,
- archive files,
- delete files,
- apply patches,
- call Claude Code,
- merge common candidates,
- treat `.raw` converted Markdown as active reviewed knowledge.

## Acceptance Gate

The first implementation is acceptable when every fixture has:

- deterministic exit code,
- stable issue code,
- stable target path,
- no file writes,
- concise human-readable output,
- enough paths for narrow Claude Code follow-up.

This keeps `kw-maint doctor` a safe first checkpoint, not a full maintenance platform.
