---
type: spec
title: "SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - pilot
  - validation
  - scenario
  - simple-minimum
related:
  - "[[2026-07-05 SharePoint Workspace Evidence Track Order]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Private Raw Evidence Rehearsal Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Evidence Capture Dry Run]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]"
---

# SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix

## Purpose

Choose the next pilot evidence scenario without reopening V0 design.

This page is a control surface, not a new feature. It keeps the next step compact by mapping the user's current question to one rehearsal path.

## Default Recommendation

If there is no stronger reason, choose:

```text
note-only private materialization
  -> kw-maint doctor
  -> SharePoint / OneDrive validation
```

Reason: the first proof should show that one ordinary project source can become reviewed knowledge or an official patch without making `.raw`, weekly topics, or multi-project discovery part of the user's first mental model.

## Scenario Matrix

| Scenario | Choose When | First Evidence | Do Not Include Yet |
|---|---|---|---|
| Note-only private rehearsal | Need the simplest workflow proof. | Actual Simple Minimum folder plus one source in `projects/sample-project/sources/`. | Converted `.raw`, weekly topics, multi-project common candidates. |
| Raw-converted private rehearsal | Need to prove Excel/PPTX/PDF/Word traceability or SharePoint text search value. | Converted Markdown under `projects/sample-project/.raw/` with original-path frontmatter and reviewed article citation. | Conversion automation, broad raw corpus scan, automatic article merge. |
| `kw-maint doctor` implementation | Need to prove admin Python can reduce repeated Claude Code scanning. | No-write output with fixture-backed issue codes. | Generated-block writes, conversion, deletion, patch application. |
| SharePoint / OneDrive validation | Tenant behavior is the riskiest unknown. | Permission, search, version history, local availability, filename, and conflict observations. | Team rollout, large source import. |
| Two-project common-candidate rehearsal | Need to test multi-WIKI common discovery after at least two project mini-wikis exist. | Curator-facing top-five common-candidate report with reason codes. | User-wide weekly distribution, automatic merge, direct notifications except `needs_action`. |
| Weekly topic rehearsal | Need to test motivation and reader attention after real content exists. | One weekly note capped at five topics and reviewed by curator. | Daily reminders, broad FYI notifications, unreviewed recommendations. |

## Choosing Rules

Use the narrowest scenario that answers the current risk:

| Current Risk | Pick |
|---|---|
| "Will a normal user understand the workflow?" | Note-only private rehearsal |
| "Will converted Excel/PPTX Markdown preserve enough evidence?" | Raw-converted private rehearsal |
| "Will client Claude Code sessions waste tokens scanning?" | `kw-maint doctor` implementation |
| "Will SharePoint permissions/search/sync behave?" | SharePoint / OneDrive validation |
| "Will project WIKIs reveal common topics?" | Two-project common-candidate rehearsal |
| "Will users keep reading this every week?" | Weekly topic rehearsal |

If two risks compete, pick the one that can produce real evidence with the least new machinery.

## Scenario Order Guardrail

Do not start common-candidate or weekly-topic rehearsals until at least one of these is true:

- two project mini-wikis exist with reviewed pages,
- or a small synthetic fixture exists specifically for `kw-maint` common-candidate dry-run tests.

Do not use `.raw` as the first scenario unless source traceability is the thing being tested.

Do not implement new Claude skills for any scenario. Use the existing three behaviors:

- `workspace_navigator`,
- `knowledge_steward`,
- `patch_reviewer`.

## Evidence Required Per Scenario

| Scenario | Minimum Evidence To Record |
|---|---|
| Note-only private rehearsal | Folder tree, source path, reviewed/patch output path, event path, checklist result. |
| Raw-converted private rehearsal | Raw path, original file path frontmatter, reviewed/patch `source_files`, `raw-validate` result if available. |
| `kw-maint doctor` implementation | Command, exit code, issue codes, no-write confirmation, fixture result. |
| SharePoint / OneDrive validation | Date, account, library path, observed behavior, pass/fallback, screenshot or note if useful. |
| Two-project common-candidate rehearsal | Input project pages, candidate list, reason codes, confidence band, curator decision. |
| Weekly topic rehearsal | Topic list, source links, intended readers, curator approval, reader feedback if available. |

## Evidence Record Location

When a real rehearsal runs, record the result in the pilot workspace:

```text
_reviews/open/pilot-evidence-YYYYMMDD.md
```

Also add one short event file under `_index/events/` so the activity is discoverable without reading the whole evidence note.

The evidence note should stay short. It is not a report for every detail; it is the proof bundle that tells the next Claude Code or human reviewer what was actually tested.

## Evidence Note Template

```markdown
---
type: pilot_evidence
status: open
scenario: note-only-private-rehearsal
environment: private-local | private-sharepoint-test | shared-sharepoint-pilot
selected_risk: workflow-understanding
owner: nishizawa
created: YYYY-MM-DD
source_files:
  - "projects/sample-project/sources/example.md"
result: pass | pass_with_notes | blocked
---

# Pilot Evidence YYYY-MM-DD

## Scenario

[one selected scenario from this matrix]

## Selected Risk

[why this scenario was selected]

## What Was Tested

- [short bullet]

## Evidence Paths

- Folder/root:
- Source:
- Reviewed output:
- Patch output:
- Event:
- Doctor output:

## Signals

- [issue code, warning, or important pass signal]

## Result

[pass, pass_with_notes, or blocked]

## Next Step

[one concrete next step]

## Notes

- [only the friction that should affect the next step]
```

Use `pass_with_notes` when the loop works but the design or tooling should be adjusted before team rollout.

Use `blocked` only when the selected scenario cannot produce its minimum evidence.

Use `next_step` to say whether the next action is repair, `kw-maint doctor`, SharePoint validation, or a new rehearsal.

## Stop Conditions

Stop and revise before expanding if:

- a normal note-only rehearsal feels too hard to explain,
- `.raw` appears in user-facing views as if it were reviewed knowledge,
- `kw-maint doctor` output is too verbose for an admin to act on,
- SharePoint search surfaces raw evidence without project README or reviewed pages giving context,
- weekly topics create notification pressure instead of motivation,
- common-candidate output implies automatic merge authority.

## Recommended Next Scenario

Current default: note-only private rehearsal.

Alternate: raw-converted private rehearsal, only if the next selected source is an Excel, PowerPoint, PDF, Word, or similar file whose Markdown conversion value should be tested immediately.

All other scenarios should wait for either actual pilot files or a deliberately small Python fixture.
