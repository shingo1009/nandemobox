---
type: spec
title: "SharePoint AI Knowledge Workspace First Output Acceptance Checklist"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - handoff
  - checklist
  - claude-code
related:
  - "[[SharePoint AI Knowledge Workspace Expected First Claude Code Output]]"
  - "[[SharePoint AI Knowledge Workspace Claude Code Handoff Intake Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
---

# SharePoint AI Knowledge Workspace First Output Acceptance Checklist

## Purpose

Check whether Claude Code's first plan after reading the handoff ZIP is safe to approve.

This is a human-side gate. It does not validate the real workspace yet.

## Decision Options

| Decision | Meaning |
|---|---|
| `approve_to_materialize` | The plan is narrow, concrete, and safe enough to create the private pilot folder. |
| `request_changes` | The plan is directionally right but missing required details or guardrails. |
| `reject_scope` | The plan expands beyond V0 or starts shared rollout too early. |

## Must Pass

Approve only if all are true:

- The plan says shared rollout is not ready.
- The plan asks for or states a concrete target path before file creation.
- The plan starts with private Simple Minimum materialization.
- The default scenario is note-only unless `.raw`, Python, or SharePoint risk is intentionally selected.
- The plan creates only the Simple Minimum folders and files.
- The plan uses three Claude behaviors, not many new skill files.
- The plan keeps official changes patch-first.
- The plan keeps deletion out of scope.
- The plan treats `.raw` as source evidence, not active reviewed knowledge.
- The plan includes file consistency checking before use.
- The plan includes one evidence note after rehearsal.
- The plan treats `kw-maint doctor` as read-only.

## Required Details

The plan should name:

- target path,
- environment: local private folder or private SharePoint test folder,
- curator,
- pilot project slug,
- first scenario,
- files/folders to create,
- initial content sources,
- validation checklist,
- expected `kw-maint doctor` behavior,
- open questions.

## Red Flags

Request changes or reject if the plan:

- creates a shared team workspace immediately,
- starts with SharePoint permission changes,
- creates MCP, database, service, UI, or root automation,
- creates `_system/skill_*.md` by default,
- creates root `sources/`, `extracted/`, `proposals/`, `reviewed/`, `official/`, or `people/` by default,
- writes to `official/` directly,
- deletes, archives, or moves articles automatically,
- treats weekly/common-candidate distribution as V0 required,
- runs write-mode Python maintenance before dry-run evidence,
- skips the pilot file consistency checklist,
- lacks a human approval point before file creation.

## Approval Note Template

```markdown
# First Output Acceptance

Decision: approve_to_materialize / request_changes / reject_scope

Reason:
- ...

Required changes before approval:
- ...

Approved target path:
- ...

Approved scenario:
- note-only / raw-converted / doctor-only / SharePoint-validation
```

## Next Step After Approval

After approval, Claude Code may create the private pilot folder and write the approved plan to:

```text
_reviews/open/private-simple-minimum-materialization-plan-YYYYMMDD.md
```

Then run the actual file consistency checklist before any manual knowledge loop.
