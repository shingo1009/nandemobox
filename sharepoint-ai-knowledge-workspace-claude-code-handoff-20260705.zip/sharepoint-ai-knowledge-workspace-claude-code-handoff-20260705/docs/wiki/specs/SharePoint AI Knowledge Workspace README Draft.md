---
type: spec
title: "SharePoint AI Knowledge Workspace README Draft"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - onboarding
  - readme
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[2026-07-04 Official Folder Permission Protection]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Simplicity Optimization Pass]]"
  - "[[SharePoint AI Knowledge Workspace README Onboarding Dry Run]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
---

# SharePoint AI Knowledge Workspace README Draft

## Purpose

This page drafts the root `README.md` for the pilot SharePoint / OneDrive Markdown workspace.

The root README is for humans. `CLAUDE.md` is for Claude Code. The README should make a new user comfortable in under one minute.

## Design Principle

The README should:

- Explain the workspace in plain language.
- Tell users where to put materials.
- Tell users where to look first.
- Reduce fear that personal notes will be treated as official rules.
- Avoid turning onboarding into a policy manual.

Detailed rules belong in `CLAUDE.md` or `_system/`.

## Candidate Root `README.md`

````markdown
# Knowledge Workspace

This folder is a shared Markdown knowledge workspace synchronized through SharePoint / OneDrive.

Use it to collect project notes, meeting notes, review results, useful personal insights, and common team knowledge.

Claude Code can help extract useful knowledge, create proposals, and notify people when action is needed.

## Quick Start

Do these three things first:

1. Add project material to `projects/{project}/sources/` or `projects/{project}/notes/`.
2. Check your action items in `_notifications/{your-user-id}/inbox/`.
3. Ask Claude Code to extract useful knowledge from the source.

If the material is not tied to one project, ask the curator where it belongs. V0 starts project-first; root source folders are an expansion option.

## Find Project Knowledge

If you know the project:

1. Open `projects/{project}/README.md`.
2. Check `projects/{project}/_index.md`.
3. Use `projects/{project}/official/` for trusted project knowledge.
4. Use `projects/{project}/reviewed/` for accepted project notes.

If you do not know the project, start with `_index/by_project.md` or `_index/by_topic.md`.

For cross-project common knowledge, use root `official/`.

## Useful Claude Code Requests

```text
自分宛通知を確認して。
```

```text
このsourceから抽出してproposalを作って。
```

```text
このproposalをレビューして。
```

```text
officialに反映すべき差分だけpatchにして。
```

## Trust And Safety

- `official/` is the most trusted area.
- Root `official/` is for cross-project knowledge.
- Project `official/` is for project-specific trusted knowledge.
- Do not directly edit root or project `official/` during the pilot. Create a patch in `_patches/open/`.
- AI-generated content is not official until reviewed.
- Personal notes in `people/` are reference material, not team policy.
- When unsure, put project material in `projects/{project}/sources/` and ask Claude Code to classify it.

## Folder Guide

| Folder | Use |
|---|---|
| `projects/{project}/README.md` | Project entry point |
| `projects/{project}/_index.md` | Project navigation and search keywords |
| `projects/{project}/sources/` | Project source material |
| `projects/{project}/notes/` | Low-friction project notes |
| `projects/{project}/reviewed/` | Accepted project notes |
| `projects/{project}/official/` | Protected project knowledge |
| `_notifications/` | Personal review requests and AI notices |
| `_reviews/open/` | Shared review findings |
| `_patches/open/` | Proposed changes to protected files |
| `_index/` | Navigation and generated indexes |
| `sources/` | Cross-project source material |
| `official/` | Protected cross-project knowledge |

## Workspace Owner

- Owner: [name or team]
- Curator: [name or team]
- Questions: ask the curator or create a note in `_notifications/{your-user-id}/inbox/`
````

## Why This README Is Intentionally Small

The first pilot should not require users to understand the whole lifecycle model. The README provides the first map. The deeper rules can stay in `CLAUDE.md` and `_system/`.

This shape follows [[SharePoint AI Knowledge Workspace README Onboarding Dry Run]] and [[SharePoint AI Knowledge Workspace Simplicity Optimization Pass]].

## Open Questions

- Should the README include contact or owner information?
- Should the README include screenshots later, or stay plain Markdown?
- Should it link to a short "first 5 minutes" sample workflow once the pilot workspace exists?
