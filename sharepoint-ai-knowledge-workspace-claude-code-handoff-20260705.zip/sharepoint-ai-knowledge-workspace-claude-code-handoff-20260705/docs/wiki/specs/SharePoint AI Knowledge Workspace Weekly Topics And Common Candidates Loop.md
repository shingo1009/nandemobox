---
type: spec
title: "SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 2
tags:
  - spec
  - maintenance
  - weekly
  - common-knowledge
  - python
  - motivation
related:
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Loop Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Article Integration Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]"
---

# SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop

## Purpose

Define the smallest optional loop for:

- showing useful weekly motion,
- surfacing repeated topics across project mini-wikis,
- keeping common knowledge evidence-based,
- avoiding extra client Claude Code usage.

This is not required for the first private materialization. Enable it only after real project activity exists.

## Principle

```text
Python prepares bounded evidence.
Claude writes judgment or narrative only where useful.
Humans decide what becomes common or official.
```

Weekly topics are not a newsletter by default. Common candidates are not automatic shared truth.

## Activation Trigger

Start this loop only when at least one is true:

- two or more project mini-wikis have meaningful updates,
- users ask "what changed this week?",
- repeated topics appear across projects,
- curators need a compact view of pending reviews or patches,
- the pilot has enough activity that visible progress would improve return visits.

Skip the loop when there is no meaningful change.

## Python Outputs

Python may produce dry-run or curator-facing files under `_reviews/open/`:

| Output | Purpose |
|---|---|
| `maint-weekly-topics-YYYY-Www.md` | factual weekly skeleton |
| `maint-common-candidates-YYYYMMDD.md` | repeated-topic candidate report |

Required fields:

- project links,
- evidence counts,
- source or event references,
- `reason_code`,
- `confidence`: `low`, `medium`, `high`,
- `sensitivity_hint`,
- `seen_count`.

Python must not decide common truth, merge articles, or notify everyone.

## Claude Role

`knowledge_steward` may:

- turn a weekly skeleton into a short curator-reviewed note,
- explain whether a candidate is truly common,
- draft cross-links,
- draft a root common candidate page,
- draft a curator notification for `needs_action` items.

Claude must not:

- broadcast the weekly note by default,
- promote common candidates automatically,
- flatten project-specific rules into shared truth,
- include sensitive details in root common notes without review.

## Human Review States

| State | Meaning |
|---|---|
| `keep_project_local` | similar words, different meaning |
| `link_only` | related enough to cross-link |
| `common_candidate` | reusable across projects, draft for review |
| `official_patch_candidate` | official knowledge may need a patch |
| `merge_plan_required` | needs scoped integration plan |
| `defer` | not enough evidence yet |

If a candidate appears for three weekly runs, close it, mark it local-only, link it, or promote it for review.

## Budgets

Default weekly note:

- at most five topics,
- at most five common candidates,
- direct notifications only for `needs_action`,
- raw skeleton stays curator-facing,
- accepted weekly note may be linked from an index or digest.

The weekly note shape:

1. What changed
2. What needs action
3. What became clearer
4. Common candidates
5. Next small step

## Failure Signals

This loop is too heavy if:

- weekly notes become a second inbox,
- weak candidates accumulate,
- normal users need Python,
- Claude reads broad folders instead of the skeleton,
- common pages collect many project exceptions,
- sensitive project context leaks into root notes.

## Success Signals

This loop is working if:

- users can see progress without reading raw event logs,
- curators find repeated topics without scanning every project,
- common knowledge is proposed with evidence,
- client Claude sessions start from generated views,
- weekly output motivates return visits without notification fatigue.

## Current Verdict

Keep this as an optional post-activity loop:

```text
admin Python dry-run
  -> bounded weekly/common evidence
  -> Claude narrative or candidate judgment
  -> curator acceptance
  -> small visible progress
```

Do not turn it into automatic distribution, automatic merge, or automatic common knowledge in V0.
