---
type: spec
title: "SharePoint AI Knowledge Workspace V0 Design Freeze Checklist"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - design-freeze
  - pilot
  - scope
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
  - "[[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Dry Run]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Simple Minimum Final Consistency Review]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
---

# SharePoint AI Knowledge Workspace V0 Design Freeze Checklist

## Purpose

Define what must be stable before moving from design refinement to pilot-folder materialization or real-environment validation.

This checklist protects V0 from growing into a full platform before the simple SharePoint / OneDrive Markdown workflow has been tested.

## Freeze Verdict

Current status: `not frozen`.

Reason:

- Core V0 design is coherent.
- Tabletop simulation is phase-complete.
- Real SharePoint / OneDrive validation is not complete.
- A few open questions are now classified in [[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]], but close-before-pilot items are not yet validated.

## V0 Design Invariants

These should not change without reopening the design:

| Invariant | Meaning |
|---|---|
| SharePoint / OneDrive first | V0 uses a synced Markdown folder, not a server, database, MCP requirement, or GROWI rollout. |
| Patch-first official updates | Claude may draft patches for `official/`, but should not directly mutate official knowledge during normal contribution flow. |
| Append-only events for shared activity | Normal users write `_index/events/` entries instead of frequently editing shared summary indexes. |
| Human-readable files | Every critical state must be inspectable as Markdown without a custom tool. |
| Project mini-wikis | Project-specific knowledge has a lightweight cloud-searchable WIKI under `projects/{project_slug}/`. |
| Optional raw evidence | Converted Excel/PPTX/document Markdown may live under project `.raw/`, but it remains source evidence and does not become a required article workflow. |
| Small role model | V0 assumes contributor, reviewer, curator, and Claude Code; no complex approval committee. |
| Notifications are action-filtered | `needs_action` must not be buried under FYI or digest noise. |
| Archive is review, not deletion | TTLs create review triggers and archive candidates, not automatic cleanup. |
| Technical helpers are deferred | Python/search/MCP/UI layers are added only after observed operational thresholds are crossed. |

## Must Be Frozen Before Materialization

| Area | Freeze Requirement | Evidence |
|---|---|---|
| Folder tree | V0 folder set is final enough to generate once. | [[SharePoint AI Knowledge Workspace Template Pack]] |
| Simple minimum profile | First pilot target is the minimum folder/rule set needed to prove one safe knowledge loop. | [[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]] |
| Project mini-wiki shell | V0 includes project-local README, index, official, reviewed, sources, notes, and optional `.raw` for converted source evidence. | [[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]], [[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]] |
| Human entrypoint | Root README is short and does not expose internal playbook complexity. | [[SharePoint AI Knowledge Workspace README Draft]] |
| Agent contract | Root `CLAUDE.md` names trust order, read order, and write boundaries. | [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]] |
| File consistency | README, `CLAUDE.md`, `_system/`, project README, project index, and starter official page do not contradict each other. | [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]], [[SharePoint AI Knowledge Workspace Pilot File Consistency Dry Run]] |
| Lifecycle statuses | Source, extraction, proposal, review, patch, notification, official, and archive states are named. | [[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]] |
| Notification statuses | `needs_action`, `waiting`, `deferred`, `resolved`, `superseded`, and `fyi` are enough for V0. | [[SharePoint AI Knowledge Workspace Shared Skill Playbooks]] |
| Patch statuses | `open`, `waiting_approval`, `merge_required`, `applied`, `rejected`, and `superseded` are enough for V0. | [[SharePoint AI Knowledge Workspace V0 Operating Flow]] |
| Review quality | The article rubric is compact enough for a real reviewer. | [[SharePoint AI Knowledge Workspace Article Quality Rubric]] |
| Validation protocol | Real-environment unknowns have pass/fallback checks. | [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]] |
| Open item disposition | Remaining uncertainties are classified as close, accept, defer, or remove. | [[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]] |
| Migration boundaries | Future tools have trigger thresholds, not enthusiasm-based adoption. | [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]] |

## Explicit V0 Scope

V0 includes:

- root `README.md`,
- root `CLAUDE.md`,
- minimum `_system/` files: `users.md`, `status_rules.md`, `write_rules.md`, and `patch_rules.md`,
- `_index/` with append-only `events/`,
- lightweight project mini-wikis under `projects/{project_slug}/`,
- optional project `.raw/` converted Markdown evidence when the pilot source comes from Excel, PowerPoint, PDF, Word, or similar,
- source-to-extraction-to-proposal flow,
- review to `reviewed/`,
- patch drafting for `official/`,
- personal notifications,
- archive candidate review,
- one starter official target.

V0 does not include:

- required Markdown playbooks or extra `_system` policy files before the first safe loop is proven,
- automatic crawling of Teams, SharePoint, Outlook, or meeting systems,
- a central database,
- MCP server dependency,
- GROWI or web UI dependency,
- automatic official edits by AI,
- global full-text search engine,
- automatic archive moves,
- full project-by-project lifecycle folder duplication,
- mandatory conversion automation for `.raw/`,
- broad rollout to many users.

## Open Items To Close Or Accept

| Item | Recommended Handling | Freeze Impact |
|---|---|---|
| Real SharePoint permission behavior | Validate through [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]. | Must close before real team pilot; can remain open for design-only freeze. |
| Version history and restore | Validate before any official page contains important content. | Must close before live official use. |
| OneDrive local file availability | Add first-run instruction if validation shows AI cannot read online-only files reliably. | Must close before asking non-technical users to use Claude locally. |
| Actual conflict filename pattern | Observe once during validation and update scanner playbook. | Can be accepted as known unknown for private rehearsal. |
| Notification digest threshold | Start conservative, recalibrate after one week. | Does not block design freeze. |
| Admin dry-run maintainer slice | Use [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]; keep write mode limited to generated blocks after review. | Dry-run planning can be in V0; broader automation should not block V0. |
| Full project-local workflow queues | Defer `_notifications/`, `_reviews/`, `_patches/`, and `_system/` inside every project until real usage proves the need. | Should not block V0. |

## Freeze Review Questions

Before freezing V0, answer these:

1. Can a new user decide where to put a source note within one minute?
2. Can Claude identify the trusted source of truth without reading the whole workspace?
3. Can a reviewer tell the difference between proposal, reviewed, and official content?
4. Can two users create work in parallel without editing the same shared summary file?
5. Can an official update be proposed without granting broad direct edit rights?
6. Can a stale proposal or notification be cleaned up without losing auditability?
7. Can the whole system still be explained without mentioning MCP, database, or web UI?

If the answer to any question is no, simplify the V0 scope before materialization.

## Freeze Exit Criteria

Design can be considered frozen for a private validation rehearsal when:

- every V0 invariant is accepted,
- every `Must Be Frozen` row has a named source page,
- [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]] has no blocking mismatch,
- open items are marked as close-before-pilot or accepted-known-unknown,
- close-before-pilot items are either closed, converted into explicit private-rehearsal risks, or removed from the rehearsal scenario,
- no new folder class is being added for convenience,
- no technical helper is required for the first manual run,
- [[SharePoint AI Knowledge Workspace V0 Readiness Gate]] still accurately reflects what is not ready.

Design cannot be frozen for a real team pilot until the external platform assumptions in [[SharePoint AI Knowledge Workspace V0 Readiness Gate]] are validated.

## Recommendation

Treat this checklist as the stop sign for design sprawl.

After this point, new V0 ideas should be handled as one of:

- replace an existing rule because it is simpler,
- defer to post-pilot backlog,
- add to migration triggers,
- add to validation protocol only if it tests a real operational risk.

Do not add new V0 folders, statuses, roles, or tools unless they directly preserve the simple source-to-proposal-to-review-to-patch loop.
