---
type: spec
title: "SharePoint AI Knowledge Workspace Initial File Contents"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - templates
  - file-contents
related:
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace README Draft]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
---

# SharePoint AI Knowledge Workspace Initial File Contents

## Purpose

Define the starter contents for the Simple Minimum pilot folder.

This page is an assembly checklist, not a second copy of every template. Full text belongs in the focused pages:

- Human onboarding: [[SharePoint AI Knowledge Workspace README Draft]]
- Claude operating rules: [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]
- Folder tree: [[SharePoint AI Knowledge Workspace Template Pack]]
- Project WIKI shape: [[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]

## Principle

The first workspace should feel usable after opening three files:

1. root `README.md`,
2. root `CLAUDE.md`,
3. project `projects/{project}/README.md`.

Everything else should be short enough for admin Python and Claude Code to validate mechanically.

## V0 Files To Create

| Path | Initial Content Source | Rule |
|---|---|---|
| `README.md` | [[SharePoint AI Knowledge Workspace README Draft]] | Human-small; quick start first. |
| `CLAUDE.md` | [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]] | Active Claude runtime contract. |
| `_system/users.md` | This page | Required. |
| `_system/status_rules.md` | This page | Required. |
| `_system/write_rules.md` | This page | Required. |
| `_system/patch_rules.md` | This page | Required. |
| `_index/by_project.md` | This page | Required generated/manual index seed. |
| `_index/by_topic.md` | This page | Required generated/manual index seed. |
| `_index/events/README.md` | This page | Append-only event convention. |
| `_notifications/{user}/digest.md` | This page | Low-priority rollup seed. |
| `_reviews/open/` | Empty folder | Evidence and review files land here. |
| `_patches/open/` | Empty folder | Official changes start here. |
| `projects/sample-project/README.md` | This page | Project WIKI entry. |
| `projects/sample-project/_index.md` | This page | Project-local navigation. |
| `projects/sample-project/sources/` | Empty folder | Normal project source notes. |
| `projects/sample-project/notes/` | Empty folder | Low-friction project notes. |
| `projects/sample-project/reviewed/` | Empty folder | Human-reviewed project notes. |
| `projects/sample-project/official/` | Empty folder or one starter target | Protected project knowledge. |

Optional for a raw-source pilot:

```text
projects/sample-project/.raw/{file_type}/
```

Use this only when converted Excel, PowerPoint, PDF, or other source Markdown is part of the scenario.

## Minimal `_system/users.md`

```markdown
# Users

Use stable lowercase IDs. Do not guess a user ID from OS username unless it is listed here.

| user_id | display_name | aliases | role |
|---|---|---|---|
| nishizawa | Nishizawa | nishizawashingo | curator |

## Rules

- If the current user is uncertain, ask.
- Do not write to `_notifications/{user}/` or `people/{user}/` without a confirmed user.
```

## Minimal `_system/status_rules.md`

```markdown
# Status Rules

| status | Meaning |
|---|---|
| source | Human-provided source material |
| proposal | Candidate shared knowledge |
| review_open | Open review finding or notification |
| reviewed | Human-reviewed knowledge |
| official | Stable accepted knowledge |
| superseded | Replaced by newer content |
| archived | Preserved only |

Trust order: `official`, `reviewed`, `proposal`, `source`, `archived`.
```

## Minimal `_system/write_rules.md`

```markdown
# Write Rules

Claude may create or update:

- `_reviews/open/`
- `_notifications/{current_user}/inbox/`
- `_patches/open/`
- generated files under `_index/`
- `projects/{project_slug}/notes/`
- `projects/{project_slug}/sources/` when asked
- `projects/{project_slug}/reviewed/` after approved review

Claude must not directly edit:

- root or project `official/`
- project `README.md`
- project `_index.md`
- `_system/`
- another person's personal folder
- `archive/`
- original source files

Protected changes require a patch in `_patches/open/`.
```

## Minimal `_system/patch_rules.md`

```markdown
# Patch Rules

Official knowledge is protected. Claude drafts patches; curators or owner-approved sessions apply them.

Patch metadata should include:

---
target_file: "projects/{project_slug}/official/path/file.md"
target_section: ""
status: open
risk: medium
owner: ""
source_files: []
---

Before drafting, search `_patches/open/` for the same `target_file`.

Before applying, reread the current target and same-target open patches, then apply one patch at a time.
```

## Minimal Index Seeds

`_index/by_project.md`:

```markdown
# By Project

## sample-project

- Project home: `projects/sample-project/README.md`
- Project index: `projects/sample-project/_index.md`
- Project official: `projects/sample-project/official/`
```

`_index/by_topic.md`:

```markdown
# By Topic

No topic index entries yet.
```

`_index/events/README.md`:

```markdown
# Index Events

Write one event file per meaningful workspace action.

Pattern: `YYYYMMDD-HHMM-user-action-topic.md`
```

## Minimal Notification Seed

`_notifications/{user}/digest.md`:

```markdown
# Notification Digest

## Open

- No open items.

## Done

- No done items.
```

## Minimal Project Files

`projects/sample-project/README.md`:

```markdown
# Sample Project WIKI

## Where To Look

1. `official/` for trusted project knowledge
2. `reviewed/` for human-reviewed project knowledge
3. `_index.md` for navigation and search keywords
4. `sources/` for source material
5. `notes/` for low-friction shared notes

## Add New Material

- Put meeting notes and review memos in `sources/`.
- Put informal shared project notes in `notes/`.
- Ask Claude Code to extract useful knowledge before creating patches.
```

`projects/sample-project/_index.md`:

```markdown
# Sample Project Index

Search keywords: sample project

## Official

- No official project notes yet.

## Reviewed

- No reviewed project notes yet.

## Sources

- No source files yet.

## Open Questions

- No open project questions yet.
```

## Deferred From Initial Contents

Do not create these by default in the first materialization:

- `_system/metadata_schema.md`
- `_system/permission_rules.md`
- `_system/notification_rules.md`
- `_system/archive_rules.md`
- `_system/skill_*.md`
- root `sources/`, `reviewed/`, `extracted/`, `proposals/`, `people/`
- generated report files beyond the two required indexes

Add them only when the scenario selector chooses that risk or real pilot evidence shows the need.
