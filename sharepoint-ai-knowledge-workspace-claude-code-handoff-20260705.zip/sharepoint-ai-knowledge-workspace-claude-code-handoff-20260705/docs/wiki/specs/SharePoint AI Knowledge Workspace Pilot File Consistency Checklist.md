---
type: spec
title: "SharePoint AI Knowledge Workspace Pilot File Consistency Checklist"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - pilot
  - acceptance
  - consistency
related:
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace README Draft]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[SharePoint AI Knowledge Workspace Initial File Contents]]"
  - "[[SharePoint AI Knowledge Workspace Governance Retention Audit]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Dry Run]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
---

# SharePoint AI Knowledge Workspace Pilot File Consistency Checklist

## Purpose

Define the consistency checks that must pass before the design is materialized into an actual pilot folder.

This is still design work. It does not create files.

## Why This Exists

The V0 design intentionally splits content across three layers:

- `README.md` for first human action,
- `CLAUDE.md` for Claude Code's operating contract,
- `_system/*.md` for detailed governance.

That split keeps onboarding simple, but it creates a new risk: the generated pilot files could drift from each other.

This checklist prevents that drift.

## Acceptance Principle

A pilot folder is acceptable only if:

1. README helps a human start quickly,
2. `CLAUDE.md` preserves the rule layer removed from README,
3. `_system/` contains the detailed rules referenced by `CLAUDE.md`,
4. project mini-wiki files follow the same trust and write boundaries,
5. no generated file contradicts the V0 scope boundary.

## Checklist

| Area | Check | Pass Condition |
|---|---|---|
| Root README | First action | README teaches add source, check notifications, ask Claude for extraction before folder taxonomy. |
| Root README | Policy lightness | README does not include full status table, full trust order, or full patch mechanics. |
| Root README | Owner clarity | README names owner, curator, or placeholder fields for them. |
| Root README | Official warning | README says root and project `official/` are protected and should use patches. |
| `CLAUDE.md` | Read order | `CLAUDE.md` names root read order and project read order. |
| `CLAUDE.md` | Trust order | `CLAUDE.md` says project `official/` wins for project-specific questions and root `official/` wins for cross-project knowledge. |
| `CLAUDE.md` | Write boundaries | `CLAUDE.md` forbids direct edits to root `official/`, project `official/`, project README, project `_index.md`, `_system/`, other users' folders, archive, and original source files. |
| `CLAUDE.md` | Current user | `CLAUDE.md` explains how to resolve `{current_user}` before personal writes. |
| `_system/users.md` | Identity | User IDs are stable and lowercase; aliases are explicit. |
| `_system/status_rules.md` | Lifecycle | Source, extracted, proposal, reviewed, official, deprecated, and archived are defined. |
| `_system/write_rules.md` | Boundary match | Allowed and forbidden writes match `CLAUDE.md`. |
| `_system/patch_rules.md` | Patch metadata | Patches require target file, target section, status, risk, owner, required approval, and source files. |
| `_system/patch_rules.md` | Project targets | `target_file` examples include root `official/...` and project `projects/{project}/official/...`. |
| Optional `_system/permission_rules.md` | Protection model | If present, root and project `official/` protection is described; convention-only fallback is explicit. |
| Optional `_system/notification_rules.md` | Action triage | If present, `needs_action`, `waiting`, `deferred`, `resolved`, `superseded`, and `fyi` are defined. |
| Optional `_system/archive_rules.md` | Preservation | If present, archive is review/preservation, not automatic deletion. |
| Claude behavior model | Skill consolidation | `CLAUDE.md` uses `workspace_navigator`, `knowledge_steward`, and `patch_reviewer`; seven `_system/skill_*.md` files are not required. |
| Project README | Searchability | Project README has project state, last reviewed date, search keywords, owner, and curator. |
| Project `_index.md` | Navigation | Project `_index.md` lists official, reviewed, sources, and open questions. |
| Project official | Patch target | Starter official page says future changes go through `_patches/open/`. |
| Optional project `.raw/` | Traceability | If project `.raw/` exists, converted Markdown files preserve original file path, original file type, conversion source, and conversion time in frontmatter. |
| Optional project `.raw/` | Trust boundary | If project `.raw/` exists, project README, `_index.md`, and generated indexes do not present converted Markdown as reviewed or official knowledge. |
| Optional project `.raw/` | Source citation | If reviewed notes or patches are created from converted Markdown, `source_files` cites the `.raw` Markdown path actually read by Claude. |
| Indexes | Empty states | Empty indexes clearly say no content exists yet. |
| Events | Append-only path | `_index/events/` exists and has an explanation or README. |
| Evidence note | Result capture | If actual materialization is run, `_reviews/open/pilot-evidence-YYYYMMDD.md` records selected scenario, source path, outputs, checklist result, and pass/pass_with_notes/blocked status. |
| Scope | No accidental expansion | No full project-local `_system/`, `_notifications/`, `_reviews/`, or `_patches/` are generated for V0. |

## Failure Handling

If a check fails before materialization:

- update the design page that owns the missing rule,
- do not patch only the generated file,
- then regenerate or manually revise the pilot file from the updated design.

If a check fails after materialization:

- record the mismatch in `_reviews/open/`,
- create a patch for the affected protected file when needed,
- add an `_index/events/` entry,
- update this design vault if the template itself was wrong.

If the checklist passes after materialization, still record the result in the pilot evidence note. Passing evidence is useful because it prevents later design work from re-litigating already tested assumptions.

## Consistency Invariants

These invariants should always hold:

- README can be simpler than `CLAUDE.md`, but not contradictory.
- `CLAUDE.md` can summarize `_system/`, but every referenced `_system` file must exist.
- Optional `_system/` files must not be referenced as mandatory in the Simple Minimum Profile unless they are materialized.
- `_system/write_rules.md` and `CLAUDE.md` must agree on protected paths.
- Project mini-wikis are independent for browsing, but not independent workflow systems in V0.
- Official content is updated through patches, whether root or project-specific.
- Project `.raw/` is an optional source-evidence layer; its presence should trigger traceability checks, not create a required conversion workflow.
- Converted `.raw` Markdown is searchable and ingestible source evidence, not an active reviewed article.

## Recommended Review Sequence

Before creating a pilot folder:

1. Review [[SharePoint AI Knowledge Workspace README Draft]].
2. Review [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]].
3. Review [[SharePoint AI Knowledge Workspace Initial File Contents]].
4. If the pilot source is converted Excel, PowerPoint, PDF, Word, or similar, review [[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]].
5. Run this checklist against the intended generated files.
6. Only then move to real SharePoint / OneDrive validation through [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]].

## Status

This checklist is a design gate.

It is a close-before-materialization item, but not a reason to build automation in V0.

Current design-artifact dry run: [[SharePoint AI Knowledge Workspace Pilot File Consistency Dry Run]] is `pass_with_notes`.

The checklist still must be rerun against actual generated or manually created pilot files if materialization is requested.
