---
type: spec
title: "SharePoint AI Knowledge Workspace Client Skill Playbooks"
status: reference
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 2
tags:
  - spec
  - skills
  - playbooks
  - client
related:
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Skill Architecture]]"
  - "[[SharePoint AI Knowledge Workspace Shared Skill Playbooks]]"
  - "[[2026-07-05 Admin Python First Maintenance]]"
---

# SharePoint AI Knowledge Workspace Client Skill Playbooks

## Purpose

Define client-side playbook candidates without making every user install or run extra tooling.

Client-side playbooks protect local identity, local sync state, personal attention, and sensitivity before information enters the shared workspace.

## V0 Decision

Do not require client-side skill installation for normal users.

Normal clients should be able to:

- browse/search the project WIKI in SharePoint,
- add source notes under a project,
- ask Claude Code only when they need help,
- start from maintained indexes, digests, or notifications prepared by admin Python.

Admin Python remains the default place for repeated maintenance.

## Candidate Client Playbooks

| Candidate | V0 Home | Promote When |
|---|---|---|
| `current_user_resolver` | `_system/users.md` plus a short prompt/rule | user identity ambiguity happens often |
| `daily_personal_triage` | `workspace_navigator` plus Python digest | users repeatedly miss `needs_action` items |
| `local_sync_conflict_scanner` | `kw-maint conflict-scan` for admin; manual warning for clients | SharePoint/OneDrive creates client-only conflicts |
| `personal_sensitivity_preflight` | checklist before sharing | users often paste customer, contract, incident, or restricted content |
| `personal_source_capture` | `knowledge_steward` prompt | local notes become a common contribution path |
| `review_assistant` | `knowledge_steward` | reviewers need a repeatable personal review routine |
| `patch_apply_assistant` | human curator procedure | permission, rollback, sync, and audit trail are proven |

## Client Boundary

| Concern | Client Side | Shared/Admin Side |
|---|---|---|
| current user identity | confirm local identity | `_system/users.md` source of truth |
| sync conflict visibility | warn when local machine sees conflict | `kw-maint conflict-scan` catches shared visible conflicts |
| personal sensitivity | check before sharing | workspace rules govern promotion |
| source capture | keep contribution lightweight | project WIKI receives source |
| review attention | show personal action list | Python digest and notification state reduce scan cost |
| patch application | never automatic for normal user | curator decides and applies |

## Minimal Client Routine

For V0, a client session should usually do only this:

1. resolve current user when needed,
2. check that the target project and notification are narrow,
3. warn if obvious local sync conflicts are visible,
4. avoid sharing sensitive content without preflight,
5. ask Claude to read only the relevant project WIKI files.

If this cannot handle real use, promote the smallest failing routine into a client playbook.

## Safety Defaults

- Do not guess `current_user`.
- Do not read another user's inbox unless explicitly asked and permitted.
- Do not delete or resolve sync conflicts automatically.
- Do not write sensitive excerpts into notifications.
- Do not apply official patches from a normal client session.
- Do not make client-side playbooks depend on one person's local path.

## Reopen This Page When

- multiple users begin using the workspace,
- SharePoint/OneDrive sync conflicts appear on client PCs,
- notification triage takes more than a few minutes,
- reviewers need personal review checklists,
- source capture becomes a daily habit,
- sensitivity warnings become frequent,
- curator patch application needs a safer guided routine.

## Current Verdict

Client-side capability should stay light for V0.

The preferred burden split is:

```text
normal client: read/search/add narrow project material
Claude Code: meaning-heavy help on request
admin Python: repeated maintenance and reports
human curator: irreversible decisions
```
