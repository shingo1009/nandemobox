---
type: spec
title: "SharePoint AI Knowledge Workspace Expected First Claude Code Output"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - handoff
  - claude-code
  - pilot
related:
  - "[[SharePoint AI Knowledge Workspace Claude Code Handoff Intake Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
---

# SharePoint AI Knowledge Workspace Expected First Claude Code Output

## Purpose

Define the first useful output Claude Code should produce after reading the handoff ZIP.

This is a planning artifact. It should not create the real workspace files by itself.

## Expected Title

```text
Private Simple Minimum Materialization Plan
```

## Output Boundary

Before human approval:

- keep the plan in chat or draft form,
- do not create the target workspace,
- do not create `_reviews/open/private-simple-minimum-materialization-plan-YYYYMMDD.md`,
- do not run SharePoint or OneDrive changes.

After human approval:

- write the approved plan into the target workspace as:

```text
_reviews/open/private-simple-minimum-materialization-plan-YYYYMMDD.md
```

## Template

````markdown
# Private Simple Minimum Materialization Plan

## Decision

Status: draft_pending_approval

Shared rollout: not ready.

Next action: create a private Simple Minimum pilot folder after the human approves the target path and scenario.

## Proposed Target

- Target path: `[fill after human confirms]`
- Environment: local private folder / private SharePoint test folder
- Curator: nishizawa
- Pilot project slug: sample-project

## Scenario Choice

Default scenario: note-only workflow proof.

Use `.raw` only if the first source is converted from Excel, PowerPoint, PDF, Word, or another original file.

## Folder Tree To Create

```text
knowledge-workspace/
├─ README.md
├─ CLAUDE.md
├─ _system/
│  ├─ users.md
│  ├─ status_rules.md
│  ├─ write_rules.md
│  └─ patch_rules.md
├─ _index/
│  ├─ by_project.md
│  ├─ by_topic.md
│  └─ events/
├─ _notifications/
│  └─ nishizawa/
│     ├─ inbox/
│     └─ digest.md
├─ _reviews/
│  └─ open/
├─ _patches/
│  └─ open/
├─ projects/
│  └─ sample-project/
│     ├─ README.md
│     ├─ _index.md
│     ├─ sources/
│     ├─ notes/
│     ├─ reviewed/
│     └─ official/
└─ archive/
```

Optional only when needed:

```text
projects/sample-project/.raw/{file_type}/
```

## Initial File Sources

| Target File | Source |
|---|---|
| `README.md` | `docs/wiki/specs/SharePoint AI Knowledge Workspace README Draft.md` |
| `CLAUDE.md` | `docs/wiki/specs/SharePoint AI Knowledge Workspace Minimal CLAUDE Rules.md` |
| `_system/users.md` | `docs/wiki/specs/SharePoint AI Knowledge Workspace Initial File Contents.md` |
| `_system/status_rules.md` | `docs/wiki/specs/SharePoint AI Knowledge Workspace Initial File Contents.md` |
| `_system/write_rules.md` | `docs/wiki/specs/SharePoint AI Knowledge Workspace Initial File Contents.md` |
| `_system/patch_rules.md` | `docs/wiki/specs/SharePoint AI Knowledge Workspace Initial File Contents.md` |
| project README and `_index.md` | `docs/wiki/specs/SharePoint AI Knowledge Workspace Project Mini Wiki Structure.md` |
| pilot source/review flow | `docs/wiki/specs/SharePoint AI Knowledge Workspace Pilot Sample Flow.md` |

## Explicit Non-Goals

- No broad team rollout.
- No SharePoint permission changes yet.
- No MCP, database, service, or UI.
- No `_system/skill_*.md`.
- No automatic deletion or archive moves.
- No generated-block write mode.
- No root `sources/`, `extracted/`, `proposals/`, `reviewed/`, `official/`, or `people/` folders unless a later scenario requires them.

## Validation Plan

Before use:

1. Run the pilot file consistency checklist against actual files.
2. Confirm `CLAUDE.md` and `_system/write_rules.md` agree on protected paths.
3. Confirm project README and `_index.md` are readable and short.
4. Confirm `_notifications/nishizawa/inbox/` exists.
5. Confirm official changes must use `_patches/open/`.

After one manual loop:

1. Record `_reviews/open/pilot-evidence-YYYYMMDD.md`.
2. Add one `_index/events/` pointer.
3. Run or simulate `kw-maint doctor`.
4. Keep result as `pass`, `pass_with_notes`, or `blocked`.

## Expected `kw-maint doctor`

If implemented, run only read-only behavior:

```text
kw-maint doctor --root /path/to/knowledge-workspace
```

Expected first result:

- exit `0` for a clean note-only folder, or
- exit `1` with warnings if metadata or dry-run index previews need review.

No writes are allowed.

## Open Questions For Human

- What exact target path should be used?
- Should the first scenario be note-only or `.raw` converted source traceability?
- Should the private folder be local-only first, or a private SharePoint test folder?
- Is `nishizawa` the only pilot user for the first run?
````

## Use In Handoff Package

Include this template in the handoff package as:

```text
EXPECTED_FIRST_OUTPUT.md
```

Claude Code can use it as the shape of its first response after reading the package.
