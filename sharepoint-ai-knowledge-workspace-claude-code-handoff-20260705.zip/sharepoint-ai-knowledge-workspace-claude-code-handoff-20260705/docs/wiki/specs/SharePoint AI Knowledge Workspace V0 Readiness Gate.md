---
type: spec
title: "SharePoint AI Knowledge Workspace V0 Readiness Gate"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - pilot
  - readiness
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
  - "[[SharePoint AI Knowledge Workspace V0 Design Freeze Checklist]]"
  - "[[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
---

# SharePoint AI Knowledge Workspace V0 Readiness Gate

## Purpose

Define the go/no-go gate for starting a real V0 pilot.

This page is a decision checklist. Evidence and detailed simulations live in the linked pages.

## Current Status

Status: `not ready for real shared pilot`.

Reason:

- Design and tabletop simulations are strong.
- The Simple Minimum folder has not yet been materialized as real files.
- `kw-maint doctor` has not been implemented or run.
- SharePoint / OneDrive behavior has not been validated in the actual tenant.

Private local rehearsal may start before shared pilot if the selected scenario is intentionally narrow.

## Gate Summary

| Area | Required For Shared Pilot | Current State |
|---|---|---|
| Human onboarding | Root README tells users where to put material, where to look, and how to ask Claude Code for extraction. | Mostly ready as design. |
| Agent contract | `CLAUDE.md` defines read order, trust order, write boundaries, and current-user handling. | Mostly ready as design. |
| Folder template | Simple Minimum structure is selected and expansion folders stay deferred. | Designed, not materialized. |
| Project mini-wiki | Pilot project has README, `_index.md`, `sources/`, `notes/`, `reviewed/`, and `official/`. | Tabletop validated, not materialized. |
| Review/notification flow | Review findings and action notifications have clear destinations. | Designed, not real-user verified. |
| Patch flow | Official changes use `_patches/open/`; same-target patches are checked. | Designed, not real-user verified. |
| Python maintenance | First no-write `kw-maint doctor` boundary and fixtures are defined. | Designed, not implemented. |
| SharePoint safety | Permission, version history, search, local availability, and conflict behavior are checked. | Not ready. |

## Go Criteria

Start a shared pilot only when all of these are true:

- A private Simple Minimum folder exists with real files.
- [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]] passes against those files.
- `kw-maint doctor --root /path/to/workspace` runs read-only and returns expected output.
- One sample source completes the path in [[SharePoint AI Knowledge Workspace Pilot Sample Flow]].
- A human can find their notification folder without explanation.
- The project README and `_index.md` are searchable from SharePoint web for permitted users.
- Root and project `official/` cannot be casually edited, or the convention-only risk is explicitly accepted.
- Version history and restore are confirmed for the target SharePoint library.
- OneDrive local availability is reliable enough for the admin-runner PC.
- The pilot has one named curator.

## No-Go Conditions

Do not start a shared pilot if any of these are true:

- `official/` can be edited by everyone and no warning or permission plan exists.
- Users cannot identify their notification folder.
- Claude Code rules do not distinguish `official`, `reviewed`, `proposal`, and `source`.
- `_index/events/` is absent for multi-user activity.
- Patch application can happen without checking same-target patches.
- Project-specific work has no project mini-wiki.
- Pilot files contradict each other on trust order, write boundaries, or patch flow.
- There is no curator.
- SharePoint search or sync behavior is still unknown and the pilot relies on it.

## Minimal Pilot Shape

Use:

- 1 curator,
- 1 contributor,
- 1 reviewer,
- 1 non-sensitive source note,
- 1 project mini-wiki,
- 1 official starter target,
- 1 week of notification and patch observation.

Do not start with a broad rollout.

## Evidence Order

1. Choose scenario in [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]].
2. Materialize private folder using [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]].
3. Run [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]].
4. Implement or simulate first `kw-maint doctor` from [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]].
5. Run one [[SharePoint AI Knowledge Workspace Pilot Sample Flow]].
6. Validate SharePoint / OneDrive using [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]].
7. Recheck [[SharePoint AI Knowledge Workspace V0 Design Freeze Checklist]].

## Decision

Current recommendation:

```text
Do not start a real shared pilot yet.
Start with private Simple Minimum materialization when moving from design to setup.
```

The gate can move from `not ready` to `private pilot ready` after real files exist and file consistency passes.

The gate can move from `private pilot ready` to `shared pilot ready` only after `kw-maint doctor` and SharePoint / OneDrive validation produce evidence.
