---
type: spec
title: "SharePoint AI Knowledge Workspace Article Quality Rubric"
status: draft
created: 2026-07-04
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - quality
  - review
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Shared Skill Playbooks]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Design Coverage Audit]]"
  - "[[SharePoint AI Knowledge Workspace Article Integration Simulation]]"
---

# SharePoint AI Knowledge Workspace Article Quality Rubric

## Purpose

Define a compact article quality rubric for proposals, reviewed notes, and official patch candidates.

This rubric keeps article precision from depending only on a reviewer's memory or Claude's style in a single session.

## When To Use

Use this rubric when:

- reviewing a proposal,
- deciding whether a proposal can move to `reviewed/`,
- deciding whether a reviewed note should become an official patch,
- checking whether an official patch is safe to apply.

## Quality Dimensions

| Dimension | Pass | Warning | Fail |
|---|---|---|---|
| Source backing | claims link to source files or reviewed/official evidence | source exists but claim mapping is vague | important claims have no evidence |
| Scope control | article states exactly when it applies | scope is implied but not explicit | article over-generalizes from one case |
| Status clarity | frontmatter and folder match lifecycle | status is present but ambiguous | reader may mistake unreviewed content for official |
| Sensitivity | confidential/restricted content is marked or excluded | sensitivity is unclear | sensitive content is exposed in shared area |
| Duplicate/conflict check | similar official/reviewed notes are linked | related notes may exist but were not checked deeply | duplicates or contradictions are ignored |
| Actionability | reader knows what to do or decide | useful but vague | only a summary; no reusable guidance |
| Owner/reviewer | owner and reviewer path are clear | owner exists but reviewer is missing | no accountable owner |
| Patch readiness | target file and section are clear | target exists but section is broad | patch cannot be applied safely |
| Merge fitness | common core and project-specific deltas are separated | overlap exists but merge plan is vague | project-specific rules are flattened into a misleading common article |

## Review Verdicts

Use one of these verdicts:

| Verdict | Meaning | Typical Next Action |
|---|---|---|
| accept_to_reviewed | good enough as provisional shared knowledge | copy proposal to `reviewed/` |
| revise | useful but needs changes | notify owner or proposal author |
| reject | not reusable or not reliable | record reason; do not promote |
| defer | useful but timing or owner is unclear | keep pending with owner/date |
| patch_official | contains a safe official delta | draft `_patches/open/` patch |
| merge_required | overlaps with another proposal or patch | compare and merge before promotion |
| cross_link | related to another reviewed note but not mergeable | add proposed links or references |
| keep_separate | similar wording but different scope, owner, or risk | record why it stays project-local |
| merge_common_core | shared principle exists with project-specific deltas | draft common reviewed article plus project links |
| revise_existing | existing reviewed note is stale, incomplete, or too broad | create article revision review file |
| authority_conflict | sources disagree on who decides or what rule applies | route to curator; do not merge |

## Minimum Passing Bar By Destination

### Proposal

Minimum:

- readable title,
- source evidence,
- proposed reusable knowledge,
- owner or suggested reviewer,
- risk level.

Failing one item is acceptable if the proposal clearly marks the gap.

### Reviewed

Minimum:

- source-backed core claims,
- scope control,
- no unresolved high-risk sensitivity issue,
- at least one human reviewer,
- duplicate/conflict check against obvious `official/` and `reviewed/` notes.

### Official Patch

Minimum:

- target file,
- target section,
- exact proposed change,
- source evidence,
- risk level,
- required approval,
- same-target patch check,
- rollback note.

### Common Or Merged Reviewed Article

Minimum:

- shared core rule is explicit,
- project-specific deltas remain linked or separate,
- source evidence covers every shared claim,
- owner or curator path is clear,
- sensitivity check passes for every included project,
- merge decision is one of `cross_link`, `merge_common_core`, `revise_existing`, `patch_official`, `keep_separate`, or `authority_conflict`.

Article size budget:

- one article should answer one user question or support one decision,
- split when more than three distinct scopes are present,
- split or move detail to project-local notes when more than seven major sections are needed.

## Risk-Based Strictness

| Knowledge Type | Required Strictness |
|---|---|
| FAQ, examples, terminology | one reviewer can accept to `reviewed/` |
| Review checklist or operating procedure | one reviewer can accept to `reviewed/`; owner review before official |
| Contract, security, authority, incident, compliance | owner or multiple reviewers before promotion; explicit approval before official |

## Compact Review Output

Use this output shape:

```text
Verdict: accept_to_reviewed / revise / reject / defer / patch_official / merge_required / cross_link / keep_separate / merge_common_core / revise_existing / authority_conflict
Risk: low / medium / high
Quality:
- Source backing: pass / warning / fail
- Scope control: pass / warning / fail
- Status clarity: pass / warning / fail
- Sensitivity: pass / warning / fail
- Duplicate/conflict: pass / warning / fail
- Actionability: pass / warning / fail
Main issues:
- ...
Next action:
- ...
```

## Failure Signals

The article quality process is too heavy if:

- contributors stop adding sources because the rubric feels like homework,
- Claude refuses to create proposals because metadata is incomplete,
- reviewers spend more time formatting than deciding,
- low-risk FAQ items wait for high-risk approval paths.

The process is too loose if:

- readers cannot tell whether a note is official,
- proposals become de facto policy,
- official patches lack source evidence,
- duplicate or contradictory reviewed notes accumulate.
- common articles flatten project-specific exceptions into broad rules.

## Design Note

This rubric should remain short. Its job is to support judgment, not replace judgment.

[[SharePoint AI Knowledge Workspace Article Integration Simulation]] adds the integration rule: use a merge plan before changing reviewed/common articles when overlap spans multiple project mini-wikis.
