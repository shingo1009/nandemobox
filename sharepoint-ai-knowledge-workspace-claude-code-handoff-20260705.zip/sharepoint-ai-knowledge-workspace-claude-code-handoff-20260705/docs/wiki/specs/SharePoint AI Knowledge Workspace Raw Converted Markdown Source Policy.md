---
type: spec
title: "SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy"
status: draft
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - raw
  - ingest
  - source
  - markdown
  - python
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
  - "[[SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation]]"
---

# SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy

## Purpose

Define how to keep Markdown conversions of original files such as Excel and PowerPoint.

The converted Markdown is valuable even before full article extraction because every client can later ingest or search the Markdown without reopening the binary source file.

## Core Rule

```text
Converted Markdown is source evidence, not a reviewed article.
Keep it in `.raw/` with the original file path in frontmatter.
```

The converted file should be treated as immutable source evidence unless an administrator intentionally regenerates it from the original.

## Folder Shape

Preferred project-local shape:

```text
projects/{project_slug}/
├─ .raw/
│  ├─ xlsx/
│  ├─ pptx/
│  └─ other/
├─ sources/
├─ reviewed/
└─ official/
```

Root-level shape is allowed only for cross-project source material:

```text
.raw/
├─ xlsx/
├─ pptx/
└─ other/
```

Reason: project-local `.raw/` keeps SharePoint search and later Claude ingestion scoped to the project mini-wiki.

## Frontmatter

Use frontmatter to preserve traceability to the original file:

```yaml
---
type: raw_converted_markdown
status: source
project: project-slug
owner: user-id
sensitivity: normal
original_file_path: "SharePoint or local synced path to original.xlsx"
original_file_name: "original.xlsx"
original_file_type: "xlsx"
original_file_modified_at: "YYYY-MM-DDTHH:mm:ss+09:00"
original_file_hash: ""
converted_from: "xlsx"
converted_at: "YYYY-MM-DDTHH:mm:ss+09:00"
converted_by: "kw-maint or user-id"
conversion_tool: "manual | python | markitdown | other"
conversion_version: ""
conversion_warning: ""
raw_source_id: "project-slug/original-file-stem"
---
```

Minimum required fields:

- `type`,
- `status`,
- `project`,
- `owner`,
- `original_file_path`,
- `original_file_name`,
- `original_file_type`,
- `converted_from`,
- `converted_at`.

Hashes are recommended but not mandatory for V0.

## Body Shape

Start with a short conversion notice:

```markdown
# Converted Source: Original File Name

This file is a Markdown conversion of an original source file.

- Original file: `...`
- Converted at: YYYY-MM-DD HH:mm
- Conversion tool: ...

## Extracted Content

...
```

For Excel:

- one section per sheet,
- preserve table headings,
- include row/column labels when useful,
- avoid inventing summaries inside the raw conversion.

For PowerPoint:

- one section per slide,
- include slide title,
- include bullets and speaker notes when available,
- keep image references as placeholders unless image extraction is explicitly supported.

If the conversion is partial, use `conversion_warning` or a visible note in the body. Examples: image-only slide, chart not extracted, table layout uncertain, speaker notes unavailable.

## Ingest Use

Claude Code may ingest from `.raw/*.md` by reading the converted Markdown and creating:

- extraction notes,
- proposals,
- reviewed articles,
- patch drafts,
- common candidates.

Generated articles must cite the `.raw` converted Markdown path in `source_files`.

The generated article should not cite only the binary original if the converted Markdown was the actual readable source used by Claude.

## Python Maintainer Role

Admin Python may later own:

- converting `.xlsx`, `.pptx`, `.docx`, or PDF source files to Markdown,
- writing converted Markdown under `.raw/`,
- validating required raw frontmatter,
- detecting stale conversions when the original file modified time is newer than `converted_at`,
- detecting explicit conversion warnings such as image-only slides or missing charts,
- reporting missing original paths,
- reporting converted files that are not cited by any extraction/proposal/review.

Admin Python must not overwrite converted Markdown without either:

- dry-run confirmation, or
- a generated replacement file with a new timestamp/version.

## Deletion And Archive Rule

Converted `.raw` Markdown is source evidence.

Do not delete it during article merge cleanup. If articles are merged, follow [[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]] for the articles, but keep the `.raw` converted Markdown unless the owner or curator approves source removal.

If original binary files are removed from the shared workspace, the converted Markdown becomes more valuable, not less, because it may be the remaining AI-readable evidence.

## Search Value

Keeping converted Markdown in SharePoint creates immediate value:

- users can search converted Excel/PPTX content as text,
- Claude Code can read the file without binary conversion in every client session,
- common-candidate discovery can use text and frontmatter,
- later reingest remains possible even if a client lacks Office tooling.

## Minimal V0 Position

V0 can support converted `.raw` Markdown without implementing conversion automation.

Minimum:

- allow project-local `.raw/`,
- define frontmatter,
- preserve original file path,
- treat converted Markdown as source evidence,
- forbid article cleanup from deleting `.raw` evidence.

Automation can come later through admin Python.

The combined operating simulation lives in [[SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation]]. It confirms that `.raw` should remain source evidence and should not become the active article layer.
