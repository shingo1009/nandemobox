---
type: index
title: "Specifications Index"
status: evergreen
created: 2026-07-02
updated: 2026-07-05
tags:
  - index
  - specs
---

# Specifications

Use this folder for product specs, feature specs, API specs, UX requirements, acceptance criteria, and scope boundaries.

## Core

- [[SharePoint AI Knowledge Workspace]]: compact V0 specification.
- [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]: active V0 runtime control page.
- [[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]: source principle for simple-first, expandable-later.

## Pilot Execution

- [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]: choose the next evidence scenario.
- [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]: create the private Simple Minimum folder when requested.
- [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]: check actual pilot files.
- [[SharePoint AI Knowledge Workspace Pilot Sample Flow]]: minimal source-to-reviewed-to-patch sample.
- [[SharePoint AI Knowledge Workspace Expected First Claude Code Output]]: first planning output template for handoff use.
- [[SharePoint AI Knowledge Workspace First Output Acceptance Checklist]]: approve, change, or reject Claude Code's first plan.
- [[SharePoint AI Knowledge Workspace V0 Readiness Gate]]: go/no-go checklist.
- [[SharePoint AI Knowledge Workspace V0 Design Freeze Checklist]]: scope freeze boundary.
- [[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]]: close/defer/remove classification.

## Workspace Files

- [[SharePoint AI Knowledge Workspace Template Pack]]: folder and file template pack.
- [[SharePoint AI Knowledge Workspace Initial File Contents]]: Simple Minimum starter file assembly checklist.
- [[SharePoint AI Knowledge Workspace README Draft]]: human onboarding README.
- [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]: root `CLAUDE.md` and minimal rule files.
- [[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]: project WIKI shape.
- [[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]]: project creation and anti-sprawl rules.

## Runtime And Maintenance

- [[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]: Python, Claude Code, and human responsibility boundary.
- [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]: admin Python command reference.
- [[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]: first no-write `kw-maint doctor` implementation plan.
- [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]: fixture-level doctor acceptance matrix.

## Knowledge Governance

- [[SharePoint AI Knowledge Workspace V0 Operating Flow]]: daily source, review, notification, and patch flows.
- [[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]]: source-to-official lifecycle.
- [[SharePoint AI Knowledge Workspace Article Quality Rubric]]: compact quality rubric.
- [[SharePoint AI Knowledge Workspace Archive TTL Policy]]: stale material review triggers.
- [[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]: merge cleanup, tombstones, archive, and delete boundary.
- [[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]: converted Office/PDF Markdown source policy.

## Expansion Paths

- [[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]: optional post-activity weekly/common-candidate loop.
- [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]: when to add helpers, search, UI, MCP, or service layers.
- [[SharePoint AI Knowledge Workspace Shared Skill Playbooks]]: deferred shared playbook candidates.
- [[SharePoint AI Knowledge Workspace Client Skill Playbooks]]: lightweight client-side playbook candidates.
- [[SharePoint AI Knowledge Workspace Skill Architecture]]: reference capability map for future skill promotion.
- [[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]: rationale for reducing many skills to three behaviors plus admin Python.

## Other Active Specs

- [[Knowledge Pull Request Hub]]: draft design for a central knowledge proposal system.

## Shipped

- _No shipped specs yet._
