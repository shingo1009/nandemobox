---
type: spec
title: "SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules"
status: draft
created: 2026-07-04
updated: 2026-07-04
project: "SharePoint AI Knowledge Workspace Project"
priority: 1
tags:
  - spec
  - project-wiki
  - governance
  - onboarding
related:
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]]"
---

# SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules

## Purpose

Define how new project mini-wikis are created without causing folder sprawl.

The goal is not strict bureaucracy. The goal is to make project-separated shared WIKIs predictable enough for humans, Claude Code, and SharePoint search.

## V0 Rule

In V0, a project mini-wiki should be created by a curator or with curator approval.

Contributors may request a project mini-wiki, but should not casually create permanent project folders without:

- a stable project slug,
- an owner,
- a curator,
- a purpose,
- a sensitivity level,
- an initial `_index.md`.

## Project Slug Rules

Use stable lowercase slugs:

```text
projects/{project_slug}/
```

Rules:

- lowercase ASCII letters, numbers, and hyphens only,
- no spaces,
- no Japanese characters in folder names for V0,
- no dates unless the date is part of the official project identifier,
- avoid product codenames if the formal project name is known,
- keep slugs short enough for OneDrive / SharePoint path safety.

Examples:

| Good | Avoid |
|---|---|
| `external-if-renewal` | `外部IF刷新プロジェクト` |
| `billing-api` | `billing api` |
| `sharepoint-knowledge-v0` | `20260704-sharepoint-knowledge-v0-long-long-name` |

## Creation States

| State | Meaning | Allowed Use |
|---|---|---|
| `draft_project` | Requested or being prepared | may contain README and notes only |
| `active_project` | Approved project mini-wiki | normal V0 use |
| `paused_project` | Temporarily inactive | read/search only unless owner resumes |
| `archived_project` | Closed project preserved for reference | no normal edits |

V0 should not add a separate project status machine beyond these four states.

## Minimum Files

Every active project mini-wiki needs:

```text
projects/{project_slug}/
├─ README.md
├─ _index.md
├─ official/
├─ reviewed/
├─ sources/
└─ notes/
```

Optional after pilot:

- `assets/` for images or PDFs,
- `archive/` for project-local archival references if root archive becomes too noisy.

Do not add in V0:

- project-local `_system/`,
- project-local `_notifications/`,
- project-local `_reviews/`,
- project-local `_patches/`.

## Project README Template

```markdown
# [Project Name] WIKI

Project slug: `project-slug`
Status: `active_project`
Owner: `[user-id]`
Curator: `[user-id or team]`
Sensitivity: `normal`

## Purpose

[One or two sentences.]

## Where To Look

1. `official/` for trusted project knowledge
2. `reviewed/` for human-reviewed project knowledge
3. `_index.md` for navigation
4. `sources/` for source material
5. `notes/` for low-friction shared notes

## Search Keywords

[project name], [system name], [acronym], [business phrase]

## Related Projects

- none yet
```

## Project Index Template

```markdown
# [Project Name] Index

Search keywords: [project name], [system name], [acronym]

## Official

- No official project notes yet.

## Reviewed

- No reviewed project notes yet.

## Sources

- No source files yet.

## Notes

- No shared project notes yet.

## Open Questions

- No open project questions yet.
```

## Creation Workflow

1. User asks for a project mini-wiki or curator identifies need.
2. Curator checks `_index/by_project.md` for duplicates.
3. Curator chooses `project_slug`.
4. Curator creates the minimum folder shell.
5. Curator creates `README.md` and `_index.md`.
6. Curator adds the project to root `_index/by_project.md`.
7. Curator writes an event under `_index/events/`.
8. Project owner adds first source or official starter page.

## Permission Guidance

V0 default:

- most members can read the project mini-wiki,
- contributors can write to project `sources/` and `notes/`,
- project `official/` is curator/owner protected where SharePoint permissions allow,
- project `README.md` and `_index.md` are curator-owned,
- project official edits still go through root `_patches/open/`.

If SharePoint cannot express these permissions cleanly, use convention-only protection for a private rehearsal and record the risk in [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]].

## Anti-Sprawl Rules

Do not create a new project mini-wiki when:

- the content belongs in an existing project,
- the project has no owner,
- the topic is temporary and can live in `notes/`,
- the only reason is to avoid deciding metadata,
- the folder would duplicate another project with a different name.

If uncertain, create a proposal or note first, not a permanent project folder.

## V0 Recommendation

Use curator-created project mini-wikis for V0.

Allow contributor-proposed project folders only as `draft_project` and only when clearly labeled in `README.md`.
