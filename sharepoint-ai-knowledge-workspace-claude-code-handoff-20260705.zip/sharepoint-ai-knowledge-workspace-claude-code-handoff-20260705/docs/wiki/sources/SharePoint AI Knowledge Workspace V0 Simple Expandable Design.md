---
type: source
title: "SharePoint AI Knowledge Workspace V0 Simple Expandable Design"
status: ingested
created: 2026-07-05
updated: 2026-07-05
tags:
  - source
  - sharepoint
  - onedrive
  - v0
  - design
source_file: ".raw/sharepoint_ai_knowledge_workspace_v0_simple_expandable_design.md"
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
---

# SharePoint AI Knowledge Workspace V0 Simple Expandable Design

## Summary

This source tightens the SharePoint / OneDrive Markdown workspace design around a smaller V0.

The core principle is:

```text
V0はシンプルにする。
ただし、将来拡張できる逃げ道だけは構造に埋め込む。
```

The design should prove only one thing first:

```text
1件のナレッジが、安全に循環できること。
```

## Key Points

- Normal users should see the system as `Project WIKI + Notifications + Official Patch`.
- The first user-facing flow should be: put project material in the project WIKI, ask Claude Code to extract, and check only actionable notifications.
- V0 should not require Python helpers, MCP, GROWI, search databases, automatic crawling, automatic official edits, or broad rollout.
- The practical minimum folder structure can be smaller than the current full template pack.
- `_system/` should start with only the most essential rule files: `users.md`, `status_rules.md`, `write_rules.md`, and `patch_rules.md`.
- Project mini-wikis are the main user-facing knowledge surface.
- `status`, `project`, `owner`, `source_files`, `generated_by`, `_index/events/`, `_patches/open/`, root `_system/`, and project mini-wikis are the expansion hooks.
- Migration should happen only after observed operational pain, not tool enthusiasm.

## Design Impact

This source changes the emphasis of the current design:

- From a complete V0 template pack to a **simple minimum profile plus expansion pack**.
- From root `sources/extracted/proposals/reviewed` as prominent folders to **project-local source/reviewed/notes first**.
- From many `_system` rule files as required to **four minimum rule files plus optional post-pilot rules**.
- From proving a whole knowledge management system to proving one safe knowledge circulation loop.

## Reflected In

- [[SharePoint AI Knowledge Workspace]]
- [[SharePoint AI Knowledge Workspace Template Pack]]
- [[SharePoint AI Knowledge Workspace V0 Operating Flow]]
- [[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]

## Open Follow-Up

The current design should retain the broader template details, but they should be framed as optional expansion surfaces until the first manual pilot proves pain.
