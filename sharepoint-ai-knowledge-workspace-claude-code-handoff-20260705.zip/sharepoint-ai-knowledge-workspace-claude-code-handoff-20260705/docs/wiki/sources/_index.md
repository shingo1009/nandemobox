---
type: index
title: "Sources Index"
status: evergreen
created: 2026-07-02
updated: 2026-07-05
tags: [index, sources]
---

# Sources

Use this folder for summaries of immutable source material stored in `.raw/`.

## Sources

- [[Knowledge Pull Request Hub Design]]: 2026-07-02 design document for a FastAPI + MCP knowledge proposal hub.
- [[SharePoint AI Knowledge Workspace Design]]: 2026-07-04 design document for a SharePoint / OneDrive synchronized Markdown knowledge workspace.
- [[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]: 2026-07-05 source that tightens the workspace around a simple but expandable V0.
