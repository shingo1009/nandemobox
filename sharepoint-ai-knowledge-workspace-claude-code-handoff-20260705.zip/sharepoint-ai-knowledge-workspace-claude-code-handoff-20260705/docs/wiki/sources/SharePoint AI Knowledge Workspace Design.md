---
type: source
title: "SharePoint AI Knowledge Workspace Design"
source_type: design-document
author: "nishizawa"
date_published: 2026-07-04
confidence: high
created: 2026-07-04
updated: 2026-07-04
tags:
  - source
  - design
  - sharepoint
  - knowledge-workspace
status: ingested
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Project]]"
  - "[[SharePoint AI Knowledge Workspace Design Review]]"
sources:
  - ".raw/sharepoint_ai_knowledge_workspace_design.md"
---

# SharePoint AI Knowledge Workspace Design

Source: `.raw/sharepoint_ai_knowledge_workspace_design.md`

## Summary

This source changes the direction from a server-centered GROWI + MCP architecture toward a simpler SharePoint / OneDrive synchronized Markdown workspace.

The core idea is to treat a shared folder as an AI-readable knowledge workspace rather than a passive file store. Claude Code reads local Markdown files, checks indexes and notifications, extracts knowledge from sources, proposes common knowledge, reviews duplicates and conflicts, and creates patches instead of directly editing official knowledge.

## Key Claims

- SharePoint / OneDrive should be used first because it is already an internal standard, synchronizes as local files, and avoids early WSL, MCP, memory, and per-user setup friction.
- The workspace needs status separation: `source`, `extracted`, `proposal`, `reviewed`, `official`, `deprecated`, and `archived`.
- AI may write to `extracted/`, `proposals/`, `_reviews/open/`, `_notifications/{user}/inbox/`, `_patches/open/`, and generated `_index/` files.
- AI should not directly update `official/`, `_system/`, another person's `people/` folder, archive contents, or original source files.
- Low and medium risk knowledge should not wait for full consensus; it can move to `reviewed` after at least one review, then be corrected later through patch flow.
- Python should handle deterministic file operations, hash tracking, metadata validation, and index generation. Claude Code should handle semantic review, summarization, contradiction detection, proposal drafting, and notification text.
- The first value target is: when Claude Code opens the workspace, the user sees relevant knowledge changes, duplicates, and improvement proposals.

## Entities Mentioned

- [[SharePoint AI Knowledge Workspace Project]]: target project and operating model.
- Claude Code: local AI agent expected to read and maintain the Markdown workspace.
- SharePoint / OneDrive: synchronization and access-control substrate.
- GROWI + MCP: deferred server architecture, not the first implementation target.

## Concepts Introduced

- [[Markdown Knowledge Workspace]]: shared Markdown folder treated as an AI-operable knowledge system.
- [[AI Review Notification]]: file-based personal notification for AI-detected review work.
- `reviewed before official`: lightweight adoption path that avoids blocking on unanimous approval.
- `patch before direct edit`: safety boundary for AI-generated changes.

## Design Implications

- The most important product decision is not tool choice; it is the boundary between source, AI-generated candidate, reviewed knowledge, and official knowledge.
- The strongest MVP is operational, not technical: a folder structure, `CLAUDE.md`, minimal indexes, personal notification inboxes, and explicit write rules.
- The largest risk is workspace sprawl. The design must keep the first daily flow small enough that a user can understand where to look in under a minute.

## Open Questions

- Who is allowed to promote `reviewed` knowledge into `official`?
- How are owner names and user identifiers standardized across PCs?
- What is the minimum metadata set that users can reliably maintain without making contribution feel heavy?
- How should SharePoint sync conflicts be detected and repaired?
- Should the first MVP include Python commands, or should it start as pure Markdown conventions plus Claude Code instructions?
