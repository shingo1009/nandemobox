---
type: project
title: "SharePoint AI Knowledge Workspace Project"
status: active
created: 2026-07-04
updated: 2026-07-05
tags:
  - project
  - sharepoint
  - knowledge-workspace
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
  - "[[SharePoint AI Knowledge Workspace Objective Completion Audit]]"
  - "[[2026-07-05 SharePoint Workspace Evidence Track Order]]"
---

# SharePoint AI Knowledge Workspace Project

## Purpose

Create a practical internal knowledge sharing workspace where team members use a SharePoint / OneDrive synced folder as a Markdown knowledge base that Claude Code can read, review, and maintain.

## Current Status

V0 design and tabletop simulation are converged enough for a private rehearsal.

Coding and folder creation are intentionally paused until the user asks to move from design to setup.

Current target: Simple Minimum Profile.

Current default next move:

```text
choose scenario
  -> materialize private Simple Minimum folder
  -> record pilot evidence
  -> run kw-maint doctor
  -> validate SharePoint / OneDrive
```

Current verdict:

- Tabletop design is strong.
- Real files are not created yet.
- `kw-maint doctor` is designed but not implemented.
- SharePoint / OneDrive behavior is not validated yet.

## Scope

In scope:

- Shared Markdown folder structure.
- Lightweight project mini-wikis in the shared area so each project can be searched and browsed without local sync.
- `CLAUDE.md` operating rules for Claude Code.
- Project-local source, notes, reviewed, and official knowledge lifecycle.
- Project-local `.raw` converted Markdown evidence when Excel, PowerPoint, PDF, Word, or similar original files are used for ingest.
- Personal file-based notifications.
- AI review outputs for duplicates, conflicts, outdated content, metadata gaps, and official candidates.
- Patch-first update flow for official or other-owner files.
- Admin-run Python support for deterministic maintenance, starting with dry-run scan, validation, conflict scan, and generated index diff.

Out of scope for the first design cycle:

- GROWI server rollout.
- MCP server requirement for all users.
- Fully automated Teams / SharePoint crawling.
- Direct AI edits to official knowledge.
- Strict unanimous approval workflows.

## Core Shape

V0 is:

```text
Project WIKI + Notifications + Official Patch
```

Runtime is:

```text
3 Claude behaviors
  + 4 required _system files
  + admin-run kw-maint doctor
  + human authority
```

The first pilot should prove one ordinary source can move through the loop:

```text
source
  -> reviewed knowledge
  -> optional official patch
  -> event
  -> pilot evidence note
```

## Control Pages

Use these first:

- [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]: choose the next evidence scenario.
- [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]: create the private Simple Minimum folder when requested.
- [[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]: check actual generated/manual pilot files.
- [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]: implement or test the first no-write Python helper.
- [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]: validate SharePoint / OneDrive behavior.
- [[SharePoint AI Knowledge Workspace Objective Completion Audit]]: see what remains unproven.

Use these for boundaries:

- [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]: keep Claude behavior small.
- [[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]: handle converted Excel/PPTX/document Markdown.
- [[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]: handle article merge cleanup.
- [[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]: later motivation and common-candidate loop.
- [[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]: decide when to add tooling beyond V0.

## Key Decisions

- [[2026-07-04 SharePoint OneDrive First Knowledge Workspace]]: use SharePoint / OneDrive synchronized Markdown as the first substrate.
- [[2026-07-04 V0 Workspace Convention Choices]]: proposed V0 conventions for proposal promotion, patching, filenames, identity, and sync conflicts.
- [[2026-07-04 Official Folder Permission Protection]]: proposed protection policy for `official/`.
- [[2026-07-04 Markdown Playbooks Before Technical Skills]]: start with Markdown playbooks before implementing technical skills.
- [[2026-07-04 Link Playbooks From CLAUDE Not README]]: keep README short and route Claude Code to playbooks through `CLAUDE.md`.
- [[2026-07-05 Admin Python First Maintenance]]: deterministic maintenance should be run by an admin Python process, initially Nishizawa's PC, to reduce repeated client-side Claude Code usage.
- [[2026-07-05 SharePoint Workspace Evidence Track Order]]: use private materialization, then `kw-maint doctor`, then SharePoint / OneDrive validation as the default evidence order.

## Operating Principle

The project should prioritize daily usability over architectural completeness.

For V0, the operating model is:

```text
Project WIKI + Notifications + Official Patch
```

The simplest valuable loop is:

```text
put one source note in a project WIKI
  -> Claude extracts candidate knowledge
  -> Claude creates a review item or notification
  -> human reviews
  -> accepted knowledge goes to project reviewed/
  -> official knowledge is changed only through a patch path
```

## Open Questions

- Which scenario should the first real rehearsal use: note-only, raw-converted, Python-first, or SharePoint-first?
- Which SharePoint / OneDrive assumptions fail in this tenant?
- Does the three-behavior Claude model feel natural in actual use?
- Which migration thresholds need recalibration after real content exists?

## Next Actions

1. Use [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]] to choose one evidence scenario.
2. If the user asks to set up files, use [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]].
3. Record the rehearsal as `_reviews/open/pilot-evidence-YYYYMMDD.md` plus one `_index/events/` pointer.
4. Implement or run `kw-maint doctor` only after a real or fixture folder exists.
5. Validate SharePoint / OneDrive before any team rollout.

Do not add more V0 Claude skills until real evidence shows the three-behavior model is insufficient.
