---
type: index
title: "Projects Index"
status: evergreen
created: 2026-07-02
updated: 2026-07-05
tags:
  - index
  - projects
---

# Projects

Use this folder for each personal development project, app, tool, experiment, or long-running workstream.

## Current Focus

- [[SharePoint AI Knowledge Workspace Project]]: active design work for a SharePoint / OneDrive Markdown workspace maintained with Claude Code.

## Background Projects

- [[Knowledge Pull Request Hub Project]]: central knowledge hub concept and future implementation project.

## How To Read This Area

- Start with the current-focus project page.
- Use [[specs/_index]] for product and runtime details.
- Use [[research/_index]] for simulations, audits, and evidence notes.
- Use [[decisions/_index]] for irreversible or expensive-to-change choices.

## Paused or Archived

- _No archived projects yet._
