---
type: comparison
title: "SharePoint Workspace Structure Options"
status: draft
created: 2026-07-04
updated: 2026-07-04
tags:
  - comparison
  - information-architecture
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
---

# SharePoint Workspace Structure Options

## Question

Should the workspace start with one global lifecycle structure, project-specific lifecycle structures, or a hybrid?

## Option A: Global Lifecycle Folders

```text
sources/
extracted/
proposals/
reviewed/
official/
```

Project is metadata.

Pros:

- Easiest to teach.
- Claude Code has fewer places to inspect.
- Index generation is simpler.
- Good for V0.

Cons:

- Can become crowded as project count grows.
- Permissions are harder if projects have different confidentiality.

Verdict: best for first pilot.

## Option B: Project-Scoped Lifecycle Folders

```text
projects/active/project-a/sources/
projects/active/project-a/extracted/
projects/active/project-a/proposals/
projects/active/project-a/reviewed/
projects/active/project-a/official/
```

Pros:

- Better project isolation.
- Easier to archive a whole project.
- Better fit for project-specific permissions.

Cons:

- Harder onboarding.
- More duplicated folder structure.
- Cross-project knowledge becomes harder to find.
- Claude may need to inspect more paths.

Verdict: useful after the first pilot proves the lifecycle.

## Option C: Hybrid

```text
sources/
extracted/
proposals/
reviewed/
official/
projects/active/project-a/
```

Global folders hold common flow. Project folders hold project-specific source collections or summaries.

Pros:

- Keeps first flow simple.
- Allows project pages without fully duplicating lifecycle folders.
- Can evolve toward project-scoped folders later.

Cons:

- Requires clear rules for when content belongs in global vs project.
- Some duplication is likely.

Verdict: likely target after V0.

## Option D: Lightweight Project Mini-Wikis

```text
projects/project-a/
├─ README.md
├─ _index.md
├─ official/
├─ reviewed/
├─ sources/
└─ notes/
```

Root folders still hold shared rules, notifications, review queues, patch queues, and cross-project indexes.

Pros:

- Makes each project searchable and browsable in SharePoint without local sync.
- Gives every project a small independent WIKI surface.
- Avoids duplicating the full lifecycle and governance folder set.
- Keeps cross-project workflows centralized.

Cons:

- Requires clearer root-vs-project rules.
- Adds one more path for Claude to inspect when project is known.
- Needs a project creation convention to avoid folder sprawl.

Verdict: updated V0 target after the user's new requirement.

## Recommendation

Start with Option D for V0: lightweight project mini-wikis plus root-level workflow queues.

Use Option B only if a later pilot proves that each project needs fully independent notifications, patches, reviews, and system rules.

The design should avoid full duplicated lifecycle structure until users have proven that they need it.
