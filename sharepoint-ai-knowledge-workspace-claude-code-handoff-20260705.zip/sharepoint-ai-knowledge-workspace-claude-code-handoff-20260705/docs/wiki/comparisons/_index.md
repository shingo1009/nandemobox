---
type: index
title: "Comparisons Index"
status: evergreen
created: 2026-07-02
updated: 2026-07-04
tags: [index, comparisons]
---

# Comparisons

## Active

- [[SharePoint Workspace Structure Options]]: compares global, project-scoped, hybrid, and lightweight project mini-wiki structures for the SharePoint workspace.
- [[Pilot Sample Flow Alternatives]]: compares candidate first pilot samples for the V0 workspace flow.

Use this folder for technology comparisons, build-vs-buy analysis, architecture tradeoffs, and option matrices.
