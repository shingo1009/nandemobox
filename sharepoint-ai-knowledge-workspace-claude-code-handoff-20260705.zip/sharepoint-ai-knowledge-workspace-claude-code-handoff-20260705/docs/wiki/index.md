---
type: meta
title: "Wiki Index"
status: evergreen
created: 2026-07-02
updated: 2026-07-05
tags:
  - meta
  - index
related:
  - "[[overview]]"
  - "[[log]]"
  - "[[hot]]"
---

# Wiki Index

Purpose: personal development workspace for saving specifications, decisions, implementation notes, and project status.

Navigation: [[overview]] | [[log]] | [[hot]]

## Primary Areas

- [[specs/_index]]: product and feature specifications.
- [[decisions/_index]]: architecture and product decisions.
- [[projects/_index]]: active apps, tools, experiments, and workstreams.
- [[research/_index]]: simulations, audits, source reviews, and reference synthesis.
- [[dev-log/_index]]: chronological development records.
- [[modules/_index]]: reusable technical components and code areas.
- [[milestones/_index]]: releases, checkpoints, and delivery plans.

## Supporting Areas

- [[sources/_index]]: source documents from `.raw/`.
- [[entities/_index]]: people, organizations, tools, libraries, APIs, and products.
- [[concepts/_index]]: reusable ideas, patterns, and technical concepts.
- [[questions/_index]]: answered questions worth preserving.
- [[comparisons/_index]]: tradeoff analyses and option comparisons.
- [[meta/scaffold-2026-07-02]]: initial scaffold record.

## Current Focus

- [[Knowledge Pull Request Hub Project]]: local-to-central knowledge proposal system built around FastAPI, MCP, Markdown, and semantic review.
- [[SharePoint AI Knowledge Workspace Project]]: current design direction for a SharePoint / OneDrive Markdown workspace maintained with Claude Code.

## SharePoint Workspace Entry Points

- [[SharePoint AI Knowledge Workspace]]: compact V0 specification.
- [[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]: choose the next evidence scenario.
- [[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]: plan for creating the private Simple Minimum pilot folder.
- [[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]: expected behavior for the first admin Python doctor.
- [[2026-07-05 SharePoint Workspace Evidence Track Order]]: default evidence order before rollout.
- [[2026-07-05 Admin Python First Maintenance]]: decision to keep deterministic maintenance in admin-run Python.

## Important Decisions

- [[2026-07-02 API First MCP Second]]: FastAPI is the core product API; MCP is a thin AI-client adapter.
- [[2026-07-04 SharePoint OneDrive First Knowledge Workspace]]: use SharePoint / OneDrive synchronized Markdown as the first practical substrate.
- [[2026-07-04 V0 Workspace Convention Choices]]: proposed conventions for accepted proposals, official patches, filenames, identity, and sync conflict handling.
- [[2026-07-04 Official Folder Permission Protection]]: proposed convention-plus-permission protection for the `official/` folder.
- [[2026-07-05 Admin Python First Maintenance]]: prefer admin-run Python automation for deterministic maintenance so client PCs spend fewer Claude Code tokens.
- [[2026-07-05 SharePoint Workspace Evidence Track Order]]: default next evidence order is private materialization, then `kw-maint doctor`, then SharePoint / OneDrive validation.

## Detail Catalogs

- [[specs/_index]]: grouped specification shelf.
- [[research/_index]]: grouped simulation and audit shelf.
- [[decisions/_index]]: full decision list.
- [[log]]: append-only operation history.

## Current Concepts And Modules

- [[Knowledge Pull Request]]: proposal workflow for knowledge changes.
- [[Knowledge Claim]]: smallest officializable unit extracted from local changes.
- [[Semantic Diff and Impact Diff]]: meaning and impact review aids.
- [[Knowledge Gap]]: verified search failure that can later become a proposal.
- [[Markdown Knowledge Workspace]]: shared Markdown folder with AI-readable lifecycle rules.
- [[AI Review Notification]]: file-based review notification routed to a person's inbox.
- [[FastAPI Knowledge Hub]]: core backend and API surface.
- [[Local Knowledge Agent]]: local CLI or agent for scan, pull, propose, and sync.
