---
type: research
title: "SharePoint AI Knowledge Workspace Pilot Dry Run Validation"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - dry-run
  - pilot
  - validation
related:
  - "[[SharePoint AI Knowledge Workspace Pilot Sample Flow]]"
  - "[[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]]"
  - "[[SharePoint AI Knowledge Workspace Article Quality Rubric]]"
  - "[[SharePoint AI Knowledge Workspace Archive TTL Policy]]"
---

# SharePoint AI Knowledge Workspace Pilot Dry Run Validation

## Purpose

Validate the current lifecycle state machine and article quality rubric against the pilot sample without creating a real shared folder.

This is a tabletop dry run. It checks whether the flow is understandable, safe, and not overly bureaucratic.

## Input

Pilot sample:

- [[SharePoint AI Knowledge Workspace Pilot Sample Flow]]

Relevant design pages:

- [[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]]
- [[SharePoint AI Knowledge Workspace Article Quality Rubric]]
- [[SharePoint AI Knowledge Workspace V0 Operating Flow]]
- [[SharePoint AI Knowledge Workspace Archive TTL Policy]]

## Dry Run Trace

| Step | Pilot Artifact | Lifecycle State | Result |
|---|---|---|---|
| 1 | `sources/meetings/2026-07-04_meeting_external-if-review.md` | source | fits state machine |
| 2 | `extracted/ext-20260704-external-if-review.md` | extracted | fits state machine |
| 3 | `proposals/prp-20260704-external-if-review-checklist.md` | proposal | fits state machine |
| 4 | review output | review open | needs explicit `_reviews/open/` file in sample |
| 5 | `_notifications/nishizawa/inbox/...` | notification `needs_action` | fits notification lifecycle |
| 6 | `_patches/open/patch-20260704-external-interface-review-checklist.md` | patch open | fits state machine |
| 7 | `_index/events/...` | event trace | fits audit trail |
| 8 | no official edit | official protected | expected |

## Quality Rubric Trial

Target:

- `proposals/prp-20260704-external-if-review-checklist.md`

Rubric result:

```text
Verdict: patch_official
Risk: medium
Quality:
- Source backing: pass
- Scope control: warning
- Status clarity: pass
- Sensitivity: pass
- Duplicate/conflict: warning
- Actionability: pass
Main issues:
- Responsibility boundary wording can become project-specific if written too strongly.
- Duplicate/conflict check depends on the starter official page and any reviewed design-review notes.
Next action:
- Draft patch to official target with "confirm responsibility boundary" wording.
```

Interpretation:

- The rubric is useful and not too heavy for a medium-risk checklist proposal.
- The sample should explicitly create a review file under `_reviews/open/` so the verdict is durable.
- The proposal should avoid turning one meeting's decision into universal policy.

## Lifecycle Trial

The lifecycle state machine works for the sample, but one transition needs clarification:

```text
proposal -> review open -> patch open
```

The current sample jumps from quality review text to notification and patch. For durable operation, the review verdict should be saved as:

```text
_reviews/open/rev-20260704-external-if-review-checklist.md
```

Then the notification and patch can link to the review file.

## Archive TTL Trial

Archive behavior for the pilot sample:

| Artifact | TTL Handling |
|---|---|
| source meeting note | keep; no automatic TTL |
| extraction | archive candidate after 60 days only if proposal/patch lineage is preserved |
| proposal | if patch is applied, mark superseded or archive candidate after 30 days |
| review file | if resolved, archive candidate after 60 days |
| notification | resolved after owner decision; archive candidate after 30 days |
| patch | if applied, keep until event trace is clear; archive candidate after 30 days |
| event file | keep; no archive in V0 |
| official page | never automatic archive |

## Findings

| Finding | Severity | Adjustment |
|---|---|---|
| Review output needs a durable file | medium | add `_reviews/open/` expected output to pilot sample |
| Rubric is useful for medium-risk proposal | low | keep compact format |
| Responsibility boundary wording needs caution | medium | use "confirm" language rather than fixed ownership |
| Archive policy should preserve evidence chain | high | never archive source if it is only evidence |
| Lifecycle is understandable | low | no simplification needed yet |

## Verdict

The lifecycle state machine and quality rubric are good enough for a controlled dry run.

The pilot sample should be updated to include an explicit review file and to link notification, patch, and event outputs back to that review file.
