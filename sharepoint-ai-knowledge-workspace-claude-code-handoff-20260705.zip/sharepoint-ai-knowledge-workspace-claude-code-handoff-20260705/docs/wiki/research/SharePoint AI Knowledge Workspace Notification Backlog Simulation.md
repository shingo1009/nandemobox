---
type: research
title: "SharePoint AI Knowledge Workspace Notification Backlog Simulation"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - simulation
  - notifications
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace Usage Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Simulation Findings]]"
  - "[[SharePoint AI Knowledge Workspace Shared Skill Playbooks]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
---

# SharePoint AI Knowledge Workspace Notification Backlog Simulation

## Purpose

Simulate what happens when file-based notifications accumulate for one week in a SharePoint / OneDrive Markdown workspace.

The goal is to reveal usability problems that are not visible when testing only one clean source-to-proposal flow.

## Simulation Scope

Actors:

- `nishizawa`: curator and frequent reviewer.
- `sato`: contributor who checks notifications once or twice per week.
- `tanaka`: occasional reviewer.
- Claude Code sessions on each user's synced folder.
- OneDrive / SharePoint sync with normal delay.

Folders exercised:

- `_notifications/{user}/inbox/`
- `_notifications/{user}/digest.md`
- `_index/notification_summary.md`
- `_index/events/`
- `proposals/`
- `_reviews/open/`
- `_patches/open/`

## Scenario

Five workdays pass after the first pilot starts. Several proposals, review findings, and patch requests are created. Users do not all check notifications daily.

## Timeline

### Day 1: Healthy Start

Three notifications exist:

- one proposal review request,
- one patch approval request,
- one FYI about a new extracted source.

This is manageable.

### Day 2: Duplicate Workflow Notifications

Claude creates separate notifications for:

- proposal created,
- proposal reviewed,
- patch drafted,
- patch needs approval.

Risk observed:

- These are one conceptual workflow, but they appear as multiple unrelated files.
- A user cannot tell which file is the latest actionable state.

### Day 3: Low-Severity Notifications Hide Important Items

FYI notifications and "index stale" notices sit beside approval requests.

Risk observed:

- The inbox has no strong distinction between `needs_action` and `FYI`.
- A user who opens the folder manually may miss the one item that needs a decision.

### Day 4: Stale Items Have No Lifecycle

Some notifications are no longer useful because a proposal was already revised.

Risk observed:

- Nothing marks old notifications as `superseded`, `resolved`, or `stale`.
- Claude may summarize obsolete items as if they still need attention.

### Day 5: Digest Becomes Necessary

The inbox now has 12 files for one user.

Risk observed:

- Daily triage becomes a mini research task.
- Users will stop checking notifications if every check requires reading many files.

## Key Findings

| Finding | Severity | Design Impact |
|---|---|---|
| Notification files need lifecycle status | high | add status and action semantics |
| A workflow needs one current thread per owner | high | avoid many files for one workflow |
| FYI and action items must be separated | high | reduce missed approvals |
| Stale notifications need TTL or superseded rules | medium | prevent old files from polluting triage |
| Digest is not optional after the first week | medium | batch low-severity items |
| Notification summary should be curator-owned | medium | avoid multi-user conflict on summary file |

## Recommended Adjustments

### Adjustment 1: Add Notification Status Rules

Create `_system/notification_rules.md`.

Required notification status values:

- `needs_action`
- `waiting`
- `deferred`
- `resolved`
- `superseded`
- `fyi`

Daily triage should show `needs_action` first, then `waiting`, then `deferred`. `resolved`, `superseded`, and `fyi` should not interrupt the user unless requested.

### Adjustment 2: Prefer Workflow Threads

Use one notification thread per workflow and user:

```text
_notifications/nishizawa/inbox/ntf-20260704-external-if-review.md
```

If the same workflow progresses, append a dated section to the thread instead of creating a new notification.

### Adjustment 3: Add Digest Threshold

When more than five low-severity notifications exist for a user, Claude should update or propose updating:

```text
_notifications/{user}/digest.md
```

The digest should not replace action items. It should absorb FYI and low-priority observations.

### Adjustment 4: Make Staleness Explicit

If a notification is made obsolete by a newer review, patch, or decision, update the old thread status to `superseded` when allowed, or create an event file saying it should be superseded.

## Simulation Verdict

File-based notifications are workable for V0, but only if they have lifecycle status and strong triage rules.

Without these rules, the notification system will look usable in a one-flow demo and become noisy after a normal week of real use.
