---
type: research
title: "SharePoint AI Knowledge Workspace README Onboarding Dry Run"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - onboarding
  - readme
  - design-validation
related:
  - "[[SharePoint AI Knowledge Workspace README Draft]]"
  - "[[SharePoint AI Knowledge Workspace Simplicity Optimization Pass]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Initial File Contents]]"
---

# SharePoint AI Knowledge Workspace README Onboarding Dry Run

## Purpose

Dry-run the root README and project README from the viewpoint of a first-time shared-folder user.

This is still design work. It does not create a pilot folder.

## Test User Assumption

The user:

- has access to the SharePoint folder,
- knows the project name loosely,
- has one meeting note or review memo,
- does not know the lifecycle model,
- wants a useful result in the first few minutes.

## First-Minute Task

The README should let the user complete one of these without reading `CLAUDE.md` or `_system/`:

1. find the right project WIKI,
2. place a project source,
3. ask Claude Code for extraction,
4. check personal action items.

## Current README Friction

| Finding | Impact | Design Adjustment |
|---|---|---|
| Start Here is split into trusted knowledge, attention, and adding material. | Good content, but the first choice is still a small taxonomy exercise. | Lead with three user actions: add, check, ask. |
| Folder Guide is useful but too prominent for first-run onboarding. | New users may try to understand every folder before acting. | Move folder guide below Quick Start and keep it short. |
| Status Meanings belong more to Claude/curator than first-run users. | It teaches lifecycle vocabulary before the user has a task. | Replace with a short trust note; keep status table in `_system/status_rules.md`. |
| Trust Rule is important but too detailed for the first screen. | It can make onboarding feel like policy. | Keep one plain-language sentence in README; detailed order stays in `CLAUDE.md`. |
| Project README lacks "last reviewed". | Users cannot judge freshness quickly. | Add `Last reviewed` and `Search keywords` to project README. |

## Optimized Root README Shape

The root README should use this order:

1. one-sentence purpose,
2. Quick Start with three actions,
3. where to find project knowledge,
4. useful Claude prompts,
5. short trust and official-edit warning,
6. compact folder guide,
7. owner/curator contact.

## Optimized Project README Shape

Each project README should use this order:

1. project purpose,
2. current state and last reviewed,
3. search keywords,
4. where to look,
5. where to add new material,
6. owner and curator.

## Design Decision

The root README is not the policy manual.

It should be a launchpad. The detailed lifecycle, trust order, patch rules, metadata rules, and status model belong in `CLAUDE.md` and `_system/`.

## Acceptance Test

A draft README passes this dry run when a new user can answer these in under one minute:

- Where do I put a project meeting note?
- How do I ask Claude for extraction?
- Where do I check my action items?
- Which area should I not edit directly?
- Who owns the workspace or project?

## Follow-Up

Update [[SharePoint AI Knowledge Workspace README Draft]] and the sample project README in [[SharePoint AI Knowledge Workspace Initial File Contents]] to follow this shape.
