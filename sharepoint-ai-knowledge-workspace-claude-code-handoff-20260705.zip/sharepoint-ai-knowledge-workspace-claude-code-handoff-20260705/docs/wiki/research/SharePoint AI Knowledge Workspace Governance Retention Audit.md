---
type: research
title: "SharePoint AI Knowledge Workspace Governance Retention Audit"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - governance
  - onboarding
  - design-validation
related:
  - "[[SharePoint AI Knowledge Workspace README Onboarding Dry Run]]"
  - "[[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]]"
  - "[[SharePoint AI Knowledge Workspace Initial File Contents]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
---

# SharePoint AI Knowledge Workspace Governance Retention Audit

## Purpose

Check that simplifying the human README does not weaken the governance model.

The README was intentionally reduced to a launchpad: add project material, check notifications, and ask Claude Code for extraction. This audit verifies that the detailed rules removed from README still live in the agent and curator rule layer.

## Audit Question

When a normal user sees a simple README, can Claude Code still enforce:

- trust order,
- status meanings,
- write boundaries,
- notification lifecycle,
- patch-first official updates,
- archive safety,
- project mini-wiki protection?

## Coverage Matrix

| Rule Area | Should Live In | Current Evidence | Status |
|---|---|---|---|
| Read order | `CLAUDE.md` | [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]], [[SharePoint AI Knowledge Workspace Initial File Contents]] | covered |
| Trust order | `CLAUDE.md` and `_system/status_rules.md` | project official, root official, reviewed, proposal, extracted, source order is present | covered |
| Status meanings | `_system/status_rules.md` | lifecycle statuses remain in rule files | covered |
| Write boundaries | `CLAUDE.md` and `_system/write_rules.md` | root and project `official/`, project README, project `_index.md`, `_system/`, and other users' folders are protected | covered after update |
| Notification lifecycle | `_system/notification_rules.md` | action-first statuses and digest rule remain present | covered |
| Patch-first official updates | `_system/patch_rules.md` | required metadata, same-target detection, and serialized apply remain present | covered |
| Archive safety | `_system/archive_rules.md` | archive is preservation; source and official files are protected from automatic archive | covered |
| Project mini-wiki protection | `CLAUDE.md`, `_system/write_rules.md`, `_system/permission_rules.md` | project `official/`, README, and `_index.md` are protected; project `sources/`, `notes/`, and approved `reviewed/` writes are allowed | covered after update |

## Findings

### 1. README Simplification Is Safe If Rule Layer Stays Explicit

The root README can stay small because the detailed governance is still present in `CLAUDE.md` and `_system/`.

This supports the current split:

- README: first action and confidence.
- `CLAUDE.md`: agent startup contract.
- `_system/`: detailed rule references.

### 2. Minimal CLAUDE Rules Needed Project Write Boundary Alignment

The main `CLAUDE.md` candidate already included project mini-wiki read/write boundaries.

However, the standalone `_system/write_rules.md` section in [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]] was still closer to the older root-only model. It needed to explicitly include:

- allowed project `notes/`,
- allowed project `sources/`,
- approved project `reviewed/`,
- protected project `official/`,
- protected project README,
- protected project `_index.md`,
- protected original source files.

### 3. Patch Rules Need Project Target Examples

Patch rules should show that `target_file` can point to either:

- `official/...` for cross-project common knowledge,
- `projects/{project_slug}/official/...` for project-specific official knowledge.

This avoids accidental direct edits to project official pages.

## Governance Retention Rule

Any future simplification of human-facing docs must pass this check:

> If a rule is removed from README, it must either remain in `CLAUDE.md` / `_system/`, or be intentionally removed from the design.

This prevents simplicity from becoming silent policy loss.

## Recommendation

Keep the README simple, but treat [[SharePoint AI Knowledge Workspace Minimal CLAUDE Rules]] and [[SharePoint AI Knowledge Workspace Initial File Contents]] as the authoritative governance layer for V0.

Before pilot materialization, compare the actual generated `README.md`, `CLAUDE.md`, and `_system/*.md` files against this audit.
