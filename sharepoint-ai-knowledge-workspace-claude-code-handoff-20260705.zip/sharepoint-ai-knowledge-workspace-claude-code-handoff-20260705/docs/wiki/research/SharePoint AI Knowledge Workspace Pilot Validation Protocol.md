---
type: research
title: "SharePoint AI Knowledge Workspace Pilot Validation Protocol"
status: draft
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - pilot
  - validation
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace Project]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace Simulation Completion Assessment]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Dry Run Validation]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Risk Checklist]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]]"
---

# SharePoint AI Knowledge Workspace Pilot Validation Protocol

## Purpose

Turn the remaining real SharePoint / OneDrive unknowns into a small validation protocol.

This is still design work. It does not create the pilot folder, change permissions, or start a rollout.

## Validation Principle

Do not prove that the design is theoretically correct. Prove that the simplest V0 can survive real user and cloud-sync behavior.

Each check should answer three questions:

- Can a normal user understand what happened?
- Can Claude Code read the right local files without guessing?
- Can the curator recover or serialize changes if sync, review, or permission behavior is messy?

## Minimum Validation Cast

| Role | Minimum Count | Responsibility |
|---|---:|---|
| Curator | 1 | Owns `official/`, applies patches, observes conflicts and archive candidates. |
| Contributor | 1 | Adds source material and asks Claude to create extraction/proposal outputs. |
| Reviewer | 1 | Reviews a proposal, resolves one notification, and comments on article quality. |

The same person may temporarily play multiple roles for a private rehearsal, but final validation needs at least two real devices or user profiles.

## Test Dataset

Use one non-sensitive source note with enough substance to exercise the lifecycle.

Recommended shape:

- one meeting note,
- one decision-like claim,
- one open question,
- one detail that could become an official patch,
- no credentials, customer secrets, HR content, or private personal data.

Use the pilot sample from [[SharePoint AI Knowledge Workspace Pilot Sample Flow]] unless a better real non-sensitive note is available.

## Validation Scenarios

### 1. Permission Boundary

Goal: confirm whether root and project `official/` areas can be protected without breaking daily use.

Steps:

1. Curator creates or designates the pilot library/folder.
2. Curator applies the intended permission model to root `official/` and the pilot project `official/`.
3. Contributor attempts to edit a project source or note file.
4. Contributor attempts to edit a root `official/` file.
5. Contributor attempts to edit a project `official/` file.
6. Curator confirms whether patch-first editing is still practical.

Pass condition:

- Contributor can work in project `sources/`, project `notes/`, root `_notifications/`, and review/proposal paths.
- Contributor cannot casually change root or project `official/`, or the UI strongly discourages it.
- Curator can still apply an approved patch without special friction.

Design fallback:

- If folder permissions are too brittle, keep `official/` convention-protected and add stronger warning text in `official/README.md` and `CLAUDE.md`.
- If permissions create too many exceptions, restrict only the final official subfolder, not the entire workspace.

### 2. Project Mini-Wiki Creation

Goal: confirm that project-separated shared WIKIs can be created without folder sprawl or unclear ownership.

Steps:

1. Curator checks the root project catalog, such as `_index/by_project.md`, before creating a new project.
2. Curator chooses a stable lowercase ASCII slug.
3. Curator creates the minimum project shell: `README.md`, `_index.md`, `official/`, `reviewed/`, `sources/`, and `notes/`.
4. Curator records owner, curator, purpose, sensitivity, and state in the project README.
5. Curator adds the project to the root project catalog and writes one event.
6. Contributor proposes a separate project folder and marks it as `draft_project` instead of treating it as permanent.

Pass condition:

- Project owner, curator, purpose, sensitivity, and state are obvious from the project entry page.
- The project is discoverable from the root project catalog.
- The slug follows [[SharePoint AI Knowledge Workspace Project Mini Wiki Creation Rules]].
- Contributor-created folders do not silently become permanent project WIKIs.

Design fallback:

- If contributor-created drafts are confusing, require all V0 project mini-wikis to be curator-created.
- If root project catalog edits conflict, keep catalog updates as append-only events and let the curator roll them up.

### 3. Project Searchability

Goal: confirm that users can investigate a project in the shared SharePoint area before syncing or pulling the full project locally.

Steps:

1. Add visible project keywords to the pilot project `README.md` and `_index.md`.
2. Add one project source file and one project official or reviewed file.
3. In SharePoint web, search by project name, acronym, and one topic phrase.
4. Confirm whether README, index, source, and official/reviewed files appear in useful search results for permitted users.
5. Confirm that a user without permission does not see restricted project results.
6. Record any search latency, indexing delay, or misleading result ranking.

Pass condition:

- A permitted user can find the project README or index by project keyword.
- A permitted user can find at least one relevant project knowledge file by topic keyword.
- Permission trimming behaves as expected for restricted content.
- The user can decide whether deeper local sync is needed after searching in the shared area.

Design fallback:

- Add a visible `Search keywords` section to project README and `_index.md`.
- If permission-trimmed behavior is unclear, do not use this pattern for sensitive project content until tenant behavior is verified.
- If SharePoint search ranking is poor, require root `_index/by_project.md` as the first navigation path.

### 4. Version History And Restore

Goal: confirm the recovery path for accidental official changes.

Steps:

1. Curator makes a harmless test edit to a pilot file.
2. Curator checks whether version history is visible.
3. Curator restores or compares a previous version.
4. Curator records the practical restore steps in a pilot note.

Pass condition:

- A previous version can be found and restored or copied.
- The workflow is simple enough that a curator could use it during a real incident.

Design fallback:

- If version restore is unavailable or hidden, V0 must rely more heavily on patch files, extra backups, or delayed official application.

### 5. Local Availability For AI Reading

Goal: confirm Claude Code can read the files that users believe are available locally.

Steps:

1. Contributor syncs the pilot folder.
2. Contributor leaves at least one file online-only if the environment supports that state.
3. Contributor asks the local AI session to read the pilot source and relevant `_system/` files.
4. Contributor marks the pilot folder or required files as locally available if needed.
5. Repeat the read.

Pass condition:

- The daily AI flow can reliably read `CLAUDE.md`, `_system/`, the project README, the project `_index.md`, the target source, and current notification/patch files.
- If local availability matters, the README or client playbook tells users what to do.

Design fallback:

- Add a first-run instruction: make `_system/`, root `_index/`, active project README/index files, active project source/official files, and active personal notification folders available offline.

### 6. File Name And Path Safety

Goal: confirm the template avoids names and depth that OneDrive / SharePoint may reject or rename.

Steps:

1. Review proposed folder names and starter file names.
2. Create a harmless test file using the longest expected project path and naming convention.
3. Confirm the file syncs without automatic rename.
4. Confirm Claude Code can reference the synced path without path confusion.

Pass condition:

- No template file is renamed by OneDrive.
- Path length stays comfortably below the platform limit.
- Filenames avoid characters likely to create sync or cross-platform trouble.

Design fallback:

- Shorten prefixes.
- Avoid deeply nested project folders in V0.
- Shorten project slugs before shortening meaningful article names.
- Prefer `YYYYMMDD-topic.md` over long descriptive filenames for operational files.

### 7. Actual Sync Conflict Observation

Goal: capture the real conflict pattern instead of guessing.

Steps:

1. Two users or devices edit the same low-risk test file while one device is temporarily stale.
2. Let OneDrive sync resolve the situation.
3. Record the resulting filenames, notifications, or UI prompts.
4. Add the observed pattern to the Local Sync Conflict Scanner playbook.

Pass condition:

- The team knows what conflict files look like in its actual environment.
- The daily check can search for the observed pattern.

Design fallback:

- If conflict behavior is unpredictable, move more shared state into append-only event files and keep curator rollups manual.

### 8. Notification Fatigue And Triage

Goal: confirm the notification lifecycle is understandable after several days.

Steps:

1. Generate at least three notification states: `needs_action`, `waiting`, and `fyi`.
2. Reviewer performs daily triage on two separate days.
3. Reviewer resolves one item, defers one item, and leaves one item waiting.
4. Curator checks whether stale or superseded notifications remain visible as active work.

Pass condition:

- A user can identify what needs action within one minute.
- Resolved or superseded items do not keep resurfacing as urgent.
- Digest threshold feels reasonable.

Design fallback:

- Collapse low-value notifications into one weekly digest.
- Make `needs_action` the only default notification category shown in daily triage.

### 9. Patch Serialization

Goal: confirm same-target patches do not accidentally become direct official edits.

Steps:

1. Contributor creates a patch proposal against the starter project official page.
2. Reviewer or curator creates a second patch against the same official page.
3. Curator performs same-target detection.
4. Curator either applies one patch or marks both as `merge_required`.

Pass condition:

- The open patch files contain enough target metadata.
- Curator can detect same-target patches before editing `official/`.
- The root or project official file is edited only through the accepted patch path.

Design fallback:

- Add a stricter patch filename convention with target slug.
- Require a curator queue file before applying official changes.

## Exit Criteria

The validation phase is complete when each scenario has one of these statuses:

- `pass`: use the current V0 rule.
- `pass_with_note`: use the current rule, but document an operational caveat.
- `design_change_required`: update template, README, `CLAUDE.md`, or playbooks before pilot.
- `defer`: acceptable known unknown for a private pilot, not for team rollout.

Do not mark V0 ready for real pilot if any of these are `design_change_required`:

- permission boundary,
- project mini-wiki creation,
- project searchability for team pilot,
- version history or recovery,
- local AI readability,
- patch serialization.

## Minimal Output Record

For each scenario, write one short validation record:

```markdown
# Validation Record: [scenario]

date:
participants:
environment:
status:
evidence:
observed friction:
design change:
next action:
```

These records can later live under `_reviews/open/` or `wiki/research/` depending on whether they are part of the real shared workspace or this design vault.

## Recommendation

This protocol should be the next step after design freeze and before any broad rollout.

The best next design action is to keep this protocol as a gate, not to run it prematurely. A private rehearsal is useful only after the user explicitly decides to materialize a pilot folder.
