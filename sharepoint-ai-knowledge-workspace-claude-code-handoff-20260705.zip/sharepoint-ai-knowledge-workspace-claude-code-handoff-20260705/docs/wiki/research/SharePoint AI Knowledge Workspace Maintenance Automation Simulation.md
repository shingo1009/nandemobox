---
type: research
title: "SharePoint AI Knowledge Workspace Maintenance Automation Simulation"
status: active
created: 2026-07-05
updated: 2026-07-05
tags:
  - research
  - simulation
  - maintenance
  - python
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace Migration Trigger Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Usage Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Simulation Findings]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Operating Simulation]]"
---

# SharePoint AI Knowledge Workspace Maintenance Automation Simulation

## Purpose

Simulate daily and weekly README/index maintenance if deterministic work is moved from Claude Code to Python.

## Scenario A: Daily Small Team Run

Context:

- one curator,
- one contributor,
- one reviewer,
- one project mini-wiki,
- three new project source files,
- two review files,
- one open patch,
- five notification items.

Manual-only result:

- Claude can update indexes, but each update is a shared file edit.
- The curator must remember which summary files need changes.
- README/project index drift is likely after a few days.

Python-maintained result:

1. The admin PC runs the Python maintainer against the synced workspace using the daily profile from [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]].
2. Python scans project files and frontmatter.
3. Python detects three new source files and two review records.
4. Python updates generated blocks in project `_index.md`.
5. Python updates `_index/by_project.md` and `_index/by_topic.md`.
6. Python refreshes `_notifications/{user}/digest.md` counts.
7. Python writes a maintainer event to `_index/events/`.

Claude Code is still needed only when:

- source material needs extraction,
- a review needs explanation,
- a notification needs human-readable context,
- an official patch needs drafting.

Finding: Python reduces daily friction without changing knowledge authority.

Token implication: normal users do not need to spend Claude Code context on checking every index, stale notification, and project list. Claude Code starts from maintained generated views.

## Scenario B: Weekly Topic Distribution

Context:

- five project mini-wikis,
- twenty new events,
- repeated topics across projects,
- users want a weekly "what changed" digest.

Python role:

- group events by `project`, `topic`, `status`, and `owner`,
- count new sources, reviewed notes, open patches, and unresolved notifications,
- produce a weekly generated skeleton.

Claude Code role:

- turn the skeleton into a short readable weekly topic note,
- identify cross-project themes,
- separate "interesting trend" from noisy coincidence,
- draft follow-up questions or patch proposals.

Finding: weekly distribution should be hybrid. Python prepares evidence; Claude writes the useful narrative.

## Scenario C: Multiple WIKI Collection

Context:

- multiple project mini-wikis under one shared workspace,
- each project has local `official/`, `reviewed/`, `sources/`, and `_index.md`,
- common items begin to repeat across projects.

Python role:

- scan all project indexes and frontmatter,
- find repeated topic labels,
- find same or similar filenames,
- find source files that cite the same external artifact,
- produce a "common item candidates" report.

Claude Code role:

- decide whether the repeated item is truly common,
- explain similarities and differences,
- propose a root common page or cross-project patch if useful,
- avoid flattening project-specific context into misleading shared rules.

Finding: Python can detect convergence signals, but Claude should decide whether they deserve shared knowledge.

## Scenario D: Scale Stress

Context:

- more than 500 active Markdown files,
- more than 10 projects,
- several users with notification backlogs,
- several same-target patches.

Without Python:

- manual index updates become brittle,
- stale indexes cause search misses,
- notification digest maintenance becomes noisy,
- Claude spends too much time on file discovery.

With Python:

- generated indexes become the navigation base,
- stale and malformed files are visible,
- notification counts are cheap,
- Claude starts from better evidence,
- client-side Claude Code sessions read fewer files and spend fewer tokens on discovery.

Risk:

- if Python writes too much prose, it can erase human-friendly onboarding,
- if Python edits official or source files, the trust model is broken,
- if every user runs the helper independently, sync conflicts return,
- if the admin PC is offline, scheduled maintenance can be delayed.

Mitigation:

- generated blocks only,
- dry-run default,
- curator-owned scheduled run,
- one active maintainer runner at a time,
- append-only event records,
- no official/archive/source mutations.

## Design Implication

The first maintenance helper should not be a "knowledge AI".

It should be a deterministic janitor:

```text
scan files
  -> validate metadata
  -> detect conflicts
  -> roll up events
  -> update generated index/digest blocks
  -> report what needs Claude or human judgment
```

This preserves the simple V0 mental model while making future scale much less painful.

## Command Fit Check

The proposed command set fits the simulation if:

- daily maintenance can run with `scan`, `validate`, `conflict-scan`, `digest`, and `rebuild-indexes`,
- weekly motivation can run with `weekly-topics`,
- multi-WIKI convergence can start with `common-candidates`,
- all outputs remain generated blocks or review reports,
- Claude Code is invoked only after Python has narrowed the evidence.

## Follow-Up Simulation

[[SharePoint AI Knowledge Workspace Admin Python Operating Simulation]] tests the same boundary from persona experience: contributor, reviewer, admin, weekly curator, stale admin runner, and scale expansion.

Its additional refinement is that `kw-maint doctor` should be judged by client-load reduction, not just mechanical correctness. The output is successful only if it lets Claude Code start from compact generated facts and explicit links rather than broad workspace scans.
