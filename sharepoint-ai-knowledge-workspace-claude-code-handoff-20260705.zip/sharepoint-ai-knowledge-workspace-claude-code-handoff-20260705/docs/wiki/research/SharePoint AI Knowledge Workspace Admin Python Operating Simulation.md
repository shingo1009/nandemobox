---
type: research
title: "SharePoint AI Knowledge Workspace Admin Python Operating Simulation"
status: active
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
tags:
  - research
  - simulation
  - python
  - maintenance
  - token-budget
related:
  - "[[2026-07-05 Admin Python First Maintenance]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Boundary]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]"
---

# SharePoint AI Knowledge Workspace Admin Python Operating Simulation

## Purpose

Simulate the actual operating experience after adopting [[2026-07-05 Admin Python First Maintenance]].

The key question is not "can Python automate maintenance?" It is:

```text
Can one admin-side Python run keep normal client Claude Code sessions narrow?
```

## Assumptions

- The shared workspace is a SharePoint / OneDrive synced Markdown folder.
- The first admin runner is Nishizawa's own PC.
- Normal users may browse SharePoint, sync files, and optionally use Claude Code.
- Normal users do not run Python maintenance.
- Claude Code usage is limited and should be spent on meaning, writing, review, and patch drafting.
- Python may be moderately complex if it removes repeated discovery work from many client sessions.

## Scenario 1: Contributor Adds One Source

Context:

- A contributor drops one meeting note into `projects/sample/sources/`.
- The contributor does not use Claude Code.
- The file has weak or missing frontmatter.

Without admin Python:

- A later Claude Code session may need to scan project folders to discover the new source.
- The project `_index.md` may drift.
- The curator may not notice missing metadata until much later.

With admin Python:

1. Admin runs `kw-maint doctor`.
2. Python finds the new source.
3. Python reports missing optional metadata as a warning, not a blocking error.
4. Python previews the project index entry that would be generated later.
5. Claude Code is invoked only if the source should be extracted into reviewed knowledge.

Finding: Low-friction contribution remains possible. Python absorbs discovery and metadata hygiene without forcing every contributor into AI tooling.

## Scenario 2: Reviewer Checks Their Work

Context:

- A reviewer asks Claude Code, "自分宛の確認事項だけ見て".
- There are 60 files in the workspace, 8 notifications, and 2 actual `needs_action` items.

Without admin Python:

- Claude may read `_notifications/`, project indexes, review folders, and recent files to reconstruct state.
- The reviewer spends token budget before reaching the action items.

With admin Python:

1. Python maintains `_notifications/{user}/digest.md` or previews it in dry-run.
2. The digest separates `needs_action` from FYI.
3. Claude reads the digest first, then only the two linked files.

Finding: The reviewer experience improves only if generated outputs are small and action-oriented. The digest must not become another long report.

## Scenario 3: Admin Daily Run

Context:

- Five projects exist.
- One project is missing `_index.md`.
- One OneDrive conflict file appears.
- One official file changed yesterday.

Expected `doctor` behavior:

```text
scan
validate
conflict-scan
raw-validate if .raw exists
rebuild-indexes --dry-run
```

Python should produce:

| Finding | Severity | Action |
|---|---|---|
| missing project `_index.md` | blocking | create or restore before pilot readiness |
| conflict filename | warning | human checks duplicate and sync state |
| recent official edit | warning | human confirms whether patch path was used |
| generated index diff | info | preview only in V0 |

Claude Code should not be needed for the first pass. Claude becomes useful only if the admin asks it to explain a conflicted article, draft a patch, or summarize what changed.

Finding: The first admin habit should be `doctor`, not a broad AI review. This proves the folder can be mechanically trusted before spending tokens on semantics.

## Scenario 4: Weekly Common Candidates

Context:

- Three project mini-wikis each mention "approval criteria".
- The topic repeats, but the rules differ by project.

Python output:

- candidate reason: repeated topic label,
- confidence: medium,
- sensitivity hint: project-specific process,
- seen count: 2,
- links to the three project pages.

Claude output after reading only the report and linked pages:

- "Do not merge into one common rule yet."
- "Create cross-links or a comparison note if readers keep asking."
- "Promote only the shared definition of approval criteria, not project-specific thresholds."

Finding: Python should find convergence signals, but Claude/human review prevents false unification.

## Scenario 5: Admin PC Is Offline For A Week

Context:

- The admin PC is unavailable.
- Users continue adding sources and reviews.

Expected degradation:

- Source contribution continues.
- Reviewed and patch workflows continue if humans know paths.
- Generated indexes, digests, and weekly skeletons become stale.

Unacceptable degradation:

- Users cannot find official project pages.
- Claude Code requires whole-workspace scanning for basic navigation.
- Conflicts go unnoticed before official patches are applied.

Design response:

- Core folder structure must remain browsable without fresh generated blocks.
- Generated blocks should display last-updated timestamps.
- `doctor` should report stale generated sections when maintenance resumes.
- If admin absence becomes common, add a backup admin runner before adding server infrastructure.

Finding: Admin Python is a cost-control layer, not the only access path. The WIKI must remain useful in a stale-but-readable state.

## Scenario 6: Scale Expansion

Context:

- 20 project mini-wikis,
- 2,000 Markdown files,
- weekly common-candidate detection,
- multiple reviewers using Claude Code.

Naive AI usage:

- each reviewer asks Claude to search broad folders,
- weekly synthesis rereads many project pages,
- duplicate article checks become token-heavy and inconsistent.

Python-first usage:

- `by_project`, `by_topic`, digest, stale, conflict, and common-candidate outputs become the default entry points,
- Claude starts from top-N reports and explicit links,
- semantic review stays limited to linked files and candidate clusters.

Finding: Scale is viable only if Python produces narrow entry points. Adding more Claude skills without generated evidence would increase the cognitive and token surface.

## Refined Requirements For `kw-maint doctor`

The implementation plan should include client-load acceptance criteria:

- a reviewer can find `needs_action` items without broad project scans,
- an admin can see missing required files before asking Claude to inspect content,
- a common-candidate review starts from a top-N report, not all project folders,
- dry-run index output is deterministic and compact,
- every generated output includes enough links for Claude to read only target files.

## Design Adjustments

- Treat `kw-maint doctor` as the next strongest execution track if the priority is long-term usage cost.
- Keep write mode out of V0 until dry-run output is trusted.
- Add "stale generated block" detection to `validate`.
- Require generated outputs to be compact: links and counts first, copied content only when necessary.
- Do not add new V0 Claude skills for weekly, merge, or digest work. Keep them inside `knowledge_steward` and feed them Python-generated evidence.

## Verdict

The Python-first design remains coherent under real use if it is framed as:

```text
admin Python narrows the workspace
Claude Code interprets the narrowed evidence
humans authorize shared truth
```

This supports the user's goal: fewer client-side tokens, less repeated maintenance, and a cleaner skill surface without losing future expansion paths.
