---
type: research
title: "SharePoint AI Knowledge Workspace Pilot Risk Checklist"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - risk
  - pilot
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace README Draft]]"
  - "[[2026-07-04 Official Folder Permission Protection]]"
---

# SharePoint AI Knowledge Workspace Pilot Risk Checklist

## Purpose

This checklist captures risks to review before a V0 pilot starts.

## Pilot Readiness Questions

### User Understanding

- Can a new user explain the difference between `official/`, `reviewed/`, and `proposals/`?
- Can a user add a source note without filling perfect metadata?
- Does the README say what to do when the user is unsure?

### AI Safety

- Does `CLAUDE.md` clearly forbid direct edits to `official/`?
- Does Claude know it must identify `current_user` before checking notifications?
- Does Claude separate official, reviewed, proposal, extracted, source, and personal information in answers?

### SharePoint / OneDrive

- Is `official/` protected by permissions, or is convention-only clearly marked as temporary?
- Are sync conflict filenames included in daily check?
- Are users told not to resolve official conflicts silently?
- Are normal user updates written to `_index/events/` instead of directly editing shared summary indexes?

### Review Load

- Is there a person or role responsible for curating stale proposals?
- Are low-severity notifications batched or deferred?
- Are notification statuses explicit: `needs_action`, `waiting`, `deferred`, `resolved`, `superseded`, or `fyi`?
- Is there a digest threshold so FYI items do not bury approvals?
- Is there a clear reject/defer path so proposals do not pile up forever?

### Patch Flow

- Does every patch include `target_file`, `target_section`, status, owner, risk, source files, and required approval?
- Does Patch Drafter search `_patches/open/` for same-target patches?
- Is same-target overlap marked as `merge_required`?
- Is official patch application curator-only or owner-approved?
- Does patch application reread the current official target and all same-target open patches?

### Psychological Safety

- Are personal notes explicitly opt-in?
- Does the wording avoid "monitoring" language?
- Does the workflow avoid directly correcting another person's files?

## Red Flags

- Users put everything in root.
- Claude creates notifications for every small observation.
- A user's inbox mixes FYI and approval requests without status.
- `official/` changes without a patch.
- Two same-target patches are applied without serialized review.
- People hesitate to add notes because metadata feels too strict.
- Reviewers cannot tell what action is being requested.
- Multiple users directly edit `_index/recent_changes.md` or `_index/by_topic.md`.

## Pilot Exit Criteria

The V0 design is ready for the next stage when:

- Users can add sources without asking where they go.
- At least one source becomes an extraction.
- At least one extraction becomes a proposal.
- At least one proposal is accepted into `reviewed/` or rejected with a reason.
- At least one official patch is drafted without editing `official/`.
- The curator can explain what needs cleanup.
