---
type: research
title: "SharePoint AI Knowledge Workspace Simulation Round 2 Findings"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - simulation
  - findings
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace Notification Backlog Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Concurrent Patch Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
---

# SharePoint AI Knowledge Workspace Simulation Round 2 Findings

## Summary

The second simulation round tested two conditions that are easy to miss in a clean demo:

- notifications after one week of uneven user attention,
- concurrent official patch drafts against the same target file.

Both simulations confirm that the V0 structure is usable, but they expose two missing rule layers: notification lifecycle rules and patch queue rules.

## Findings

### 1. Notifications Need Lifecycle Semantics

A notification file is not enough. It must say whether it is:

- actionable now,
- waiting on someone else,
- deferred,
- resolved,
- superseded,
- or only FYI.

Without this, a user's inbox becomes a folder of ambiguous Markdown files.

### 2. Digest Is A V0 Need, Not A Later Luxury

The first simulation treated digesting as useful once notifications exist. Round 2 shows it should be part of V0.

Low-severity items should be batched when they exceed a threshold. Otherwise, a week of normal activity can bury a single high-value review request.

### 3. Same-Target Patches Are Normal

The design cannot assume one patch per official file at a time. Real reviews often produce several changes to the same article.

The design should allow multiple patches, but make their relationship explicit.

### 4. Patch Application Must Be Serialized

Drafting patches can be distributed. Applying official patches must be serialized by a curator or owner-approved session.

Before applying any patch, the current official target and all open same-target patches should be reread.

### 5. Event Files Should Track Status Changes

`_index/events/` should not record only creation events. It should also record status changes:

- notification resolved,
- notification superseded,
- patch marked merge-required,
- patch applied,
- patch rejected.

## Design Adjustments Required

- Add `_system/notification_rules.md`.
- Add `_system/patch_rules.md`.
- Add initial contents for those files.
- Update Notification Router to prefer status-aware workflow threads and digest thresholds.
- Update Patch Drafter to detect same-target open patches and mark merge-required when needed.
- Update V0 Operating Flow to serialize official patch application.
- Update Pilot Risk Checklist with backlog and concurrent patch readiness checks.

## Verdict

The user's intuition was correct: realistic usage simulation reveals tool inconvenience that static design review does not.

The design did not fail, but it became more honest. V0 now needs two small operating contracts that keep file-based collaboration from turning into unclear folders of stale work.
