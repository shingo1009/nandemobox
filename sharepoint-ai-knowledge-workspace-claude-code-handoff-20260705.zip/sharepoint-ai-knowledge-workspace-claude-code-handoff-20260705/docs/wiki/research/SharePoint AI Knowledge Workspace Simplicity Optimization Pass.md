---
type: research
title: "SharePoint AI Knowledge Workspace Simplicity Optimization Pass"
status: active
created: 2026-07-04
updated: 2026-07-05
tags:
  - research
  - design-optimization
  - simplicity
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
---

# SharePoint AI Knowledge Workspace Simplicity Optimization Pass

## Purpose

Re-check the current design from the viewpoint of practical simplicity.

The design has accumulated good safety mechanisms: project mini-wikis, notifications, review records, patch-first official updates, archive candidates, and readiness gates. The risk is that a correct design can still feel too heavy for real users.

This pass asks:

- What should a normal user do in the first minute?
- Which rules protect trust without becoming bureaucracy?
- Which folders are essential now, and which are future pressure valves?
- Which future features should be triggered by observed pain rather than prebuilt?

## Current Optimization Thesis

V0 should be a **shared project knowledge folder with a light WIKI surface**, not a full knowledge management platform.

The core should stay:

1. project mini-wikis for SharePoint-side browsing and search,
2. source-to-proposal extraction,
3. one actionable notification path,
4. patch-first official changes,
5. append-only event records for audit and later rollup.

Everything else should either be:

- a Markdown convention,
- a curator habit,
- or a post-pilot migration trigger.

## Persona-Based Friction Review

| Persona | What They Need | Current Risk | Optimization |
|---|---|---|---|
| Contributor | Drop a useful note without understanding the whole system. | Too many possible folders can create hesitation. | Tell contributors: put material in the relevant project `sources/` or `notes/`; if no project exists, ask the curator before creating a cross-project area. |
| Reviewer | See what requires judgment today. | Notifications, proposals, and patches can split attention. | Daily check should show only `needs_action` first, then waiting/deferred, then FYI digest. |
| Curator | Keep trust, indexes, and official pages healthy. | Curator can become a bottleneck if every small update requires officialization. | Use `reviewed/` as the normal accepted layer; reserve `official/` for stable rules, interfaces, and decisions. |
| Project owner | Know whether project knowledge is current. | Project mini-wiki can become stale if README and `_index.md` are not maintained. | Require a visible "Last reviewed" and "Search keywords" section in project README, but keep it human-editable. |
| New user | Understand the workspace without training. | `CLAUDE.md`, `_system/`, and lifecycle pages are agent-heavy. | Human README should contain only three actions: add source, check notifications, ask for extraction. |
| Claude Code | Read enough context without crawling everything. | Per-project WIKI plus root control plane can confuse read order. | If project is known, read project README, project `_index.md`, project `official/`, project `reviewed/`, then root official/reviewed. |
| SharePoint admin | Avoid permission surprises. | Folder-level permissions can become difficult to reason about. | V0 should validate only root/project `official/` protection; avoid deep per-folder permission schemes. |
| Security/compliance reviewer | Prevent sensitive content from leaking through search or summaries. | Project searchability is useful but can expose metadata if permissions are wrong. | Do not put sensitive pilot content into project mini-wikis until permission-trimmed search is verified. |

## Simplest Happy Path

The first V0 workflow should be explainable in six sentences:

1. Put project-specific material in `projects/{project}/sources/`.
2. Ask Claude to extract decisions, risks, and reusable knowledge.
3. Claude writes extraction and, when useful, a proposal.
4. If someone must decide, Claude writes one `needs_action` notification.
5. A reviewer accepts useful material into `reviewed/`.
6. Only curator-approved patches change `official/`.

This happy path should be more prominent than the full lifecycle state machine in human-facing onboarding.

## Essential V0 Folders

These folders are essential because they each protect a distinct job:

| Folder | Job | Keep? |
|---|---|---|
| `projects/{project}/README.md` | project entry and search surface | yes |
| `projects/{project}/_index.md` | project-local navigation | yes |
| `projects/{project}/sources/` | project evidence intake | yes |
| `projects/{project}/notes/` | informal project work notes | yes |
| `projects/{project}/reviewed/` | accepted but not official project knowledge | yes |
| `projects/{project}/official/` | stable project authority | yes, protected |
| `_notifications/{user}/inbox/` | action routing | yes |
| `_reviews/open/` | human review records | yes, but only for non-trivial reviews |
| `_patches/open/` | official change proposals | yes |
| `_index/events/` | append-only audit trail | yes |
| root `official/` | cross-project stable knowledge | yes |

These should not be emphasized to normal contributors on day one:

| Folder | Why Hide From Day-One Mental Model |
|---|---|
| root `extracted/` | mostly agent output; project-specific extractions may later move under project if volume requires it |
| root `proposals/` | useful internally, but users should think "review request" rather than "folder taxonomy" |
| `archive/` | curator concern, not contributor concern |
| deep `_system/` pages | agent contract, not user onboarding |

## Rule Simplification

### Keep These Rules Hard

- AI must not directly edit root or project `official/`.
- Sensitive content must not enter a project mini-wiki until permissions and search behavior are validated.
- Official patches must name `target_file`, evidence, risk, and required reviewer.
- Same-target open patches must be checked before official application.
- Source files should remain traceable from reviewed or official knowledge.

### Keep These Rules Soft

- Metadata can be incomplete at intake.
- Project keywords can start as plain text in README.
- Indexes can lag if `_index/events/` records exist.
- Notification digest thresholds can be tuned after pilot observation.
- Archive movement can remain manual.

## Future Expansion Map

| Observed Pain | Future Response | Do Not Build Before |
|---|---|---|
| Users cannot find project files in SharePoint search. | Add stronger project README keyword blocks or generated project indexes. | Project Searchability scenario fails or is painful. |
| Curator spends too much time updating indexes. | Add deterministic index helper. | Repeated index drift is observed. |
| Notifications become noisy. | Add digest generator or notification summary helper. | One-week pilot shows ignored FYI noise. |
| Same-target patches collide often. | Add patch queue and target-lock helper. | Two or more real merge-required incidents. |
| Reviewed knowledge grows stale. | Add scheduled review dashboard. | Review dates are missed in pilot. |
| Markdown folders are too hard for non-technical users. | Consider GROWI, SharePoint page front-end, or lightweight web UI. | Real users fail the README-only onboarding check. |
| Retrieval fails across many projects. | Add local search, semantic index, or MCP/API layer. | Project count or file count crosses practical search limits. |

## Design Risk Register

| Risk | Severity | Early Signal | Mitigation |
|---|---|---|---|
| Folder taxonomy overwhelms users. | high | Users ask where to put files repeatedly. | Reduce onboarding to two intake paths: project source or root source. |
| `reviewed/` and `official/` blur together. | high | Users cite reviewed notes as final policy. | README and CLAUDE must describe `reviewed` as provisional. |
| Project mini-wikis sprawl. | medium | Duplicate project slugs or abandoned project folders appear. | Curator-created or curator-approved projects only. |
| SharePoint search misses Markdown content or ranks poorly. | medium | Project Searchability scenario fails. | Root `_index/by_project.md` becomes the first navigation path. |
| Permission model is too complex. | high | Users lose access to normal source or notes folders. | Protect only root/project `official/` in V0. |
| Notifications become a second inbox nobody trusts. | high | `needs_action` items stay untouched. | Daily check hides resolved/superseded/FYI unless requested. |
| Curator becomes bottleneck. | medium | Many low-risk proposals wait for officialization. | Promote more useful items to `reviewed/`; keep `official/` scarce. |

## Optimization Decisions

These are design recommendations, not yet final implementation:

1. V0 human onboarding should advertise only three actions: add source, check notifications, ask for extraction.
2. `reviewed/` should be the normal destination for useful accepted knowledge; `official/` should be rare.
3. Project mini-wiki README should include visible search keywords and last-reviewed metadata.
4. The first real pilot should validate project search before validating advanced lifecycle automation.
5. Do not add full project-local `_notifications/`, `_reviews/`, `_patches/`, or `_system/` until root queues become a proven bottleneck.
6. Deterministic helpers should be introduced by observed pain, not by architectural completeness.

## Open Design Questions

- Should project-specific `extracted/` and `proposals/` remain root-level in V0, or should they move under each project to improve SharePoint-side local context?
- What is the minimum project README format that helps SharePoint search without becoming a form?
- Should `reviewed/` be described to humans as "accepted notes" rather than "reviewed knowledge"?
- Should the first pilot intentionally avoid cross-project sources to reduce mental load?
- What exact event fields are required so indexes can be regenerated later without reading every file?

## Recommendation

Keep the current architecture, but present it differently:

- Human mental model: **Project WIKI + Notifications + Official Patch**.
- Claude mental model: **Read order + write boundary + lifecycle status**.
- Curator mental model: **Trust boundary + event trail + cleanup candidates**.

This keeps V0 understandable while preserving enough structure for future automation.
