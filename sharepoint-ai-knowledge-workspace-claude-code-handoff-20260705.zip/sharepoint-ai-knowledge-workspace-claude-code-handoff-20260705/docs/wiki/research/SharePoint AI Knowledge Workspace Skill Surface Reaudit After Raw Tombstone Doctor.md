---
type: research
title: "SharePoint AI Knowledge Workspace Skill Surface Reaudit After Raw Tombstone Doctor"
status: active
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
tags:
  - research
  - skills
  - simplification
  - runtime
  - audit
related:
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
  - "[[SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation]]"
---

# SharePoint AI Knowledge Workspace Skill Surface Reaudit After Raw Tombstone Doctor

## Purpose

Reaudit the V0 skill surface after adding:

- converted Markdown under `.raw/`,
- tombstone and deletion policy,
- `kw-maint doctor` acceptance fixtures.

The concern is simple: every useful new behavior can tempt the design toward another Claude skill. This audit checks whether the system can stay compact.

## Verdict

No new V0 Claude skills are needed.

The new work fits the existing split:

```text
admin Python narrows and validates files
Claude Code interprets narrowed evidence
humans authorize shared truth
```

## Responsibility Mapping

| New Need | V0 Home | Reason |
|---|---|---|
| Validate `.raw` converted Markdown frontmatter | `kw-maint doctor` / `raw-validate` | deterministic metadata check |
| Detect stale or partial conversions | `kw-maint doctor` / `raw-validate` | timestamp and warning-field check |
| Convert Excel/PPTX to Markdown | future explicit admin Python `convert-source` | deterministic but not V0 daily habit |
| Extract knowledge from `.raw` Markdown | `knowledge_steward` | semantic extraction and wording |
| Decide whether incomplete conversion is enough | `knowledge_steward` plus human | requires judgment |
| Keep tombstones out of active indexes | `kw-maint rebuild-indexes --dry-run` | deterministic index policy |
| Explain where a tombstone points | `workspace_navigator` | navigation task |
| Draft merge plan before superseding articles | `knowledge_steward` | semantic article integration |
| Validate deletion plan risk | future `deletion-plan-check` | deterministic preflight, admin-only |
| Hard delete from SharePoint | human admin only | authority and alert risk |

## Updated Minimal Runtime

V0 remains:

```text
3 Claude behaviors
  + 4 required _system files
  + admin-run read-only kw-maint doctor
  + human authority
```

`kw-maint doctor` now includes:

```text
scan
validate
conflict-scan
raw-validate if .raw exists
rebuild-indexes --dry-run
```

This is still one admin command, not a new daily skill for every client.

## What Not To Add In V0

Do not add:

- a separate `.raw` Claude skill,
- a separate tombstone cleanup Claude skill,
- a deletion manager skill,
- a weekly newsletter skill,
- an article merge automation skill,
- a project-local maintenance skill per mini-wiki.

These would make the surface larger without proving real pilot need.

## Prompt Sections Are Enough

If the pilot materializes `CLAUDE.md`, the existing three behaviors can contain small prompt sections:

| Section | Parent Behavior |
|---|---|
| "When reading `.raw` converted Markdown" | `knowledge_steward` |
| "When encountering a tombstone" | `workspace_navigator` |
| "When drafting an article merge plan" | `knowledge_steward` |
| "When drafting an official patch" | `patch_reviewer` |

These are prompt snippets, not installable skills.

## Expansion Triggers

Split a new skill only if real pilot evidence shows:

- users repeatedly ask Claude to process `.raw` files incorrectly,
- tombstones frequently confuse normal readers,
- deletion plans become frequent enough to need a specialized checklist,
- `knowledge_steward` grows too long for `CLAUDE.md`,
- multiple admins need a repeatable `convert-source` workflow.

Until then, keep the capability in `kw-maint` and existing behavior sections.

## Design Check

The added policies increase **coverage**, not **interaction complexity**:

- normal users still add/read project WIKI files,
- reviewers still start from notifications/digest,
- admins still run one `doctor` command,
- Claude still has three behaviors,
- humans still authorize official/shared truth.

This preserves the user's target balance: simple and compact, but expandable.
