---
type: index
title: "Research Index"
status: evergreen
created: 2026-07-02
updated: 2026-07-05
tags:
  - index
  - research
---

# Research

Use this folder for technical research, library evaluation, API notes, implementation patterns, and reference synthesis.

## Source And Design Inputs

- [[Knowledge Pull Request Hub Design]]: source document for architecture and MVP research.
- [[SharePoint AI Knowledge Workspace Design Review]]: design optimization memo for the SharePoint / OneDrive Markdown knowledge workspace.
- [[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]: alignment note for adopting the simple but expandable V0 profile from the latest source.

## Pilot Readiness

- [[SharePoint AI Knowledge Workspace Pilot Risk Checklist]]: pilot readiness and risk checklist.
- [[SharePoint AI Knowledge Workspace Pilot Dry Run Validation]]: tabletop validation of the pilot sample against lifecycle, article quality, and archive rules.
- [[SharePoint AI Knowledge Workspace Simulation Completion Assessment]]: assessment separating finished tabletop simulation from remaining real SharePoint / OneDrive validation.
- [[SharePoint AI Knowledge Workspace Pilot Validation Protocol]]: real-environment validation protocol for permissions, version history, local availability, filenames, conflicts, notifications, and patch serialization.
- [[SharePoint AI Knowledge Workspace Pilot File Consistency Dry Run]]: tabletop run of the pre-materialization consistency checklist.
- [[SharePoint AI Knowledge Workspace Simple Minimum Final Consistency Review]]: final consistency review across Simple Minimum Profile, admin-run Python maintenance, and consolidated Claude behaviors.
- [[SharePoint AI Knowledge Workspace Objective Completion Audit]]: requirement-level audit for the broader design objective, current evidence, and remaining real-world proof.
- [[SharePoint AI Knowledge Workspace Pilot Evidence Capture Dry Run]]: dry run of pilot evidence notes for note-only, raw-converted, and blocked doctor scenarios.
- [[SharePoint AI Knowledge Workspace Claude Code Handoff Intake Simulation]]: intake simulation for the handoff ZIP and first Claude Code planning task.
- [[SharePoint AI Knowledge Workspace First Output Acceptance Dry Run]]: dry run of first Claude Code plan review with the acceptance checklist.

## Usage And Sync Simulations

- [[SharePoint AI Knowledge Workspace Usage Simulation]]: tabletop simulation of real-user and cloud-sync usage.
- [[SharePoint AI Knowledge Workspace Simulation Findings]]: simulation findings and V0 design adjustments.
- [[SharePoint AI Knowledge Workspace Notification Backlog Simulation]]: one-week simulation of file-based notification backlog and triage friction.
- [[SharePoint AI Knowledge Workspace Concurrent Patch Simulation]]: simulation of two users drafting patches against the same official target.
- [[SharePoint AI Knowledge Workspace Simulation Round 2 Findings]]: second simulation findings covering notification lifecycle and patch queue rules.
- [[SharePoint AI Knowledge Workspace End To End V0 Pilot Simulation]]: full V0 tabletop run through setup, source extraction, review, patch, maintenance, weekly summary, article integration, and scale stress.

## Project Wiki And Onboarding

- [[SharePoint AI Knowledge Workspace Project Mini Wiki Dry Run]]: tabletop revalidation after adding lightweight project mini-wikis.
- [[SharePoint AI Knowledge Workspace Simplicity Optimization Pass]]: persona-based simplification pass for V0.
- [[SharePoint AI Knowledge Workspace README Onboarding Dry Run]]: first-minute onboarding dry run for root and project README content.
- [[SharePoint AI Knowledge Workspace Governance Retention Audit]]: audit that README simplification still preserves governance in `CLAUDE.md` and `_system/`.

## Maintenance And Scale

- [[SharePoint AI Knowledge Workspace Maintenance Automation Simulation]]: simulation of admin-run Python maintenance for daily indexes, weekly topics, multi-WIKI convergence, and scale.
- [[SharePoint AI Knowledge Workspace Admin Python Operating Simulation]]: persona and scale simulation for admin-run Python as the client Claude Code token-saving layer.
- [[SharePoint AI Knowledge Workspace Weekly Loop Simulation]]: tabletop simulation of weekly topics, common-candidate discovery, reader motivation, and scale guardrails.

## Article Integration And Source Care

- [[SharePoint AI Knowledge Workspace Article Integration Simulation]]: tabletop simulation for merging, revising, cross-linking, or keeping overlapping project articles separate.
- [[SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation]]: simulation of converted Markdown sources, source traceability, merge tombstones, and SharePoint deletion alert care.
- [[SharePoint AI Knowledge Workspace Private Raw Evidence Rehearsal Simulation]]: private rehearsal simulation comparing note-only and converted `.raw` source pilots while preserving the Simple Minimum boundary.

## Skill Surface Audits

- [[SharePoint AI Knowledge Workspace Design Coverage Audit]]: coverage audit against the user's design-continuation objective and remaining gaps.
- [[SharePoint AI Knowledge Workspace Skill Surface Reaudit After Raw Tombstone Doctor]]: audit confirming raw/tombstone/doctor additions do not require new V0 Claude skills.
