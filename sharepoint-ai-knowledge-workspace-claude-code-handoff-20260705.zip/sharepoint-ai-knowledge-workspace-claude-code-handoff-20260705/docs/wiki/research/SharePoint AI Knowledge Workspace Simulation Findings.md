---
type: research
title: "SharePoint AI Knowledge Workspace Simulation Findings"
status: active
created: 2026-07-04
updated: 2026-07-05
tags:
  - research
  - simulation
  - findings
related:
  - "[[SharePoint AI Knowledge Workspace Usage Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace Shared Skill Playbooks]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
---

# SharePoint AI Knowledge Workspace Simulation Findings

## Summary

The simulation confirms that the V0 design is directionally sound, but it exposes friction around shared mutable indexes, ambiguous review responses, notification noise, and patch target availability.

## Main Improvements

### 1. Add `_index/events/`

Current design lets multiple users or Claude sessions edit `_index/recent_changes.md` and `_index/by_topic.md` directly. In OneDrive, this is likely to create conflict files.

Improvement:

- Add `_index/events/` as append-only event log folder.
- Let normal users and Claude sessions write event files.
- Let curator or later helper roll up indexes.

### 2. Add Canonical Review Response Format

Review results should not be scattered across proposal files, notification files, and chat.

Improvement:

- Add `_reviews/open/rev-YYYYMMDD-HHMM-topic.md`.
- Keep proposal content stable.
- Link review response to proposal, source, notification, and patch.

### 3. Use Notification Threads

Notification Router should avoid creating too many notification files for one workflow.

Improvement:

- Prefer one notification file per workflow and owner.
- Update status or add dated sections inside the notification.
- Use digest for low severity items.

### 4. Include Starter Official Article

Patch drafting is awkward if no official target exists.

Improvement:

- Add `official/design-review/external-interface.md` starter page to the template pack.
- Keep it minimal and clearly official.

### 5. Navigator Fallback When Indexes Are Stale

Claude should not rely entirely on `_index/`.

Improvement:

- If `_index/` is stale, missing, or conflict-marked, scan the relevant lifecycle folder directly.
- Keep that scan narrow.

## Design Status Impact

These findings do not invalidate the V0 design. They refine it before a real pilot.

Required before pilot:

- Update template pack with `_index/events/`.
- Add review response format.
- Add starter official article.
- Replace Claude-side index maintenance with append-only events plus admin-run Python generated rollups.
- Update Notification Router to prefer workflow-thread notifications.

Deferred:

- Write-mode generated rollup from `_index/events/` after dry-run maintainer validation.
- Real conflict resolution tooling.
- Semantic duplicate detection at scale.
