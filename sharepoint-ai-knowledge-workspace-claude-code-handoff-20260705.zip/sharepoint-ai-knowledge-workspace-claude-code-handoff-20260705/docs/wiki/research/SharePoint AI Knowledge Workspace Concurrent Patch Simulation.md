---
type: research
title: "SharePoint AI Knowledge Workspace Concurrent Patch Simulation"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - simulation
  - patch
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace Usage Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Simulation Findings]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Shared Skill Playbooks]]"
---

# SharePoint AI Knowledge Workspace Concurrent Patch Simulation

## Purpose

Simulate what happens when two users draft official-update patches against the same target file at nearly the same time.

The goal is to test whether the patch-first rule is enough for real cloud-synced use.

## Simulation Scope

Actors:

- `nishizawa`: curator.
- `sato`: reviewer drafting a patch from one proposal.
- `tanaka`: reviewer drafting a second patch from another proposal.
- Claude Code sessions on separate PCs.
- OneDrive / SharePoint sync with eventual consistency.

Target official file:

```text
official/design-review/external-interface.md
```

Folders exercised:

- `_patches/open/`
- `_reviews/open/`
- `_notifications/{user}/inbox/`
- `_index/events/`
- `official/`

## Scenario

Two users review different proposals that both affect the "External Interface Review" official page. Both ask Claude Code to draft official patches before their OneDrive folders fully converge.

## Timeline

### T0: Target Exists

The starter official page exists:

```text
official/design-review/external-interface.md
```

This avoids the "no target file" problem found in [[SharePoint AI Knowledge Workspace Usage Simulation]].

### T1: Sato Drafts Patch A

Sato asks Claude Code to create a patch for error response checklist additions.

Expected file:

```text
_patches/open/patch-20260704-external-interface-error-response.md
```

Risk observed:

- Patch A has a target file, but no visible claim that it is the active patch for that target.

### T2: Tanaka Drafts Patch B Before Patch A Syncs

Tanaka asks Claude Code to create a patch for ownership and API versioning additions.

Expected file:

```text
_patches/open/patch-20260704-external-interface-versioning.md
```

Risk observed:

- Tanaka's Claude session may not know Patch A exists yet.
- Both patches may propose edits to the same section.

### T3: Curator Opens Patch Queue

Nishizawa now sees two open patches with the same target file.

Risk observed:

- The correct action is not simply "apply both".
- The curator needs to know whether the patches are independent, overlapping, or contradictory.

### T4: One Patch Is Applied

Curator applies Patch A to `official/`.

Risk observed:

- Patch B may now be stale because the target context changed.
- If Patch B is applied later without rebase, it may overwrite or duplicate Patch A's content.

### T5: Notification And Index Drift

Sato receives "patch accepted"; Tanaka still has "patch pending".

Risk observed:

- Notification status and patch status can diverge.
- `_index/events/` needs to record patch status changes, not only patch creation.

## Key Findings

| Finding | Severity | Design Impact |
|---|---|---|
| Patch-first is necessary but not sufficient | high | add patch queue rules |
| Multiple patches can target the same official file | high | require target and section metadata |
| Patch application must be serialized | high | curator-only apply order |
| Patches need statuses beyond open/applied | medium | add merge-required and superseded |
| Patch notifications must track patch status | medium | avoid stale approval requests |
| The official target should be reread before applying each patch | high | prevent stale patch application |

## Recommended Adjustments

### Adjustment 1: Add Patch Rules

Create `_system/patch_rules.md`.

Patch statuses:

- `open`
- `waiting_approval`
- `merge_required`
- `applied`
- `rejected`
- `superseded`

Required patch metadata:

- `target_file`
- `target_section`
- `source_files`
- `owner`
- `required_approval`
- `status`
- `risk`

### Adjustment 2: Detect Same-Target Patches

Before drafting a patch, Claude should search:

```text
_patches/open/
```

for files with the same `target_file`. If one exists, the new patch should either:

- reference the existing patch,
- mark itself `merge_required`,
- or ask the user whether to merge into the existing patch thread.

### Adjustment 3: Serialize Official Application

Only the curator or owner-approved session should apply official patches.

Before applying each patch:

1. reread the current target official file,
2. reread all open patches with the same target file,
3. decide whether the patch is still valid,
4. mark conflicting patches as `merge_required` or `superseded`,
5. write an `_index/events/` status event.

### Adjustment 4: Keep Patch Files As Audit Records

Do not delete applied or rejected patch files during V0. If archive folders are not yet active, leave the file with updated status or record status through an event file.

## Simulation Verdict

The patch-first model remains correct, but V0 needs a small patch queue rule set.

The important rule is not "only one patch may exist." The rule is "official application is curator-only and serialized; multiple same-target patches must be detected before application."
