---
type: research
title: "SharePoint AI Knowledge Workspace Usage Simulation"
status: active
created: 2026-07-04
updated: 2026-07-05
tags:
  - research
  - simulation
  - operations
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Sample Flow]]"
  - "[[SharePoint AI Knowledge Workspace Simulation Findings]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
---

# SharePoint AI Knowledge Workspace Usage Simulation

## Purpose

Simulate realistic usage of the SharePoint / OneDrive Markdown workspace before creating a real shared folder.

This is a tabletop simulation, not a live SharePoint test. It assumes multiple users, local OneDrive sync delay, Claude Code sessions, notifications, patches, and index updates.

Later design updates replace the many named Claude playbooks in this simulation with three consolidated behaviors and admin-run Python maintenance. The conflict findings remain valid; the current mitigation is [[SharePoint AI Knowledge Workspace Skill Consolidation Pass]] plus [[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]].

## Simulation Scope

Actors:

- `nishizawa`: curator and source owner.
- `sato`: reviewer and second user.
- Claude Code session A: running on Nishizawa's PC.
- Claude Code session B: running on Sato's PC.
- OneDrive / SharePoint sync: eventually consistent file synchronization.

Folders exercised:

- `sources/`
- `extracted/`
- `proposals/`
- `_notifications/{user}/inbox/`
- `_patches/open/`
- `_index/`
- `official/`

## Scenario

Nishizawa adds an external interface review meeting note. Claude Code extracts review knowledge and creates a proposal. Sato later reviews it and asks for an official patch. Both users' clients may update indexes or notifications around the same time.

## Timeline

### T0: Initial Workspace

The workspace contains the template pack:

- `README.md`
- `CLAUDE.md`
- `_system/`
- empty `_index/`
- lifecycle folders

Risk observed:

- Empty `_index/official_index.md` gives Claude Code little context. The first pilot needs either a starter official article or clear "no official knowledge yet" language.

### T1: Nishizawa Adds Source

File added:

```text
sources/meetings/2026-07-04_meeting_external-if-review.md
```

Claude Code session A runs:

- sensitivity preflight rule,
- `workspace_navigator`,
- `knowledge_steward`,
- optional `patch_reviewer`,
- admin-run `kw-maint` later handles generated index rollup.

Expected outputs:

- `extracted/ext-20260704-external-if-review.md`
- `proposals/prp-20260704-external-if-review-checklist.md`
- `_notifications/nishizawa/inbox/ntf-20260704-1530-external-if-review.md`
- `_index/recent_changes.md` update
- `_index/by_topic.md` update

Risk observed:

- Any Claude-side direct edit to shared `_index/*.md` files can create OneDrive conflicts. Current design avoids this by writing append-only events during workflow and using admin-run Python generated rollups later.

### T2: Sato Opens Workspace Before Sync Fully Settles

Sato's local folder has:

- source file synced,
- proposal synced,
- but `_index/by_topic.md` still stale.

Claude Code session B runs daily triage.

Risk observed:

- If Claude trusts stale `_index/` too much, it may miss the new proposal.
- `Workspace Navigator` needs a fallback: when recent changes are stale or sync warning exists, check likely lifecycle folders directly.

### T3: Sato Reviews Proposal

Sato reviews:

```text
proposals/prp-20260704-external-if-review-checklist.md
```

Expected action:

- classify as medium risk,
- request patch to official,
- notify Nishizawa or curator.

Risk observed:

- It is unclear whether Sato should write a review finding, a notification, or a comment inside the proposal.
- V0 needs one canonical review response format.

### T4: Patch Draft Is Created

File created:

```text
_patches/open/patch-20260704-external-interface-review-checklist.md
```

Risk observed:

- If no `official/design-review/external-interface.md` exists yet, patch has no concrete target.
- The pilot template should include either a starter official article or allow patches against a proposed future official path.

### T5: Index Update Conflict

Claude Code session A and B both attempt to update:

```text
_index/recent_changes.md
_index/by_topic.md
```

Simulated OneDrive result:

```text
_index/recent_changes (Sato's conflicted copy).md
_index/by_topic (Nishizawa's conflicted copy).md
```

Risk observed:

- Shared mutable index files are a conflict hotspot.
- The design should reduce direct multi-user writes to `_index/*.md`.

### T6: Notification Noise

Notifications created:

- one to source owner,
- one to reviewer,
- one for patch review,
- possibly one for stale index or conflict.

Risk observed:

- Users may receive multiple files for one conceptual workflow.
- Notification Router should collapse related events into one thread or digest when possible.

## Key Findings

| Finding | Severity | Design Impact |
|---|---|---|
| `_index/*.md` files are shared-write conflict hotspots | high | avoid multi-user direct index editing |
| stale indexes can cause Claude to miss new files | high | navigator needs lifecycle-folder fallback |
| patch target may not exist in empty pilot | medium | include starter official article or allow future target |
| review response format is ambiguous | medium | add canonical review response file format |
| notification count can grow quickly | medium | thread/digest notifications by workflow |
| `current_user` must be resolved early | medium | keep resolver as V0 client playbook |
| source owner and reviewer roles need frontmatter clarity | medium | metadata should include `owner` and optional `reviewers` |

## Simulation Verdict

The V0 design is usable, but the simulation reveals three design improvements before real pilot:

1. Avoid direct multi-user writes to shared `_index/*.md` where possible.
2. Add a canonical review response format.
3. Include a starter official article or allow patch target stubs.

## Recommended Adjustments

### Adjustment 1: Event-Based Index Updates

Instead of every user editing `_index/recent_changes.md` directly, V0 can write append-only event files:

```text
_index/events/20260704-1530-nishizawa-source-extracted.md
_index/events/20260704-1545-sato-proposal-reviewed.md
```

Then a curator or later Python helper can roll them up into:

- `_index/recent_changes.md`
- `_index/by_topic.md`
- `_index/by_project.md`

This reduces sync conflict risk.

### Adjustment 2: Review Response Files

Use:

```text
_reviews/open/rev-YYYYMMDD-HHMM-topic.md
```

for review results instead of comments inside proposal files.

Each review response should include:

- reviewed file,
- reviewer,
- verdict,
- risk,
- required action,
- related notification,
- related patch if any.

### Adjustment 3: Notification Threads

For one workflow, use one notification thread where possible:

```text
_notifications/nishizawa/inbox/ntf-20260704-external-if-review.md
```

Update status inside the same notification or create a digest entry rather than producing many small notifications.

### Adjustment 4: Starter Official Article

The template pack should include:

```text
official/design-review/external-interface.md
```

as a starter official page with minimal content. This gives patch drafting a real target during the pilot.

## What Real Pilot Still Must Validate

- Actual SharePoint permission behavior.
- Actual OneDrive conflict naming on the target company environment.
- Whether Claude Code handles file placeholders or offline-only files.
- Whether users tolerate the proposed notification and review flow.
- Whether event-based index updates are too indirect for humans.
