---
type: research
title: "SharePoint AI Knowledge Workspace Private Raw Evidence Rehearsal Simulation"
status: active
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
tags:
  - research
  - simulation
  - raw
  - pilot
  - simple-minimum
related:
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
---

# SharePoint AI Knowledge Workspace Private Raw Evidence Rehearsal Simulation

## Purpose

Simulate the first private Simple Minimum rehearsal after adding optional project `.raw/` converted Markdown evidence.

Question:

```text
Can the pilot stay simple while supporting converted Excel/PPTX/document Markdown as valuable source evidence?
```

## Scenario A: Note-Only Rehearsal

Context:

- The first source is a normal Markdown meeting note.
- No Excel, PowerPoint, PDF, or Word conversion is involved.
- The user wants to prove the smallest source-to-reviewed-to-patch loop.

Flow:

1. Create the Simple Minimum folder tree.
2. Omit `projects/sample-project/.raw/`, or leave it empty.
3. Add the note under `projects/sample-project/sources/`.
4. Claude extracts reviewed knowledge.
5. If official content should change, Claude drafts a root `_patches/open/` file.
6. `kw-maint doctor`, if available, runs `scan`, `validate`, `conflict-scan`, and `rebuild-indexes --dry-run`; `raw-validate` is skipped.

Finding: This remains the best first rehearsal if the goal is pure workflow proof.

## Scenario B: Converted Excel Rehearsal

Context:

- The first source is `vendor_checklist.xlsx`.
- An admin manually or later Python-converts it to Markdown.
- The pilot needs to prove source traceability and future reingest value.

Flow:

1. Place converted Markdown at `projects/sample-project/.raw/xlsx/vendor_checklist.md`.
2. Preserve `original_file_path`, `original_file_name`, `original_file_type`, `converted_from`, and `converted_at`.
3. Claude reads the `.raw` Markdown and creates reviewed knowledge.
4. Reviewed knowledge cites the `.raw` Markdown in `source_files`.
5. Project `_index.md` may list the file as source evidence, but not as reviewed or official knowledge.
6. `kw-maint doctor` runs `raw-validate` because `.raw/` exists.

Finding: This proves more value, but it is slightly heavier. It should be chosen only if the user wants to test converted source handling from the start.

## Scenario C: Converted PowerPoint With Partial Extraction

Context:

- A PowerPoint has slide bullets plus diagrams.
- Markdown conversion captures bullets but not diagrams.

Friction:

- A reader may assume the Markdown is complete.
- Claude may over-extract if the warning is hidden.

Required behavior:

- Use `conversion_warning` in frontmatter or a visible note in the body.
- Reviewed knowledge should mention that diagram-dependent claims need original-file confirmation.
- `kw-maint doctor` reports `raw_conversion_warning`, but does not block the pilot.

Finding: Warnings should remain visible and factual. They are not a reason to create a new V0 skill.

## Scenario D: User Searches Shared Area Before Local Pull

Context:

- A user searches SharePoint for "vendor evidence checklist".
- Search results include project README, project `_index.md`, reviewed article, and `.raw` converted Markdown.

Desired user experience:

- Project README and `_index.md` tell the user where trusted project knowledge lives.
- Reviewed and official pages are written for human reading.
- `.raw` files are still findable when the user needs the source detail.

Risk:

- Search result order may surface `.raw` before reviewed knowledge.

Mitigation:

- Keep `.raw` file titles explicit, for example `Converted Source: vendor_checklist.xlsx`.
- Project `_index.md` should label `.raw` as source evidence.
- Claude read order remains `official -> reviewed -> notes/sources -> .raw evidence`.

Finding: SharePoint search value improves, but project indexes must teach the trust boundary.

## Scenario E: Multi-Project Common Candidate Detection

Context:

- Three projects each have converted vendor checklist Markdown under `.raw/`.
- Two reviewed articles overlap.
- Admin Python later creates a common-candidate report.

Expected behavior:

- `.raw` files can support evidence counts and source traceability.
- The common-candidate report should point to reviewed articles first and `.raw` evidence second.
- No automatic merge happens.
- Old reviewed articles become `superseded` only after a human-approved merge plan.

Finding: `.raw` helps discovery, but merge authority still belongs to reviewed articles, official patches, and human review.

## Scenario F: Client Token Budget

Context:

- A normal user asks Claude Code a project question.
- The workspace has many `.raw` files.

Token-safe read path:

1. Read root `CLAUDE.md` and relevant indexes.
2. Read project README and `_index.md`.
3. Read official/reviewed pages first.
4. Read `.raw` only when evidence detail, source reingest, or stale conversion verification is needed.

Finding: `.raw` increases stored knowledge value without requiring ordinary client sessions to read every source file.

## Design Adjustments

1. Keep note-only rehearsal as the default simplest first pilot.
2. Allow raw-converted rehearsal as an explicit alternate first pilot when source conversion is the thing being tested.
3. Add a `simple_minimum_with_raw_valid` doctor fixture so `.raw` can pass cleanly when metadata is correct.
4. Add a raw-derived reviewed article fixture for missing `source_files` citation, using the existing `reviewed_missing_source_files` issue code.
5. Keep `raw-validate` conditional; do not make conversion automation part of V0.
6. Make project indexes label `.raw` as source evidence if they list it.

## Verdict

The optional `.raw` layer is worth keeping, but it should not become the default mental model.

Best pilot choice:

- choose note-only source if the next goal is proving the workflow,
- choose converted Excel/PPTX/document Markdown if the next goal is proving source traceability and SharePoint-side search value.

Both paths fit the same Simple Minimum Profile as long as `.raw` remains source evidence and `raw-validate` remains conditional.
