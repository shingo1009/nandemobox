---
type: research
title: "SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation"
status: active
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
tags:
  - research
  - simulation
  - raw
  - deletion
  - tombstone
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace Raw Converted Markdown Source Policy]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
  - "[[SharePoint AI Knowledge Workspace Article Integration Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Dry Run Implementation Plan]]"
---

# SharePoint AI Knowledge Workspace Raw Source And Tombstone Simulation

## Purpose

Simulate the combined lifecycle of:

- original Excel / PowerPoint files,
- converted Markdown under `.raw/`,
- extracted or reviewed articles,
- article merge cleanup,
- tombstones and deletion plans.

The key question:

```text
Can the workspace preserve source traceability and avoid SharePoint deletion surprises while still keeping article views clean?
```

## Scenario 1: Excel Is Converted To Raw Markdown

Context:

- Project `vendor-review` receives `vendor_checklist.xlsx`.
- The Excel file has multiple sheets: risks, actions, open questions.
- A user wants Claude Code to extract reusable review points.

Flow:

1. Admin or user converts the Excel to Markdown.
2. The converted file is placed at `projects/vendor-review/.raw/xlsx/vendor_checklist.md`.
3. Frontmatter includes `original_file_path`, `original_file_name`, `original_file_type`, `converted_from`, and `converted_at`.
4. Claude Code reads only the converted Markdown and creates an extraction or proposal.
5. The generated article cites the `.raw` Markdown in `source_files`.

Good outcome:

- clients do not need Excel parsing in every session,
- SharePoint search can find text inside the converted Markdown,
- later reingest can start from `.raw` even if the client lacks Office tooling,
- the original file path is still available for evidence checks.

Finding: Converted Markdown is immediately valuable even before automation exists.

## Scenario 2: PowerPoint Is Converted But Images Are Incomplete

Context:

- A project briefing PowerPoint contains slide text plus diagrams.
- The Markdown conversion captures slide titles and bullets but not image content.

Expected raw Markdown:

- frontmatter says `conversion_tool` and `converted_at`,
- body includes one section per slide,
- image-only slides are marked as placeholders,
- sensitivity remains visible.

Risk:

- Claude may over-trust an incomplete conversion.

Required care:

- converted Markdown should include a conversion notice,
- image or chart gaps should be explicit,
- Claude should cite the `.raw` Markdown and mention when a conclusion depends on missing image details,
- admin Python may later report `conversion_warning` if image placeholders exist.

Finding: `.raw` Markdown is readable evidence, not proof that the whole original was faithfully captured.

## Scenario 3: Reviewed Article Is Merged Into A Common Article

Context:

- Project A has `reviewed/vendor-risk-checklist.md`.
- Project B has `reviewed/vendor-evidence-checklist.md`.
- Both were extracted from converted `.raw` Excel/PPTX files.
- A common article is created: `reviewed/common/vendor-review-evidence.md`.

Unsafe cleanup:

- delete both project reviewed articles immediately,
- leave no old-path guidance,
- remove `.raw` files as "duplicates".

Safe cleanup:

1. Keep all `.raw` converted Markdown files.
2. Mark old reviewed articles `status: superseded`.
3. Replace old article bodies with tombstones or short redirect content.
4. Link each old article to the common article.
5. Record an event.
6. Let admin Python exclude tombstones from active generated indexes.

Finding: article merge does not imply source cleanup. The `.raw` files remain the evidence chain.

## Scenario 4: SharePoint Delete Alert Risk

Context:

- The admin wants to remove 30 superseded articles after a cleanup pass.
- The team watches the SharePoint library and receives deletion alerts.

If hard delete happens immediately:

- users see many deletion alerts,
- some users may think knowledge was lost,
- links in chats or tickets break,
- Claude answers may lose old trace paths.

Better path:

- keep tombstones indefinitely if alerts are politically noisy,
- hide tombstones from active generated indexes,
- batch any actual deletes into one planned maintenance window,
- create `_reviews/open/maint-deletion-plan-YYYYMMDD.md`,
- confirm replacement links and rollback path before deletion.

Finding: in a SharePoint culture, tombstones may be cheaper than deletion.

## Scenario 5: Original Binary Changes After Conversion

Context:

- `vendor_checklist.xlsx` is updated after `vendor_checklist.md` was generated.
- The converted Markdown is now stale.

Expected `raw-validate` signal:

| Check | Result |
|---|---|
| `original_file_modified_at > converted_at` | warning |
| `original_file_path` exists | pass or warning if unavailable |
| generated articles cite stale `.raw` file | warning |

Claude role:

- do not silently update derived articles,
- explain that the source conversion may be stale,
- propose reconversion or review.

Finding: stale raw conversions are a maintenance signal, not an automatic rewrite trigger.

## Scenario 6: Scale With Many Raw Files

Context:

- 20 projects,
- 400 converted Markdown files under `.raw`,
- 250 reviewed articles,
- 60 tombstones.

Without guardrails:

- `.raw` becomes a second article corpus,
- Claude may answer from raw source when reviewed/official knowledge exists,
- tombstones pollute search and indexes.

With guardrails:

- trust order remains `official -> reviewed -> proposal/extracted -> .raw source`,
- generated indexes hide tombstones from active views,
- `.raw` appears in source/evidence reports, not as current knowledge,
- common-candidate detection may use `.raw` as evidence but not as final answer.

Finding: `.raw` must be searchable and ingestible, but not presented as the main WIKI article layer.

## Design Adjustments

1. Keep `.raw` converted Markdown as source evidence with `status: source`.
2. Add `conversion_warning` as an optional field when conversion is partial.
3. Keep `raw-validate` in `doctor` when `.raw` exists.
4. Do not make `convert-source` part of V0 `doctor`; it is an explicit admin action later.
5. Treat tombstones as navigation aids, not active articles.
6. Let generated indexes omit tombstones by default while keeping them findable by path/search.
7. Never delete `.raw` evidence as part of article merge cleanup.

## Verdict

The combined design works if the layers stay separate:

```text
original binary
  -> converted .raw Markdown
  -> extracted/proposed/reviewed article
  -> common article or official patch
  -> old article tombstone
```

This gives the shared system immediate value: even before full automation, placing converted Markdown under `.raw/` makes source material searchable, portable, and ingestible by clients.
