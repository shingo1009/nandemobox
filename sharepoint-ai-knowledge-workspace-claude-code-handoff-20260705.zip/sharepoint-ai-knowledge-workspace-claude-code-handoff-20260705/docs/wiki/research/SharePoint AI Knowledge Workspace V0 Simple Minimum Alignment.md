---
type: research
title: "SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment"
status: active
created: 2026-07-05
updated: 2026-07-05
tags:
  - research
  - v0
  - simplification
  - design-alignment
related:
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Template Pack]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Simplicity Optimization Pass]]"
---

# SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment

## Purpose

Align the existing SharePoint AI Knowledge Workspace design with the new [[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]] source.

This is design-only. It does not create a pilot folder.

## Main Adjustment

The new source strengthens the existing simplicity direction:

```text
V0 should prove one safe knowledge circulation loop, not the whole platform.
```

Therefore V0 should now be described with two profiles:

| Profile | Meaning | Use |
|---|---|---|
| Simple Minimum Profile | Smallest folder and rule set that can run one pilot loop. | Default first pilot target |
| Expansion Pack | Additional folders, rule files, playbooks, and helpers that are already designed but not required first. | Add only after observed pain |

## Simple Minimum Profile

The first pilot should be able to run with:

```text
knowledge-workspace/
├─ README.md
├─ CLAUDE.md
├─ _system/
│  ├─ users.md
│  ├─ status_rules.md
│  ├─ write_rules.md
│  └─ patch_rules.md
├─ _index/
│  ├─ by_project.md
│  ├─ by_topic.md
│  └─ events/
├─ _notifications/
│  └─ {user}/
│     ├─ inbox/
│     └─ digest.md
├─ _reviews/
│  └─ open/
├─ _patches/
│  └─ open/
├─ projects/
│  └─ sample-project/
│     ├─ README.md
│     ├─ _index.md
│     ├─ sources/
│     ├─ notes/
│     ├─ reviewed/
│     └─ official/
└─ archive/
```

## Expansion Pack

These are still useful, but should not be required for the first pilot:

- root `sources/`,
- root `extracted/`,
- root `proposals/`,
- root `reviewed/`,
- root `official/` beyond a README or cross-project placeholder,
- `_system/metadata_schema.md`,
- `_system/notification_rules.md`,
- `_system/archive_rules.md`,
- `_system/permission_rules.md`,
- `_system/skill_*.md`,
- `_index/recent_changes.md`,
- `_index/official_index.md`,
- `_index/notification_summary.md`,
- `_notifications/_template/`,
- full project-local workflow queues,
- Python helpers,
- search database,
- MCP/API layer,
- GROWI or web UI.

## Operating Flow Adjustment

The first pilot loop should be:

```text
projects/sample-project/sources/meeting.md
  -> Claude extraction / proposal / reviewed candidate
  -> notification if human action is needed
  -> patch to projects/sample-project/official/external-interface.md if official should change
  -> _index/events/ record
```

This means root `extracted/` and root `proposals/` may exist as later expansion folders, but they should not be required for the first useful loop.

## Rule File Adjustment

Minimum `_system` rule files:

| File | Reason |
|---|---|
| `users.md` | resolves current user and notification folder |
| `status_rules.md` | keeps `source`, `reviewed`, and `official` understandable |
| `write_rules.md` | protects official and source evidence |
| `patch_rules.md` | keeps official changes patch-first |

Optional after first pilot:

| File | Add When |
|---|---|
| `metadata_schema.md` | metadata gaps become common |
| `notification_rules.md` | notification volume grows |
| `archive_rules.md` | stale files appear |
| `permission_rules.md` | SharePoint permission validation starts |

## Design Decision

Adopt the new source as the V0 default:

- Simple Minimum Profile is the first pilot target.
- The larger Template Pack remains valid as an expansion pack.
- Do not remove the expansion design, but stop presenting it as mandatory for the first pilot.

## Risks

| Risk | Mitigation |
|---|---|
| Too much is deferred and the pilot lacks governance. | Keep `CLAUDE.md`, `write_rules.md`, and `patch_rules.md` mandatory. |
| Root cross-project knowledge has no place. | Allow root `official/README.md` or root `official/` as an expansion placeholder, but do not require cross-project official articles in the first loop. |
| Proposal/extraction trace becomes unclear. | Use `_reviews/open/`, project `reviewed/`, notifications, and `_index/events/` for the first loop; add root `extracted/` or `proposals/` only if the trace is too thin. |
| Future automation lacks metadata. | Keep the five expansion fields visible: `status`, `project`, `owner`, `source_files`, and `generated_by`. |

## Recommendation

Freeze V0 around:

```text
Project WIKI + Notifications + Official Patch
```

with the success condition:

```text
one non-sensitive source note circulates safely into reviewed or official-change proposal with traceable Markdown evidence.
```
