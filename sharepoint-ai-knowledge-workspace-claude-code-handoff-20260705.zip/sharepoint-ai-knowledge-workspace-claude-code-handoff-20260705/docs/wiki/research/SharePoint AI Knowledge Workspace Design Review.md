---
type: research
title: "SharePoint AI Knowledge Workspace Design Review"
status: active
created: 2026-07-04
updated: 2026-07-04
tags:
  - research
  - design-review
  - operations
  - sharepoint
related:
  - "[[SharePoint AI Knowledge Workspace]]"
  - "[[SharePoint AI Knowledge Workspace Project]]"
  - "[[AI Review Notification]]"
---

# SharePoint AI Knowledge Workspace Design Review

## Review Position

The direction is strong because it optimizes for adoption before infrastructure. The main design risk is not whether SharePoint can store Markdown; it is whether the folder remains understandable after many humans and AI agents add files.

The design should therefore be optimized around three constraints:

- Users must know where to put things.
- Claude Code must know what it may read and write.
- Official knowledge must remain protected from accidental AI or sync-conflict edits.

## Bias Log

This review may be biased toward simple filesystem workflows because they are easier to reason about locally. Counterweight: SharePoint / OneDrive sync introduces real multi-user race conditions that a plain local folder does not have. The design should not pretend local-file ergonomics remove shared-state risk.

## What To Preserve

- SharePoint / OneDrive first is pragmatic.
- Markdown as the canonical editable format is appropriate.
- Status separation is essential.
- Patch-first editing is the right safety boundary.
- File-based notifications are a good first step because Claude Code can read and summarize them.
- `reviewed` as provisional knowledge avoids blocking on perfect governance.

## Simplify The First Flow

The original folder tree is useful as a future map, but MVP should reduce the first daily path:

```text
sources/ -> extracted/ -> proposals/ -> reviewed/ -> official/
              |
              v
       _notifications/{user}/inbox/
```

Everything else should support that path.

Do not start with many command files. Start with three user-facing commands or prompts:

- "自分宛通知を確認して"
- "このsourceから抽出してproposalを作って"
- "officialに反映すべき差分だけpatchにして"

## Operational Risk Register

| Risk | Why it matters | Mitigation |
|---|---|---|
| OneDrive sync conflict | Two users or AI sessions may edit related files at the same time. | Avoid direct official edits; use patches; include recent-change regeneration; detect `conflicted copy` filenames. |
| Folder sprawl | The workspace can become another file dump. | Keep root small; generated indexes; archive rules; weekly digest. |
| Metadata burden | Too many required fields will stop contribution. | Require only title, status, owner, project/topic if known; let AI propose missing fields. |
| Official/proposal confusion | Users may treat unreviewed AI output as policy. | Status frontmatter, folder separation, answer priority rules in `CLAUDE.md`. |
| AI over-notification | Users will ignore noisy notifications. | Severity, digest, duplicate suppression, weekly low-priority batch. |
| Psychological safety | People may feel monitored if personal notes are scanned. | Use opt-in `people/` sharing, owner control, careful wording, no direct correction of others' files. |
| Permission drift | SharePoint access may not match project confidentiality. | Use SharePoint groups by project; separate restricted workspaces when necessary. |
| Stale indexes | Claude Code may trust old generated files. | Include generated timestamp; regenerate indexes before major review; flag stale indexes. |
| Broken ownership | Notifications fail if owners are inconsistent. | Define user IDs in `_system/users.md` or metadata schema. |
| Unbounded AI-generated files | Extracted/proposal/review files may multiply. | Add TTL/archive rules for stale generated files. |

## Governance Recommendation

Use risk-based promotion:

| Knowledge type | Suggested promotion rule |
|---|---|
| FAQ, examples, links, terminology | 1 reviewer can move to `reviewed` |
| Review checklist, operational procedure | 1 reviewer can move to `reviewed`; owner review before `official` |
| Contract, authority, production incident policy, security rule | owner or multiple reviewers before `reviewed`; explicit approval before `official` |

Do not require the same approval strength for every knowledge item.

## Recommended MVP Boundary

MVP should prove:

- A user can contribute by dropping a source note.
- Claude can extract useful candidates.
- Claude can notify the right person.
- A human can accept or reject a proposal.
- Official knowledge is protected.

MVP should not yet prove:

- Perfect duplicate detection.
- Full semantic conflict resolution.
- Automated SharePoint crawling.
- Multi-project taxonomy completeness.
- GROWI or MCP migration.

## Persona-Level Design Check

### Contributor

The contributor wants to drop a note without learning a taxonomy first. The design should only require:

- Put the note in `sources/` or `people/{current_user}/`.
- Give it a readable title.
- Include project or topic if obvious.
- Ask Claude Code to extract or propose.

If contribution requires perfect frontmatter, the workspace will fail before it starts.

### Reviewer

The reviewer wants to see only items that need judgment. The design should give them:

- `_notifications/{user}/inbox/` for direct items.
- `_reviews/open/` for shared review backlog.
- Severity and recommended action.
- A visible accept, reject, defer, or request-change path.

### Curator

The curator protects the workspace from entropy. The design should give them:

- `_index/recent_changes.md`
- `_index/official_index.md`
- stale proposal list
- missing metadata list
- duplicate and conflict candidate lists
- archive candidates

The curator role can be human, AI-assisted, or rotating.

## Proposed V0 Operating Checklist

Before adding Python commands or server components, the workspace can be tested with this manual plus Claude Code checklist:

1. Create the minimal folder tree from [[SharePoint AI Knowledge Workspace]].
2. Add `README.md` with "where to start" links.
3. Add `CLAUDE.md` with read priority and write restrictions.
4. Create `_system/metadata_schema.md`, `_system/status_rules.md`, and `_system/write_rules.md`.
5. Create `_notifications/{pilot_user}/inbox/`.
6. Add one real meeting note to `sources/`.
7. Ask Claude Code to extract decisions, risks, review points, and FAQ candidates into `extracted/`.
8. Ask Claude Code to create one proposal in `proposals/`.
9. Ask Claude Code to create one notification for the pilot user.
10. Accept or reject the proposal and record the result.

If this loop feels heavy, adding automation will only automate a bad workflow.

## Information Architecture Recommendation

Prefer status plus shallow folders over deep classification early on.

Recommended first split:

```text
sources/
extracted/
proposals/
reviewed/
official/
people/
projects/
```

Avoid creating many topic subfolders until there are enough files to justify them. Use `topics:` metadata and `_index/by_topic.md` first.

## Future Evolution Map

| Stage | Trigger | Add |
|---|---|---|
| V0 convention pilot | 1-2 users, one project | folders, `CLAUDE.md`, manual Claude Code prompts |
| V1 deterministic helper | indexes become stale or metadata is inconsistent | `knowledge scan`, `knowledge index`, metadata validation |
| V2 review operations | notifications and proposals grow | review queue summaries, duplicate suppression, stale proposal archive |
| V3 search layer | Markdown search is too weak | local SQLite or search index generated from Markdown |
| V4 server layer | many users need web UI or stronger permissions | GROWI, MCP, or custom service as publishing/control plane |

The design should not skip stages. Each stage should be justified by actual operational pain.

## Future Considerations

### If The Workspace Grows

Add project-scoped workspaces only after the global flow works. Prematurely mirroring `sources/extracted/proposals/reviewed/official` inside every project will make the design harder to teach.

### If Governance Becomes Important

Introduce an explicit approval record:

```yaml
approved_by:
  - user-id
approved_at: 2026-07-04
approval_reason: "low-risk FAQ addition"
```

### If Search Becomes Weak

Move from file indexes to a local SQLite or search index, but keep Markdown as the human-editable source of truth.

### If Server Features Become Necessary

GROWI or MCP can be added later as a publishing and access layer. It should not replace the Markdown lifecycle until the workspace conventions have proven useful.

## Design Questions To Continue

- What is the smallest `CLAUDE.md` that prevents dangerous writes without overwhelming users?
- Should notifications be per-person folders or one shared queue filtered by owner?
- How should Claude Code identify `current_user` reliably on different machines?
- Should `official/` be read-only at SharePoint permission level, or protected only by convention?
- How should accepted patches be recorded if file moves are awkward through OneDrive sync?
