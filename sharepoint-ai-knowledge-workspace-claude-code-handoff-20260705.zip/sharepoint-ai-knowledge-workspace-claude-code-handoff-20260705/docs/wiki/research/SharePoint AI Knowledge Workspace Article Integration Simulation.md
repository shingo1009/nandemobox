---
type: research
title: "SharePoint AI Knowledge Workspace Article Integration Simulation"
status: active
created: 2026-07-05
updated: 2026-07-05
tags:
  - research
  - simulation
  - article-quality
  - merge
  - revision
  - scale
related:
  - "[[SharePoint AI Knowledge Workspace Article Quality Rubric]]"
  - "[[SharePoint AI Knowledge Workspace Knowledge Lifecycle State Machine]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]"
  - "[[SharePoint AI Knowledge Workspace Design Coverage Audit]]"
  - "[[SharePoint AI Knowledge Workspace Article Deletion And Tombstone Policy]]"
---

# SharePoint AI Knowledge Workspace Article Integration Simulation

## Purpose

Simulate how articles are revised, merged, or kept separate when multiple project mini-wikis produce overlapping knowledge.

This targets the long-term problem: a shared Markdown workspace is useful only if articles improve over time without turning into an uncontrolled pile of near-duplicates.

## Minimal Merge Principle

```text
Do not merge because titles look similar.
Merge only when shared scope, evidence, owner path, and user action are clear.
```

The system should prefer a small merge plan over direct edits.

## Scenario 1: Two Similar Project Notes

Context:

- Project A has `reviewed/source-backed-claims.md`.
- Project B has `reviewed/evidence-requirements.md`.
- Both describe source-backed claims.
- Project A is a product planning context.
- Project B is a compliance review context.

Python signal:

- similar topic label,
- similar headings,
- two different project owners,
- no same official target.

Claude `knowledge_steward` review:

| Question | Result |
|---|---|
| Same user action? | Mostly yes: link claims to source evidence. |
| Same risk level? | No: compliance is stricter. |
| Same owner path? | No. |
| Can one common article serve both? | Partially. |

Recommended action:

- create a common reviewed article only for the shared low-risk principle,
- leave stricter compliance requirements project-local,
- add cross-links between project notes and the common note.

Finding: the merge output should be "common core plus project deltas", not one flattened article.

## Scenario 2: Existing Article Needs Revision

Context:

- A reviewed article says "one reviewer is enough for all checklist updates."
- A later source says security checklist updates need owner approval.
- The reviewed article is being cited by two projects.

Bad behavior:

- directly rewrite the reviewed article in place,
- silently broaden the rule,
- notify everyone.

Better behavior:

1. Create `_reviews/open/article-revision-YYYYMMDD-security-checklist.md`.
2. Classify revision type: `scope_narrowing`.
3. Cite both the old reviewed note and the new source.
4. Propose one patch if an official file is affected.
5. Notify only the owner or reviewer with `needs_action`.

Finding: revision type matters. A correction, extension, contradiction, and scope narrowing should not be treated the same.

## Scenario 3: Three Duplicate FAQs

Context:

- three projects each have a short FAQ about "where to place meeting notes",
- content is low risk,
- the answer is identical except for project folder names.

Recommended action:

- keep project-local examples,
- create one root or shared reviewed FAQ pattern,
- link from each project README or `_index.md`,
- avoid official patch unless the root README promises a different rule.

Finding: low-risk FAQ duplication is safe to consolidate lightly. It should not require a heavyweight official patch unless official guidance changes.

Deletion care:

- do not immediately delete the three old FAQ files,
- mark old files `superseded` if a shared FAQ replaces them,
- keep a short tombstone that points to the shared FAQ,
- let admin maintenance hide tombstones from active generated indexes later.

## Scenario 4: Conflicting Operational Procedure

Context:

- Project A says patches can be applied by the project owner.
- Project B says only the workspace curator can apply patches.
- Both cite real meetings.

Recommended action:

- mark as `authority_conflict`,
- keep both notes project-local until authority is resolved,
- create one `_reviews/open/conflict-YYYYMMDD-patch-application.md`,
- route to curator as `needs_action`,
- do not create a common article yet.

Finding: contradictions are not merge work. They are authority-resolution work.

## Scenario 5: Scale Stress

Context:

- 15 projects,
- 900 Markdown files,
- 60 reviewed notes,
- 30 common-candidate signals,
- 12 stale reviewed notes.

Without guardrails:

- Claude rereads many near-duplicate pages,
- common pages grow too large,
- stale notes remain trusted because they are "reviewed",
- project-local nuance disappears.

With guardrails:

- Python lists candidate clusters with reason codes and file counts,
- Claude reviews only top clusters,
- each merge plan has a single recommended action,
- common articles keep only shared core rules,
- project-specific deltas stay linked from project pages.

Finding: article integration needs a bounded merge plan template, not another broad skill.

## Merge Decision Types

Use this compact decision set:

| Decision | Use When | Output |
|---|---|---|
| `keep_separate` | similar title but different scope or owner | add note explaining difference |
| `cross_link` | related but not mergeable | add proposed links |
| `merge_common_core` | shared principle with project-specific deltas | draft common reviewed article plus links |
| `revise_existing` | an existing reviewed article is stale or incomplete | article revision review file |
| `patch_official` | official content must change | official patch flow |
| `authority_conflict` | sources disagree on who decides | curator review, no merge |

## Delete And Tombstone Rule

Article integration can recommend deletion cleanup, but it must not perform hard delete.

After `merge_common_core` or `revise_existing`, old articles should move through:

```text
superseded
  -> tombstone at old path
  -> archive candidate after retention
  -> hard delete only by admin plan, if still necessary
```

This avoids SharePoint deletion alerts during normal merge work and keeps old links usable.

## Article Size Budget

To keep articles usable:

- one article should answer one user question or support one decision,
- if it contains more than three distinct scopes, split it,
- if it needs more than seven major sections, split or move details to project-local notes,
- common articles should contain shared core rules, not every project exception.

## Recommended Merge Plan Shape

Claude should write this only when a merge or revision is actually useful:

```text
Decision: keep_separate / cross_link / merge_common_core / revise_existing / patch_official / authority_conflict
Risk: low / medium / high
Shared core:
- ...
Project-specific deltas:
- Project A: ...
- Project B: ...
Evidence:
- ...
Recommended files:
- create/update/link only
Needs action:
- owner/reviewer and reason
```

## Design Adjustments

1. Keep article integration inside `knowledge_steward`; do not create a new V0 skill.
2. Treat Python duplicate detection as candidate clustering only.
3. Use merge plans before editing reviewed/common articles.
4. Separate common core from project-specific deltas.
5. Use `authority_conflict` instead of merging contradictory rules.
6. Add a small article size budget to prevent common articles from becoming dumping grounds.
7. Use tombstones for merged or replaced articles; do not treat merge completion as permission to delete old files.

## Verdict

The current lifecycle can support article integration if one missing habit is added:

```text
candidate cluster
  -> merge plan
  -> human acceptance
  -> reviewed/common note, cross-links, or official patch
```

This keeps the design compact. The workspace does not need a separate "article merge skill" yet.
