---
type: research
title: "SharePoint AI Knowledge Workspace End To End V0 Pilot Simulation"
status: active
created: 2026-07-05
updated: 2026-07-05
tags:
  - research
  - simulation
  - v0
  - pilot
  - simplification
  - operations
related:
  - "[[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]"
  - "[[SharePoint AI Knowledge Workspace V0 Operating Flow]]"
  - "[[SharePoint AI Knowledge Workspace Weekly Loop Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Article Integration Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Design Coverage Audit]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
---

# SharePoint AI Knowledge Workspace End To End V0 Pilot Simulation

## Purpose

Run one end-to-end tabletop simulation across the current V0 design.

This checks whether the design now works as one coherent system:

- simple first use,
- bounded Claude Code behavior,
- admin-run Python maintenance,
- project mini-wikis,
- official patch safety,
- weekly motivation,
- article integration without skill sprawl.

## Starting Assumptions

V0 uses [[SharePoint AI Knowledge Workspace Runtime Minimal Skill Pack]]:

- one shared SharePoint / OneDrive Markdown workspace,
- one pilot project mini-wiki,
- root `_notifications/`, `_reviews/open/`, `_patches/open/`, and `_index/`,
- four required `_system` files,
- three Claude behavior modes,
- admin-run `kw-maint doctor` dry-run,
- no automatic weekly distribution,
- no automatic article merge.

## Day 0: Private Setup

Admin creates a Simple Minimum Profile folder from the materialization plan.

Required files:

- root `README.md`,
- root `CLAUDE.md`,
- `_system/users.md`,
- `_system/status_rules.md`,
- `_system/write_rules.md`,
- `_system/patch_rules.md`,
- one project mini-wiki.

Expected friction:

- there are many design pages, but the materialized workspace should expose only the simple files.

Design check:

- pass if a contributor sees "project WIKI + notifications + official patch",
- fail if they see the whole design library.

## Day 1: Contributor Adds A Source

Contributor drops a meeting note into:

```text
projects/sample-project/sources/
```

They ask Claude:

```text
このsourceから抽出してproposalを作って。
```

Claude behavior:

- `workspace_navigator` narrows to the project,
- `knowledge_steward` extracts reusable points,
- writes a review item under `_reviews/open/` or a project reviewed candidate after approval,
- creates one `needs_action` notification only if human decision is needed.

Design check:

- pass: contributor does not need to know lifecycle internals,
- pass: Claude does not scan the whole shared folder,
- pass: official files remain untouched.

## Day 2: Reviewer Acts

Reviewer asks:

```text
自分宛通知を確認して。
```

Claude behavior:

- `workspace_navigator` reads only the reviewer inbox/digest and relevant project index,
- shows `needs_action` first,
- recommends accept, revise, reject, defer, or patch official.

Design check:

- pass if the reviewer sees one decision, not a pile of FYI,
- fail if review requires understanding every folder.

## Day 3: Official Patch

The accepted note implies an official rule should change.

User asks:

```text
officialに反映すべき差分だけpatchにして。
```

Claude behavior:

- `patch_reviewer` creates `_patches/open/patch-YYYYMMDD-topic.md`,
- includes target file, evidence, risk, reviewer, and rollback note,
- checks same-target open patches,
- does not edit `official/`.

Design check:

- pass: official mutation is serialized,
- pass: patch can be rejected without losing the reviewed note.

## Day 5: Admin Maintenance

Admin runs:

```text
kw-maint doctor
```

Python behavior:

- scans projects,
- validates metadata and required files,
- detects OneDrive conflict patterns,
- previews generated index changes,
- does not write by default.

Design check:

- pass: normal client PCs did not run maintenance,
- pass: admin sees deterministic issues before Claude spends tokens,
- fail if `doctor` tries to make semantic decisions.

## Week 2: Weekly Motivation

There are enough events for a weekly summary.

Python produces a raw skeleton under `_reviews/open/`.

Claude behavior:

- `knowledge_steward` turns it into a short curator-reviewed note,
- keeps maximum five topics,
- sends direct notification only for `needs_action`.

Design check:

- pass: weekly note shows useful motion,
- pass: it does not become a broadcast newsletter,
- pass: raw maintenance details stay away from normal readers.

## Week 4: Common Candidate And Article Integration

Two projects now contain similar reviewed notes.

Python common candidate:

- repeated topic label,
- similar headings,
- medium confidence,
- no automatic merge.

Claude behavior:

- `knowledge_steward` creates a merge plan,
- separates shared core from project deltas,
- chooses one: `keep_separate`, `cross_link`, `merge_common_core`, `revise_existing`, `patch_official`, or `authority_conflict`.

Design check:

- pass: no new article-merge skill is required,
- pass: common knowledge grows without flattening project nuance.

## Month 3: Scale Stress

Workspace grows to:

- 10 projects,
- 500+ Markdown files,
- weekly common-candidate reports,
- several stale proposals,
- multiple patch candidates.

Expected behavior:

- Python indexes become the first navigation layer,
- Claude starts from indexes/reports instead of scanning folders,
- weak common candidates are deferred or closed,
- expansion triggers are evaluated from real pain.

Design check:

- pass if client Claude sessions remain narrow,
- fail if every user needs admin behavior,
- fail if common pages become exception dumps.

## Convergence Findings

| Area | Result | Note |
|---|---|---|
| Human model | converged | `Project WIKI + Notifications + Official Patch` is still the simplest explanation. |
| Claude skill surface | converged | Three behavior modes cover current needs. |
| Python responsibility | converged for design | Admin-run deterministic maintenance is the right boundary. |
| Weekly motivation | converged for tabletop | Useful only when curator-reviewed and capped. |
| Article integration | converged for tabletop | Merge plan is enough; no V0 merge skill needed. |
| Real cloud behavior | unproven | SharePoint permissions and OneDrive conflicts still need real validation. |
| Actual files | unproven | No pilot folder has been materialized. |
| Python implementation | unproven | `kw-maint doctor` is designed but not built. |

## Design Adjustment

The next design focus should shift from adding more skills to proving the thin runtime:

1. materialize a private Simple Minimum folder,
2. run the file consistency checklist against actual files,
3. implement or mock `kw-maint doctor`,
4. run the Day 1 to Day 5 scenario with one real sample source,
5. validate SharePoint / OneDrive behavior before team rollout.

## Verdict

The tabletop design has reached a coherent V0 shape.

It is not "complete" as a deployable system because the real folder, real SharePoint behavior, and Python dry-run tool remain unverified.

But the design direction is now clean:

```text
simple visible workspace
  -> narrow Claude behavior
  -> admin Python maintenance
  -> human authority
  -> expansion only after observed pain
```

