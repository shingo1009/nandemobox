---
type: research
title: "SharePoint AI Knowledge Workspace Pilot Evidence Capture Dry Run"
status: active
created: 2026-07-05
updated: 2026-07-05
project: "SharePoint AI Knowledge Workspace Project"
tags:
  - research
  - simulation
  - pilot
  - evidence
  - validation
related:
  - "[[SharePoint AI Knowledge Workspace Pilot Scenario Selection Matrix]]"
  - "[[SharePoint AI Knowledge Workspace Private Pilot Materialization Plan]]"
  - "[[SharePoint AI Knowledge Workspace Pilot File Consistency Checklist]]"
  - "[[SharePoint AI Knowledge Workspace KW Maint Doctor Acceptance Matrix]]"
---

# SharePoint AI Knowledge Workspace Pilot Evidence Capture Dry Run

## Purpose

Dry-run the pilot evidence note format before any real pilot folder is created.

Question:

```text
If a real rehearsal happens tomorrow, will the evidence note be easy to write and strong enough to guide the next step?
```

## Dry Run A: Note-Only Private Rehearsal

Assumed scenario:

- Source: `projects/sample-project/sources/2026-07-05_external-if-review.md`
- Output: `projects/sample-project/reviewed/external-interface-review.md`
- Patch: `_patches/open/2026-07-05_external-interface-update.md`
- Event: `_index/events/2026-07-05-note-only-rehearsal.md`
- Doctor: not run

Evidence note worked for:

- source path,
- reviewed output path,
- patch output path,
- event path,
- checklist result,
- `pass_with_notes` status.

Friction:

- The template did not explicitly ask which risk was being tested.
- The template did not name the environment: private local folder, private SharePoint test area, or real shared library.
- The template did not make the next action explicit.

Finding: without `selected_risk`, `environment`, and `next_step`, a later reader can see what happened but may not know why it was enough.

## Dry Run B: Raw-Converted Rehearsal

Assumed scenario:

- Raw source: `projects/sample-project/.raw/xlsx/vendor_checklist.md`
- Original file path: preserved in raw frontmatter
- Reviewed output: `projects/sample-project/reviewed/vendor-checklist-summary.md`
- Event: `_index/events/2026-07-05-raw-rehearsal.md`
- Doctor: `raw-validate` warning-free

Evidence note worked for:

- raw source path,
- reviewed output path,
- event path,
- doctor note,
- `pass` status.

Friction:

- The template's `source_files` field can point to the raw Markdown, but the original binary path is only inside the raw frontmatter.
- If the raw frontmatter is wrong, the evidence note should record the specific issue code or warning.

Finding: evidence notes should include a short `signals` or `findings` section for issue codes and important warnings without copying full command output.

## Dry Run C: Blocked Doctor Rehearsal

Assumed scenario:

- `kw-maint doctor` exits `2`.
- Required `_system/patch_rules.md` is missing.
- No manual knowledge loop is run.

Evidence note worked for:

- `blocked` status,
- doctor output path,
- note about missing required file.

Friction:

- The template did not clearly distinguish "scenario blocked before loop" from "loop ran and failed".
- The next action should be a repair action, not another rehearsal.

Finding: `next_step` is necessary for blocked evidence, otherwise the evidence note becomes a dead end.

## Design Adjustments

Update the evidence note template to include:

- `environment`,
- `selected_risk`,
- `signals`,
- `next_step`.

Keep the template short. Do not add a full timeline, screenshots field, or narrative report requirement for V0.

## Verdict

The evidence capture convention is viable, but the template needs three extra pieces of context:

```text
why this scenario was chosen
where it ran
what should happen next
```

That preserves the compact design while making future pilot evidence strong enough to drive decisions.
