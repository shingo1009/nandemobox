---
type: research
title: "SharePoint AI Knowledge Workspace Project Mini Wiki Dry Run"
status: active
created: 2026-07-04
updated: 2026-07-05
tags:
  - research
  - dry-run
  - project-wiki
  - pilot
related:
  - "[[SharePoint AI Knowledge Workspace Project Mini Wiki Structure]]"
  - "[[SharePoint AI Knowledge Workspace Pilot Sample Flow]]"
  - "[[SharePoint AI Knowledge Workspace V0 Readiness Gate]]"
  - "[[SharePoint AI Knowledge Workspace V0 Open Item Disposition Matrix]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Expandable Design]]"
  - "[[SharePoint AI Knowledge Workspace V0 Simple Minimum Alignment]]"
---

# SharePoint AI Knowledge Workspace Project Mini Wiki Dry Run

## Purpose

Re-run the pilot sample after adding the requirement that each shared project should behave as a lightweight independent WIKI.

This checks whether the simple V0 flow still works when source material, project official knowledge, and project browsing live under `projects/{project_slug}/`.

## Input

Project mini-wiki:

```text
projects/sample-project/
├─ README.md
├─ _index.md
├─ official/
│  └─ external-interface.md
├─ reviewed/
├─ sources/
│  └─ 2026-07-04_meeting_external-if-review.md
└─ notes/
```

Root workflow control plane:

```text
_system/
_notifications/
_reviews/open/
_patches/open/
_index/events/
```

## Dry Run Trace

| Step | Artifact | Expected Location | Result |
|---|---|---|---|
| Project entry | project README | `projects/sample-project/README.md` | fits mini-wiki model |
| Project navigation | project index | `projects/sample-project/_index.md` | fits cloud-searchable navigation |
| Source capture | meeting note | `projects/sample-project/sources/2026-07-04_meeting_external-if-review.md` | better than root source for project-specific material |
| Extraction | AI extraction | root `extracted/` or project `notes/` | root `extracted/` is acceptable for workflow; project `notes/` is better for browsable project memory |
| Proposal | reusable candidate | root `proposals/` | acceptable because proposal queue is shared |
| Review verdict | durable review file | root `_reviews/open/` | correct; review queue stays centralized |
| Notification | owner attention | root `_notifications/{user}/inbox/` | correct; user inbox stays centralized |
| Official target | project trusted page | `projects/sample-project/official/external-interface.md` | correct; project official wins for project-specific knowledge |
| Patch draft | official change request | root `_patches/open/` | correct; patch queue stays centralized |
| Audit event | activity trace | root `_index/events/` | correct; shared event log prevents index conflicts |

## Root Versus Project Placement Decisions

| Content Type | V0 Placement | Reason |
|---|---|---|
| Project source | `projects/{project}/sources/` | Makes source searchable/browsable in SharePoint by project. |
| Cross-project source | curator-designated project or later root `sources/` expansion | V0 is project-first; root source folders should appear only when cross-project source volume proves the need. |
| Project official | `projects/{project}/official/` | Trust is project-specific and discoverable in project WIKI. |
| Cross-project official | root `official/` | Shared/common knowledge belongs at root. |
| Review queue | root `_reviews/open/` | Avoid duplicated review workflows. |
| Patch queue | root `_patches/open/` | Enables same-target detection across projects. |
| Notifications | root `_notifications/` | Users need one inbox, not one inbox per project. |
| Event log | root `_index/events/` | Keeps a single audit trail and avoids summary-index conflicts. |
| Low-friction project notes | `projects/{project}/notes/` | Searchable project memory before proposal/review. |

## Risk Recheck

| Risk | Result | Adjustment |
|---|---|---|
| Project folder sprawl | still present | require curator-created or curator-approved project mini-wiki |
| Confusion between root and project official | reduced but still possible | root README and `CLAUDE.md` must state trust order |
| Duplicate workflow queues | avoided | keep `_notifications/`, `_reviews/`, `_patches/`, and `_system/` at root |
| Search noise | manageable | require project `_index.md` and visible search keywords |
| Patch target ambiguity | manageable | patch metadata must use full target path |
| Source lineage | improved | project source path is more meaningful than root `sources/` |

## Updated Patch Metadata Example

```yaml
---
target_file: "projects/sample-project/official/external-interface.md"
target_section: "Current Checklist"
status: open
risk: medium
owner: "nishizawa"
required_approval: "project owner"
source_files:
  - "projects/sample-project/sources/2026-07-04_meeting_external-if-review.md"
---
```

## Verdict

The project mini-wiki requirement improves the design.

It adds one required project-level shell, but it does not force full project-local workflow duplication. The V0 flow remains simple if the root workspace is treated as the workflow control plane and the project folder is treated as the project knowledge surface.

## Required Follow-Up

Before pilot-folder materialization:

1. Update the project sample source path everywhere.
2. Ensure the starter official target is `projects/sample-project/official/external-interface.md`.
3. Ensure `CLAUDE.md` documents root-vs-project trust order.
4. Ensure patches use full target paths.
5. Ensure root README tells humans to start from `projects/{project}/README.md` when project is known.
