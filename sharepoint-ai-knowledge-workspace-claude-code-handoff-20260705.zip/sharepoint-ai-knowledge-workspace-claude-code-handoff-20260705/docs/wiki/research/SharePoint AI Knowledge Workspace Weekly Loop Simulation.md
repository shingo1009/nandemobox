---
type: research
title: "SharePoint AI Knowledge Workspace Weekly Loop Simulation"
status: active
created: 2026-07-05
updated: 2026-07-05
tags:
  - research
  - simulation
  - weekly
  - common-knowledge
  - motivation
  - python
related:
  - "[[SharePoint AI Knowledge Workspace Weekly Topics And Common Candidates Loop]]"
  - "[[SharePoint AI Knowledge Workspace Admin Python Maintainer Command Set]]"
  - "[[SharePoint AI Knowledge Workspace Skill Consolidation Pass]]"
  - "[[SharePoint AI Knowledge Workspace Maintenance Automation Simulation]]"
  - "[[SharePoint AI Knowledge Workspace Design Coverage Audit]]"
---

# SharePoint AI Knowledge Workspace Weekly Loop Simulation

## Purpose

Run a tabletop simulation of the weekly topics and common-candidate loop after moving deterministic maintenance to admin-run Python.

This checks whether the loop:

- helps users notice useful progress,
- finds repeated topics across project mini-wikis,
- keeps Claude Code token usage low on normal client PCs,
- stays compact rather than becoming another noisy reporting system.

## Actors

| Actor | Goal | Tool Burden |
|---|---|---|
| Admin / curator | Run maintenance and decide what deserves attention. | Python can be moderately complex. |
| Contributor | Add project-local notes and sources. | Should not run Python or broad Claude scans. |
| Reviewer | See only items that need judgment. | Should start from digest or weekly note. |
| Occasional reader | Search project WIKI or read weekly highlights. | Should not need local sync or Claude Code. |

## Scenario 1: First Week Private Pilot

Workspace state:

- one project mini-wiki,
- three new source notes,
- one extracted reviewed note,
- one open official patch,
- four low-severity FYI notifications.

Python weekly dry-run output:

- changed projects: 1,
- reviewed updates: 1,
- open patches: 1,
- common candidates: 0,
- low-severity FYI: 4.

Claude task:

- read the weekly skeleton,
- create a two-topic curator note,
- avoid broad notification,
- ask for review only on the open patch.

Result:

- useful progress is visible,
- contributor workload does not increase,
- no one receives a noisy weekly broadcast.

Finding: week 1 should remain curator-facing. The first value is administrator confidence, not team-wide distribution.

## Scenario 2: Fourth Week With Three Project Mini-Wikis

Workspace state:

- Project A: notes about source-backed claims and approval rules,
- Project B: notes about source-backed claims and release review,
- Project C: notes about approval rules and customer-sensitive sources.

Python common-candidate report:

| Candidate | Evidence | Initial Confidence |
|---|---|---|
| source-backed claims | same topic label in A/B, repeated heading names, same quality rubric link | high |
| approval rules | repeated label in A/C, different owner and different official target | medium |
| customer-sensitive sources | appears once but in a protected context | low |

Claude review:

- `source-backed claims` becomes `common_candidate`,
- `approval rules` becomes `link_only`,
- `customer-sensitive sources` becomes `keep_project_local`.

Result:

- one true common practice is surfaced,
- project-specific context is not flattened,
- sensitivity does not leak into a root common page.

Finding: common candidates need reason codes and confidence bands. Otherwise Claude must reread too much evidence before deciding.

## Scenario 3: Normal Reader Wants "What Changed?"

User behavior:

- a normal reader opens the shared folder in SharePoint,
- they do not run Claude Code,
- they want a short answer to "what changed this week?"

Good outcome:

- root or project index points to the latest accepted weekly note or digest link,
- the note has at most five topics,
- each topic has a project link and one suggested next action.

Bad outcome:

- weekly reports pile up under `_reviews/open/`,
- the user sees raw maintenance details,
- every low-severity FYI appears as a separate item.

Finding: V0 should distinguish the raw generated skeleton from a curator-accepted weekly note. Until the note format is validated, keep raw output in `_reviews/open/` and link only the accepted short note from digest or index.

## Scenario 4: Scale Stress

Workspace state:

- 12 project mini-wikis,
- 700 Markdown files,
- 80 weekly events,
- 18 common-candidate signals,
- 30 stale or waiting notifications.

Without guardrails:

- weekly notes become too long,
- common-candidate reports become a second backlog,
- Claude spends tokens explaining weak candidates.

With guardrails:

- weekly note shows at most five topics,
- common-candidate report shows top five by confidence,
- weak candidates are grouped under "deferred signals",
- items deferred for three weekly runs must be closed, promoted, or marked local-only.

Result:

- the loop remains small enough to read,
- Python still handles broad scanning,
- Claude receives a bounded set of judgment tasks.

Finding: weekly loop needs budgets. Without topic and candidate limits, it becomes a growth vector rather than a simplification layer.

## Friction Found

| Friction | Impact | Adjustment |
|---|---|---|
| Raw weekly skeleton is not suitable for normal users. | Readers see maintenance noise. | Curator-accepted weekly note should be separate from raw `_reviews/open/` output. |
| Common candidates can be weak. | Claude spends tokens rejecting noise. | Add reason codes, simple confidence bands, and top-N limits. |
| Repeated deferred candidates can accumulate. | Weekly review becomes stale. | Close, promote, or mark local-only after three appearances. |
| Users may expect every weekly topic to notify them. | Notification fatigue. | Direct notifications only for `needs_action`; everything else stays digest/index-linked. |
| Sensitivity can be lost during cross-project synthesis. | Confidential detail may leak. | Candidate reports include a sensitivity hint from paths/status before Claude writes common narrative. |

## Design Adjustments

1. Add `reason_code` and `confidence` to common-candidate reports.
2. Limit default weekly topics to five and common candidates to five.
3. Keep generated weekly skeletons in `_reviews/open/`.
4. Create or link a human-facing weekly note only after curator review.
5. Treat repeated deferred candidates as cleanup items after three weekly runs.
6. Keep normal client PCs out of Python maintenance; they consume generated views only.

## Verdict

The weekly loop is useful if it remains a bounded review aid.

It should not become:

- a broadcast newsletter,
- an automatic common-knowledge merger,
- a second notification inbox,
- a reason for normal users to run maintenance tools.

The clean design is still:

```text
admin Python scan
  -> bounded weekly evidence
  -> Claude narrative or judgment only where useful
  -> human acceptance
  -> small visible progress
```

