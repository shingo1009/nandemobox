---
type: meta
title: "Overview"
status: evergreen
created: 2026-07-02
updated: 2026-07-02
tags:
  - meta
  - overview
related:
  - "[[index]]"
  - "[[hot]]"
  - "[[log]]"
---

# Overview

This vault is the main development knowledge base for personal projects.

It stores:

- Specifications: what should be built, why it matters, scope, acceptance criteria.
- Development records: what changed, what was tested, what remains open.
- Decisions: technical and product choices with rationale.
- Project status: current workstreams, milestones, blockers, and next actions.
- Research: references, libraries, APIs, patterns, and tradeoffs discovered during development.

## Operating Model

Use `.raw/` for immutable inputs: transcripts, screenshots, exported docs, copied specs, logs, and research dumps.

Use `wiki/` for synthesized notes that Codex can maintain. The wiki is allowed to evolve. Raw sources are not.

When a new project starts, create a page in `wiki/projects/`. When a feature becomes concrete, create a page in `wiki/specs/`. When an implementation session ends, add a record to `wiki/dev-log/` and update [[hot]].

## Default Filing Rules

- Feature requirements go to `wiki/specs/`.
- Session summaries go to `wiki/dev-log/`.
- Architecture choices go to `wiki/decisions/`.
- Project-level status goes to `wiki/projects/`.
- Code structure notes go to `wiki/modules/`.
- External docs and research synthesis go to `wiki/research/`, `wiki/sources/`, `wiki/entities/`, or `wiki/concepts/`.
